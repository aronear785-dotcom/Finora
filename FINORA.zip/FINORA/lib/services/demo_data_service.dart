import 'package:sqflite/sqflite.dart';

import '../database/app_database.dart';
import '../models/budget.dart';
import '../models/category.dart';
import '../models/debt.dart';
import '../models/expense.dart';
import '../models/income.dart';
import '../models/recurring_expense.dart';
import '../models/savings_goal.dart';
import '../models/savings_transaction.dart';
import '../models/subscription.dart';
import '../repositories/finance_repository.dart';
import '../repositories/planning_repository.dart';

/// Optional realistic sample data so the UI and charts can be explored
/// immediately. Sample rows are ordinary rows; "Remove sample data" uses
/// the same safe wipe as "Delete all data". A guard prevents loading samples
/// when real data already exists, so demo rows are never mixed with real
/// entries.
class DemoDataService {
  DemoDataService();

  Future<bool> _userDataExists() async {
    final db = await AppDatabase.instance.database;
    final exp = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM expenses'));
    final inc = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM income'));
    final sav = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM savings_goals'));
    return (exp ?? 0) > 0 || (inc ?? 0) > 0 || (sav ?? 0) > 0;
  }

  Future<void> loadSampleData() async {
    if (await _userDataExists()) return; // never mix with real data

    final finance = FinanceRepository();
    final planning = PlanningRepository();
    final now = DateTime.now();
    final year = now.year;
    final month = now.month;
    final daysInMonth = DateTime(year, month + 1, 0).day;
    int _day(int d) => d > daysInMonth ? daysInMonth : d;

    final cats = await finance.categories();
    final incomeCats = await finance.categories(income: true);
    int? catId(List<Category> list, String name) {
      for (final c in list) {
        if (c.name == name) return c.id;
      }
      return null;
    }

    // ----- Income
    final salaryId = catId(incomeCats, 'salary');
    final freelanceId = catId(incomeCats, 'freelance');
    if (salaryId != null) {
      await finance.addIncome(Income(
          amount: 15000,
          categoryId: salaryId,
          date: DateTime(year, month, 1),
          note: 'Monthly salary',
          isRecurring: true));
    }
    if (freelanceId != null) {
      await finance.addIncome(Income(
          amount: 2000,
          categoryId: freelanceId,
          date: DateTime(year, month, _day(12)),
          note: 'Design project'));
    }

    // ----- Expenses spread across the month
    const sampleExpenses = <(double, String, int, String)>[
      (5000, 'rent', 3, 'Apartment rent'),
      (250, 'food', 4, 'Groceries'),
      (120, 'food', 6, 'Lunch'),
      (30, 'transport', 6, 'Metro card'),
      (300, 'internet', 7, 'Fiber plan'),
      (80, 'phone', 7, 'Mobile plan'),
      (180, 'shopping', 9, 'Shoes'),
      (220, 'food', 11, 'Groceries'),
      (400, 'car', 14, 'Fuel'),
      (90, 'entertainment', 16, 'Cinema'),
      (150, 'food', 18, 'Restaurant'),
      (60, 'health', 20, 'Pharmacy'),
    ];
    for (final (amount, catName, day, note) in sampleExpenses) {
      final id = catId(cats, catName);
      if (id == null) continue;
      await finance.addExpense(Expense(
          amount: amount,
          categoryId: id,
          date: DateTime(year, month, _day(day)),
          note: note));
    }

    // ----- Budgets for the current month
    final budgetDefs = <(String, double)>[
      ('food', 2500),
      ('transport', 800),
      ('shopping', 1000),
      ('entertainment', 500),
      ('rent', 5000),
    ];
    final monthKey = '$year-${month.toString().padLeft(2, '0')}';
    for (final (catName, amount) in budgetDefs) {
      final id = catId(cats, catName);
      if (id == null) continue;
      await planning.setBudget(
          Budget(categoryId: id, amount: amount, month: monthKey));
    }

    // ----- Savings goal + transactions
    final goalId = await planning.addSavingsGoal(SavingsGoal(
      name: 'Emergency fund',
      target: 30000,
      color: 0xFF00BFA5,
      icon: 'emergency',
      note: '3 months of expenses',
    ));
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: goalId, amount: 3000, date: DateTime(year, month, 1)));
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: goalId,
        amount: 1500,
        date: DateTime(year, month, _day(10)),
        note: 'First paycheck'));

    // ----- Subscriptions
    await planning.addSubscription(Subscription(
        name: 'Netflix',
        amount: 120,
        period: 'monthly',
        nextBilling: DateTime(year, month, _day(5))));
    await planning.addSubscription(Subscription(
        name: 'Cloud storage',
        amount: 240,
        period: 'yearly',
        nextBilling: DateTime(year, month, _day(20))));

    // ----- Recurring expense (rent template)
    await planning.addRecurringExpense(RecurringExpense(
      name: 'Rent',
      amount: 5000,
      categoryId: catId(cats, 'rent') ?? 1,
      frequency: 'monthly',
      nextDate: DateTime(year, month + 1, 1),
      active: true,
    ));

    // ----- Debts
    await planning.addDebt(Debt(
      person: 'Karim',
      amount: 500,
      direction: Debt.owe,
      date: DateTime(year, month, _day(8)),
      note: 'Dinner',
    ));
    await planning.addDebt(Debt(
      person: 'Sara',
      amount: 300,
      direction: Debt.owed,
      date: DateTime(year, month, _day(15)),
      note: 'Taxi share',
    ));
  }
}
