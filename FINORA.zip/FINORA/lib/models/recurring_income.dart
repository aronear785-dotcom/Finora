/// An automatic monthly income template (e.g. salary). A real income row is
/// generated for it on [dayOfMonth] of every month starting at [startMonth]
/// ('YYYY-MM'), unless that month was skipped by the user.
class RecurringIncome {
  const RecurringIncome({
    this.id,
    required this.name,
    required this.amount,
    required this.categoryId,
    this.dayOfMonth = 1,
    required this.startMonth,
    this.endMonth,
    this.autoReceive = true,
    this.active = true,
  });

  final int? id;
  final String name;
  final double amount;
  final int categoryId;
  final int dayOfMonth;
  final String startMonth;

  /// Last month ('YYYY-MM') the income applies to; null = no end.
  final String? endMonth;

  /// true: recorded as received automatically on its day.
  /// false: stays "expected" until the user confirms receipt.
  final bool autoReceive;
  final bool active;

  RecurringIncome copyWith({
    String? name,
    double? amount,
    int? categoryId,
    int? dayOfMonth,
    String? startMonth,
    String? endMonth,
    bool clearEndMonth = false,
    bool? autoReceive,
    bool? active,
  }) =>
      RecurringIncome(
        id: id,
        name: name ?? this.name,
        amount: amount ?? this.amount,
        categoryId: categoryId ?? this.categoryId,
        dayOfMonth: dayOfMonth ?? this.dayOfMonth,
        startMonth: startMonth ?? this.startMonth,
        endMonth: clearEndMonth ? null : (endMonth ?? this.endMonth),
        autoReceive: autoReceive ?? this.autoReceive,
        active: active ?? this.active,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'amount': amount,
        'category_id': categoryId,
        'day_of_month': dayOfMonth,
        'start_month': startMonth,
        'end_month': endMonth,
        'auto_receive': autoReceive ? 1 : 0,
        'active': active ? 1 : 0,
      };

  factory RecurringIncome.fromMap(Map<String, Object?> map) => RecurringIncome(
        id: map['id'] as int?,
        name: map['name'] as String,
        amount: (map['amount'] as num).toDouble(),
        categoryId: map['category_id'] as int,
        dayOfMonth: (map['day_of_month'] as int?) ?? 1,
        startMonth: map['start_month'] as String,
        endMonth: map['end_month'] as String?,
        autoReceive: (map['auto_receive'] as int? ?? 1) == 1,
        active: (map['active'] as int? ?? 1) == 1,
      );
}
