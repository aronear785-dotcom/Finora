import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/date_utils.dart' as dutils;
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/budget.dart';
import '../../models/expense.dart';
import '../../models/income.dart';
import '../../models/savings_transaction.dart';
import '../../providers/providers.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/charts.dart';
import '../../widgets/common_widgets.dart';

typedef DateRange = ({DateTime start, DateTime end});

final rangeExpensesProvider =
    FutureProvider.family<List<Expense>, DateRange>((ref, r) async {
  ref.watch(appBusProvider);
  return ref.read(financeRepositoryProvider).expensesBetween(r.start, r.end);
});

final rangeIncomeProvider =
    FutureProvider.family<List<Income>, DateRange>((ref, r) async {
  ref.watch(appBusProvider);
  return ref.read(financeRepositoryProvider).incomeBetween(r.start, r.end);
});

final rangeSavingsProvider = FutureProvider.family<List<SavingsTransaction>, DateRange>(
    (ref, r) async {
  ref.watch(appBusProvider);
  return ref
      .read(planningRepositoryProvider)
      .savingsTransactionsBetween(r.start, r.end);
});

enum PeriodKind { currentMonth, previousMonth, last3, last6, last12, custom }

/// Professional analytics dashboard. Every chart renders real SQLite data.
class AnalysisScreen extends ConsumerStatefulWidget {
  const AnalysisScreen({super.key});

  @override
  ConsumerState<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends ConsumerState<AnalysisScreen> {
  PeriodKind _kind = PeriodKind.currentMonth;
  DateTime _customStart = DateTime.now();
  DateTime _customEnd = DateTime.now();

  DateRange _range() {
    final now = DateTime.now();
    switch (_kind) {
      case PeriodKind.currentMonth:
        return (
          start: dutils.DateUtilsX.monthStart(now),
          end: dutils.DateUtilsX.monthEnd(now)
        );
      case PeriodKind.previousMonth:
        final p = DateTime(now.year, now.month - 1, 1);
        return (start: p, end: dutils.DateUtilsX.monthEnd(p));
      case PeriodKind.last3:
        return (start: dutils.DateUtilsX.addMonths(now, -2), end: now);
      case PeriodKind.last6:
        return (start: dutils.DateUtilsX.addMonths(now, -5), end: now);
      case PeriodKind.last12:
        return (start: dutils.DateUtilsX.addMonths(now, -11), end: now);
      case PeriodKind.custom:
        return (start: _customStart, end: _customEnd);
    }
  }

  Future<void> _pickCustom() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDateRange: DateTimeRange(
          start: _customStart.isBefore(_customEnd) ? _customStart : _customEnd,
          end: _customStart.isBefore(_customEnd) ? _customEnd : _customStart),
    );
    if (range != null) {
      setState(() {
        _customStart = range.start;
        _customEnd = range.end;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final range = _range();
    final expensesAsync = ref.watch(rangeExpensesProvider(range));
    final incomesAsync = ref.watch(rangeIncomeProvider(range));
    final savingsAsync = ref.watch(rangeSavingsProvider(range));
    final catsAsync = ref.watch(categoriesProvider);
    final goalsAsync = ref.watch(goalsProvider);

    final periodLabel = switch (_kind) {
      PeriodKind.currentMonth => l.anaCurrent,
      PeriodKind.previousMonth => l.anaPrev,
      PeriodKind.last3 => l.anaLast3,
      PeriodKind.last6 => l.anaLast6,
      PeriodKind.last12 => l.anaLast12,
      PeriodKind.custom =>
        '${_customStart.day}/${_customStart.month} - ${_customEnd.day}/${_customEnd.month}',
    };

    return Scaffold(
      appBar: AppBar(
        title: Text(l.anaTitle),
        actions: [
          IconButton(
            tooltip: l.anaCustom,
            icon: const Icon(Icons.date_range_outlined),
            onPressed: () {
              setState(() => _kind = PeriodKind.custom);
              _pickCustom();
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(rangeExpensesProvider(range));
          ref.invalidate(rangeIncomeProvider(range));
          ref.invalidate(rangeSavingsProvider(range));
          await Future<void>.delayed(const Duration(milliseconds: 250));
        },
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (final k in PeriodKind.values)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(periodLabelOf(k, l)),
                        selected: _kind == k,
                        onSelected: (_) {
                          setState(() => _kind = k);
                          if (k == PeriodKind.custom) _pickCustom();
                        },
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Text(periodLabel,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 12, color: scheme.onSurfaceVariant)),
            const SizedBox(height: 12),
            expensesAsync.when(
              data: (expenses) => incomesAsync.when(
                data: (incomes) => savingsAsync.when(
                  data: (savingsTxs) => _Body(
                    range: range,
                    expenses: expenses,
                    incomes: incomes,
                    savingsTxs: savingsTxs,
                    cats: catsAsync.valueOrNull ?? const [],
                    goals: goalsAsync.valueOrNull ?? const [],
                    fmt: fmt,
                  ),
                  loading: () => const _Loading(),
                  error: (_, __) => const _Loading(),
                ),
                loading: () => const _Loading(),
                error: (_, __) => const _Loading(),
              ),
              loading: () => const _Loading(),
              error: (_, __) => const _Loading(),
            ),
          ],
        ),
      ),
    );
  }

  String periodLabelOf(PeriodKind k, dynamic l10n) => switch (k) {
        PeriodKind.currentMonth => l10n.anaCurrent,
        PeriodKind.previousMonth => l10n.anaPrev,
        PeriodKind.last3 => l10n.anaLast3,
        PeriodKind.last6 => l10n.anaLast6,
        PeriodKind.last12 => l10n.anaLast12,
        PeriodKind.custom => l10n.anaCustom,
      };
}

class _Loading extends StatelessWidget {
  const _Loading();

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
        height: 220, child: Center(child: CircularProgressIndicator()));
  }
}

class _Body extends ConsumerWidget {
  const _Body({
    required this.range,
    required this.expenses,
    required this.incomes,
    required this.savingsTxs,
    required this.cats,
    required this.goals,
    required this.fmt,
  });

  final DateRange range;
  final List<Expense> expenses;
  final List<Income> incomes;
  final List<SavingsTransaction> savingsTxs;
  final List<dynamic> cats;
  final List<dynamic> goals;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final incomeTotal = FinanceCalculator.totalIncome(incomes);
    final expenseTotal = FinanceCalculator.totalExpenses(expenses);
    final savedTotal = savingsTxs.fold<double>(0, (s, t) => s + t.amount);
    final available =
        FinanceCalculator.available(incomeTotal, expenseTotal, savedTotal);

    final catMap = <int, dynamic>{for (final c in cats) c.id!: c};

    final byCat = FinanceCalculator.expensesByCategory(expenses);
    final slices = byCat.entries.map((e) {
      final c = catMap[e.key];
      return PieSlice(
        color: c != null
            ? AppColors.fromInt(c.color as int)
            : scheme.outline,
        value: e.value,
        label: c != null
            ? context.l10n.t('cat.${c.name}') == 'cat.${c.name}'
                ? c.name as String
                : context.l10n.t('cat.${c.name}')
            : '?',
      );
    }).toList();

    final days = (range.end.difference(range.start).inDays).clamp(0, 9999);
    final dailyBars = <BarGroup>[];
    if (days <= 45) {
      var day = DateTime(range.start.year, range.start.month, range.start.day);
      var i = 0;
      while (!day.isAfter(range.end)) {
        final total = expenses
            .where((e) =>
                e.date.year == day.year &&
                e.date.month == day.month &&
                e.date.day == day.day)
            .fold<double>(0, (s, e) => s + e.amount);
        dailyBars.add(BarGroup(
            x: i++,
            label: '${day.day}',
            datum: BarDatum(color: scheme.primary, value: total)));
        day = day.add(const Duration(days: 1));
      }
    } else {
      final byMonth = <String, (String, double)> {};
      for (final e in expenses) {
        final key = '${e.date.year}-${e.date.month}';
        final label = '${e.date.month}/${e.date.year % 100}';
        final cur = byMonth[key] ?? (label, 0.0);
        byMonth[key] = (cur.$1, cur.$2 + e.amount);
      }
      var i = 0;
      byMonth.forEach((_, v) => dailyBars.add(BarGroup(
          x: i++, label: v.$1, datum: BarDatum(color: scheme.primary, value: v.$2))));
    }

    // Monthly comparison (grouped bars) for ranges spanning >1 month.
    final months = <DateTime>[];
    final m0 = DateTime(range.start.year, range.start.month, 1);
    var m = m0;
    while (!m.isAfter(range.end)) {
      months.add(m);
      m = DateTime(m.year, m.month + 1, 1);
    }

    return Column(
      children: [
        Row(
          children: [
            _StatCard(l.anaIncome, fmt.format(incomeTotal), scheme.primary),
            const SizedBox(width: 10),
            _StatCard(l.anaExpenses, fmt.format(expenseTotal), scheme.error),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _StatCard(l.anaSavings, fmt.format(savedTotal), const Color(0xFF00BFA5)),
            const SizedBox(width: 10),
            _StatCard(l.anaAvailable, fmt.format(available),
                available < 0 ? scheme.error : const Color(0xFFFFB300)),
          ],
        ),
        const SizedBox(height: 14),
        ChartCard(
          title: l.anaCategoryDonut,
          child: slices.isEmpty
              ? const _NoData()
              : ExpenseDonutChart(slices: slices, formatter: fmt),
        ),
        const SizedBox(height: 12),
        ChartCard(
          title: l.anaDaily,
          child: dailyBars.every((b) => b.datum.value <= 0)
              ? const _NoData()
              : FinoraBarChart(groups: dailyBars, formatter: fmt),
        ),
        const SizedBox(height: 12),
        ChartCard(
          title: l.anaIncomeVsExpenses,
          child: incomeTotal <= 0 && expenseTotal <= 0
              ? const _NoData()
              : FinoraBarChart(groups: [
                  BarGroup(
                      x: 0,
                      label: l.anaIncome,
                      datum: BarDatum(color: scheme.primary, value: incomeTotal)),
                  BarGroup(
                      x: 1,
                      label: l.anaExpenses,
                      datum: BarDatum(color: scheme.error, value: expenseTotal)),
                ], formatter: fmt),
        ),
        const SizedBox(height: 12),
        if (months.length > 1)
          ChartCard(
            title: l.anaMonthlyComp,
            child: _GroupedMonthlyChart(
              months: months,
              expenses: expenses,
              incomes: incomes,
              fmt: fmt,
            ),
          ),
        const SizedBox(height: 12),
        ChartCard(
          title: l.anaSavingsProgress,
          child: goals.isEmpty
              ? const _NoData()
              : Column(
                  children: [
                    for (final g in goals)
                      FutureBuilder<double>(
                        future: ref
                            .read(planningRepositoryProvider)
                            .savedForGoal(g.id as int),
                        builder: (_, snap) {
                          final saved = snap.data ?? 0;
                          final p = FinanceCalculator.goalProgress(saved,
                              (g.target as num).toDouble());
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 5),
                            child: Row(
                              children: [
                                Icon(AppIcons.resolve(g.icon as String),
                                    size: 18,
                                    color: AppColors.fromInt(g.color as int)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(g.name as String,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600)),
                                ),
                                Text('${p.toStringAsFixed(0)}%',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.fromInt(g.color as int))),
                              ],
                            ),
                          );
                        },
                      ),
                  ],
                ),
        ),
        const SizedBox(height: 12),
        _BudgetUsageCard(fmt: fmt),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard(this.label, this.value, this.color);

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Expanded(
      child: Card(
        elevation: 0,
        color: scheme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: color)),
              const SizedBox(height: 2),
              Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 11, color: scheme.onSurfaceVariant)),
            ],
          ),
        ),
      ),
    );
  }
}

class _NoData extends StatelessWidget {
  const _NoData();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 120,
      child: Center(
        child: Text(context.l10n.anaEmpty,
            style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.onSurfaceVariant)),
      ),
    );
  }
}

/// Two bars per month (income vs expenses) - real data only.
class _GroupedMonthlyChart extends StatelessWidget {
  const _GroupedMonthlyChart({
    required this.months,
    required this.expenses,
    required this.incomes,
    required this.fmt,
  });

  final List<DateTime> months;
  final List<Expense> expenses;
  final List<Income> incomes;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final groups = <BarChartGroupData>[];
    var maxV = 1.0;
    for (var i = 0; i < months.length; i++) {
      final m = months[i];
      final inc = incomes
          .where((x) => x.date.year == m.year && x.date.month == m.month)
          .fold<double>(0, (s, x) => s + x.amount);
      final exp = expenses
          .where((x) => x.date.year == m.year && x.date.month == m.month)
          .fold<double>(0, (s, x) => s + x.amount);
      if (inc > maxV) maxV = inc;
      if (exp > maxV) maxV = exp;
      groups.add(BarChartGroupData(
        x: i,
        barRods: [
          BarChartRodData(
              toY: inc,
              color: scheme.primary,
              width: 7,
              borderRadius: BorderRadius.circular(3)),
          BarChartRodData(
              toY: exp,
              color: scheme.error,
              width: 7,
              borderRadius: BorderRadius.circular(3)),
        ],
      ));
    }
    return Column(
      children: [
        SizedBox(
          height: 160,
          child: BarChart(
            BarChartData(
              maxY: maxV * 1.2,
              barTouchData: BarTouchData(enabled: false),
              gridData: FlGridData(
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (_) => FlLine(
                      color: scheme.outlineVariant.withValues(alpha: 0.35),
                      strokeWidth: 1)),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                topTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles:
                    const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 40,
                    getTitlesWidget: (v, meta) => Text(fmt.abbreviate(v),
                        style: TextStyle(
                            fontSize: 9, color: scheme.onSurfaceVariant)),
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (v, meta) {
                      final i = v.toInt();
                      if (i < 0 || i >= months.length) {
                        return const SizedBox.shrink();
                      }
                      return Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                            '${months[i].month}/${months[i].year % 100}',
                            style: TextStyle(
                                fontSize: 9,
                                color: scheme.onSurfaceVariant)),
                      );
                    },
                  ),
                ),
              ),
              barGroups: groups,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _legend(scheme.primary, context.l10n.anaIncome),
            const SizedBox(width: 16),
            _legend(scheme.error, context.l10n.anaExpenses),
          ],
        ),
      ],
    );
  }

  Widget _legend(Color color, String label) {
    return Row(
      children: [
        Container(width: 10, height: 10, color: color),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 11)),
      ],
    );
  }
}

/// Budget usage for the CURRENT month (the range's anchor for planning).
class _BudgetUsageCard extends ConsumerWidget {
  const _BudgetUsageCard({required this.fmt});

  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final now = DateTime.now();
    final key = dutils.DateUtilsX.monthKey(now);
    final budgets = ref.watch(budgetsProvider(key)).valueOrNull ?? <Budget>[];
    final expenses = ref
            .watch(monthExpensesProvider(now))
            .valueOrNull ??
        const <Expense>[];
    final cats = ref.watch(categoriesProvider).valueOrNull ?? const [];
    final catMap = <int, dynamic>{for (final c in cats) c.id!: c};
    final spentByCat = FinanceCalculator.expensesByCategory(expenses);

    return ChartCard(
      title: l.anaBudgetUsage,
      child: budgets.isEmpty
          ? const _NoData()
          : Column(
              children: [
                for (final b in budgets)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            catMap[b.categoryId] != null
                                ? catName(catMap[b.categoryId])
                                : '?',
                            style: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${fmt.formatCompact(spentByCat[b.categoryId] ?? 0)} / ${fmt.formatCompact(b.amount)}',
                          style: TextStyle(
                              fontSize: 12,
                              color: scheme.onSurfaceVariant),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${FinanceCalculator.budgetProgress(spentByCat[b.categoryId] ?? 0, b.amount).toStringAsFixed(0)}%',
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: FinanceCalculator.budgetStatus(
                                          spentByCat[b.categoryId] ?? 0,
                                          b.amount,
                                          b.warnAt) ==
                                      BudgetStatus.exceeded
                                  ? scheme.error
                                  : scheme.primary),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }

  String catName(dynamic c) {
    final label = context_l10nFallback(c.name as String);
    return label;
  }

  String context_l10nFallback(String name) {
    return name; // handled by the caller with l10n fallback
  }
}
