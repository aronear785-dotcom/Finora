import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'l10n/app_localizations.dart';
import 'providers/providers.dart';
import 'repositories/planning_repository.dart';
import 'screens/home_shell.dart';
import 'screens/onboarding_screen.dart';
import 'services/reminder_service.dart';
import 'services/settings_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Offline-first bootstrap: seed default categories, generate any due
  // recurring transactions, then start reminders if enabled.
  await SettingsService().seedDefaults();
  try {
    await PlanningRepository().generateDueTransactions();
  } catch (_) {
    // Never block startup because of a background task.
  }
  await ReminderService.instance.init();
  final s = await SettingsService().load();
  if (s.remindersEnabled) {
    await ReminderService.instance.scheduleDaily(
        hour: s.reminderHour, minute: s.reminderMinute);
  }
  runApp(const ProviderScope(child: FinoraApp()));
}

class FinoraApp extends ConsumerWidget {
  const FinoraApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settingsAsync = ref.watch(settingsProvider);
    return settingsAsync.when(
      loading: () => const _BootApp(home: _SplashView()),
      error: (_, __) => const _BootApp(home: _SplashView()),
      data: (settings) {
        final themeMode = switch (settings.theme) {
          'light' => ThemeMode.light,
          'dark' => ThemeMode.dark,
          _ => ThemeMode.system,
        };
        return MaterialApp(
          title: 'FINORA',
          debugShowCheckedModeBanner: false,
          locale: settings.language == 'system'
              ? null
              : Locale(settings.language),
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          localeResolutionCallback: (locale, supported) {
            if (locale == null) return const Locale('en');
            final lang = locale.languageCode;
            if (AppLocalizations.supportedLocales
                .any((l) => l.languageCode == lang)) {
              return Locale(lang);
            }
            return const Locale('en');
          },
          theme: AppTheme.light(),
          darkTheme: AppTheme.dark(),
          themeMode: themeMode,
          home: settings.onboardingDone
              ? const HomeShell()
              : const OnboardingScreen(),
        );
      },
    );
  }
}

/// Minimal app shell used while settings are still loading.
class _BootApp extends StatelessWidget {
  const _BootApp({required this.home});

  final Widget home;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: home,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [AppLocalizations.delegate],
    );
  }
}

class _SplashView extends StatelessWidget {
  const _SplashView();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: scheme.surface,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: Image.asset('assets/images/logo.png',
                  width: 110, height: 110),
            ),
            const SizedBox(height: 20),
            Text('FINORA',
                style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                    color: scheme.primary)),
            const SizedBox(height: 6),
            const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ],
        ),
      ),
    );
  }
}
