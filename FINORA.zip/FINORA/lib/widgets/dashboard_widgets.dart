import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/constants.dart';
import '../core/utils/date_utils.dart';
import '../core/utils/money_formatter.dart';
import '../domain/ledger_calculator.dart';
import '../l10n/l10n_ext.dart';
import '../models/plan_run.dart';
import '../providers/providers.dart';
import '../repositories/automation_repository.dart';
import '../screens/expenses/expenses_screen.dart';
import '../screens/home/quick_add_sheet.dart';
import '../screens/savings/savings_screen.dart';
import 'common_widgets.dart';

/// Dashboard palette: income green, expenses orange, savings soft blue.
class DashColors {
  DashColors._();

  static const income = Color(0xFF2ECC71);
  static const expense = Color(0xFFFF7043);
  static const savings = Color(0xFF6C8CFF);
}

String _groupLabel(BuildContext context, IncomeGroup g) => switch (g) {
      IncomeGroup.salary => context.l10n.bdSalary,
      IncomeGroup.freelance => context.l10n.bdFreelance,
      IncomeGroup.extra => context.l10n.bdExtra,
      IncomeGroup.loan => context.l10n.bdLoans,
    };

// ------------------------------------------------------------------ summary
/// "Disponible" hero card + income / expenses / savings cards. All figures
/// come from [monthLedgerProvider] (one centralized calculation).
class DashboardSummary extends ConsumerWidget {
  const DashboardSummary({super.key, required this.month});

  final DateTime month;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final fmt = ref.watch(moneyFormatterProvider);
    final async =
        ref.watch(monthLedgerProvider(DateTime(month.year, month.month, 1)));
    return async.when(
      loading: () => const SizedBox(
          height: 220, child: Center(child: CircularProgressIndicator())),
      error: (_, __) => const SizedBox(height: 120),
      data: (ledger) => Column(
        children: [
          _AvailableCard(ledger: ledger, fmt: fmt),
          const SizedBox(height: 12),
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: _MiniCard(
                    label: context.l10n.homeIncome,
                    value: fmt.format(ledger.receivedIncome),
                    icon: Icons.arrow_downward_rounded,
                    color: DashColors.income,
                    onTap: () =>
                        showIncomeBreakdownSheet(context, ledger, fmt),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _MiniCard(
                    label: context.l10n.homeExpenses,
                    value: fmt.format(ledger.totalExpenses),
                    icon: Icons.arrow_upward_rounded,
                    color: DashColors.expense,
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => const ExpensesScreen())),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _MiniCard(
                    label: context.l10n.homeSavings,
                    value: fmt.format(ledger.actualSavings),
                    icon: Icons.savings_outlined,
                    color: DashColors.savings,
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => const SavingsScreen())),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AvailableCard extends StatelessWidget {
  const _AvailableCard({required this.ledger, required this.fmt});

  final MonthLedger ledger;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final negative = ledger.available < 0;
    final color = negative ? scheme.error : scheme.primary;
    return Semantics(
      button: true,
      label: '${l.homeAvailable}: ${fmt.format(ledger.available)}',
      child: Material(
        color: scheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(color: color.withValues(alpha: 0.45), width: 1.2),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => showAvailableSheet(context, ledger, fmt),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.account_balance_wallet_outlined,
                        size: 18, color: color),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(l.homeAvailable,
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: scheme.onSurfaceVariant)),
                    ),
                    if (negative)
                      Icon(Icons.warning_amber_rounded,
                          size: 18, color: scheme.error),
                    Icon(Icons.chevron_right,
                        size: 20, color: scheme.onSurfaceVariant),
                  ],
                ),
                const SizedBox(height: 8),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(fmt.format(ledger.available),
                      style: TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.w800,
                          color: color)),
                ),
                const SizedBox(height: 4),
                Text(l.dashAvailableSub,
                    style: TextStyle(
                        fontSize: 12, color: scheme.onSurfaceVariant)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MiniCard extends StatelessWidget {
  const _MiniCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Semantics(
      button: true,
      label: '$label: $value',
      child: Material(
        color: scheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: scheme.outlineVariant.withValues(alpha: 0.5)),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(icon, size: 16, color: color),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 12, color: scheme.onSurfaceVariant)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(value,
                      style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w800,
                          color: color)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------- sheets
Widget _sheetLine(BuildContext context, String label, String value,
    {Color? color, bool bold = false, String? sub}) {
  final scheme = Theme.of(context).colorScheme;
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
                      color: scheme.onSurface)),
              if (sub != null)
                Text(sub,
                    style: TextStyle(
                        fontSize: 11, color: scheme.onSurfaceVariant)),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Text(value,
            style: TextStyle(
                fontSize: bold ? 17 : 14,
                fontWeight: FontWeight.w800,
                color: color ?? scheme.onSurface)),
      ],
    ),
  );
}

Future<void> _showSheet(BuildContext context, String title, List<Widget> body) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (ctx) => SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          ...body,
        ],
      ),
    ),
  );
}

/// Income breakdown: base salary, freelance, additional income and loans
/// received. The lines add up exactly to the "Revenus" card total, and a
/// loan is never presented as earned income.
Future<void> showIncomeBreakdownSheet(
    BuildContext context, MonthLedger ledger, MoneyFormatter fmt) {
  final l = context.l10n;
  final scheme = Theme.of(context).colorScheme;
  final total = ledger.receivedIncome;
  final children = <Widget>[];
  if (ledger.incomeGroups.isEmpty) {
    children.add(Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Text(l.bdEmpty),
    ));
  }
  for (final g in ledger.incomeGroups) {
    final pct = total <= 0 ? 0 : g.amount / total * 100;
    children.add(_sheetLine(
      context,
      _groupLabel(context, g.group),
      fmt.format(g.amount),
      color: g.group == IncomeGroup.loan ? scheme.tertiary : DashColors.income,
      sub: '${pct.toStringAsFixed(0)}%',
    ));
  }
  children.add(const Divider(height: 22));
  children.add(_sheetLine(context, l.bdTotal, fmt.format(total), bold: true));
  children.add(_sheetLine(context, l.bdEarned, fmt.format(ledger.earnedIncome)));
  if (ledger.loanIncome > 0) {
    children.add(Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Text(l.bdLoanNote,
          style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant)),
    ));
  }
  if (ledger.expectedIncome > 0) {
    children.add(const Divider(height: 22));
    children.add(_sheetLine(
      context,
      l.autoExpectedIncome,
      fmt.format(ledger.expectedIncome),
      sub: l.dashExpectedNotCounted,
      color: scheme.onSurfaceVariant,
    ));
  }
  return _showSheet(context, l.bdTitle, children);
}

/// Transparent "how is Disponible calculated" sheet.
Future<void> showAvailableSheet(
    BuildContext context, MonthLedger ledger, MoneyFormatter fmt) {
  final l = context.l10n;
  final scheme = Theme.of(context).colorScheme;
  return _showSheet(context, l.dashHowCalc, [
    _sheetLine(context, l.dashReceived, '+${fmt.format(ledger.receivedIncome)}',
        color: DashColors.income),
    _sheetLine(context, l.dashFixed, '-${fmt.format(ledger.fixedExpenses)}',
        color: DashColors.expense),
    _sheetLine(
        context, l.dashVariable, '-${fmt.format(ledger.variableExpenses)}',
        color: DashColors.expense),
    _sheetLine(
        context, l.dashSavedActual, '-${fmt.format(ledger.actualSavings)}',
        color: DashColors.savings),
    const Divider(height: 22),
    _sheetLine(context, l.homeAvailable, fmt.format(ledger.available),
        bold: true,
        color: ledger.available < 0 ? scheme.error : scheme.primary),
    const SizedBox(height: 10),
    Text(l.dashAvailableSub,
        style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant)),
    if (ledger.expectedIncome > 0)
      _sheetLine(context, l.autoExpectedIncome,
          fmt.format(ledger.expectedIncome),
          sub: l.dashExpectedNotCounted, color: scheme.onSurfaceVariant),
    if (ledger.plannedSavings > 0)
      _sheetLine(context, l.autoAutoSavings, fmt.format(ledger.plannedSavings),
          sub: l.dashPlannedSavings, color: scheme.onSurfaceVariant),
  ]);
}

// ---------------------------------------------------------- budget overview
/// Variable budgets only: real spending, remaining amount, progress bar and a
/// one-tap quick add per category. Fixed expenses never appear here.
class BudgetOverviewCard extends ConsumerWidget {
  const BudgetOverviewCard({super.key, required this.month});

  final DateTime month;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final async =
        ref.watch(monthLedgerProvider(DateTime(month.year, month.month, 1)));
    return Card(
      elevation: 0,
      color: scheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: scheme.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(l.dashBudgets,
                style:
                    const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            async.when(
              loading: () => const SizedBox(height: 60),
              error: (_, __) => const SizedBox(height: 40),
              data: (ledger) {
                if (ledger.budgetLines.isEmpty) {
                  return Text(l.dashNoBudgets,
                      style: TextStyle(
                          fontSize: 13, color: scheme.onSurfaceVariant));
                }
                return Column(
                  children: [
                    for (final b in ledger.budgetLines)
                      _BudgetRow(line: b, fmt: fmt),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _BudgetRow extends StatelessWidget {
  const _BudgetRow({required this.line, required this.fmt});

  final BudgetLine line;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final over = line.isOver;
    final color = over ? scheme.error : AppColors.fromInt(line.category.color);
    final name = context.categoryLabel(line.category.name);
    final status = over
        ? '${l.dashBudgetOver} ${fmt.format(line.remaining.abs())}'
        : '${l.dashBudgetLeft} ${fmt.format(line.remaining)}';
    return Semantics(
      label:
          '$name. ${l.dashBudgetSpent} ${fmt.format(line.spent)} / ${fmt.format(line.limit)}. $status',
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          children: [
            Icon(AppIcons.resolve(line.category.icon), size: 22, color: color),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w700)),
                      ),
                      if (over)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 4),
                          child: Icon(Icons.warning_amber_rounded,
                              size: 16, color: scheme.error),
                        ),
                      Text(
                          '${fmt.format(line.spent)} / ${fmt.format(line.limit)}',
                          style: TextStyle(
                              fontSize: 12, color: scheme.onSurfaceVariant)),
                    ],
                  ),
                  const SizedBox(height: 5),
                  ProgressBar(value: line.progress, color: color),
                  const SizedBox(height: 3),
                  Text(status,
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: over ? scheme.error : scheme.onSurface)),
                ],
              ),
            ),
            IconButton(
              tooltip: l.expQuick,
              onPressed: () =>
                  showQuickAdd(context, categoryId: line.category.id),
              icon: Icon(Icons.add_circle_outline, color: scheme.primary),
            ),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------------------- upcoming
/// Expected recurring income (not received yet) and upcoming fixed
/// obligations for the selected month.
class UpcomingCard extends ConsumerWidget {
  const UpcomingCard({super.key, required this.month});

  final DateTime month;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final m = DateTime(month.year, month.month, 1);
    final key = DateUtilsX.monthKey(m);
    final incomes = ref.watch(recurringIncomesProvider).valueOrNull ?? const [];
    final runs = ref.watch(planRunsProvider(key)).valueOrNull ?? const <PlanRun>[];
    final recurring = ref.watch(recurringProvider).valueOrNull ?? const [];

    final rows = <Widget>[];
    final today = DateTime.now();
    final todayStart = DateTime(today.year, today.month, today.day);
    for (final p in incomes) {
      final handled =
          runs.any((r) => r.kind == PlanKind.income && r.planId == p.id);
      if (!p.active || handled || p.startMonth.compareTo(key) > 0) continue;
      if (p.endMonth != null && key.compareTo(p.endMonth!) > 0) continue;
      final due =
          !AutomationRepository.occurrence(m, p.dayOfMonth).isAfter(todayStart);
      final awaiting = !p.autoReceive && due;
      rows.add(_UpcomingRow(
        icon: Icons.arrow_downward_rounded,
        color: DashColors.income,
        title: p.name,
        subtitle:
            '${l.dashExpectedIncomeOn} · ${l.autoDay} ${p.dayOfMonth}',
        amount: '+${fmt.format(p.amount)}',
        action: awaiting
            ? TextButton(
                onPressed: () async {
                  final ok = await ref
                      .read(automationRepositoryProvider)
                      .markReceived(p.id!, key);
                  if (ok && context.mounted) showSnack(context, l.autoReceived);
                },
                child: Text(l.autoMarkReceived),
              )
            : null,
      ));
    }
    final end = DateUtilsX.monthEnd(m);
    for (final r in recurring) {
      // Recurring templates advance their next date once generated, so any
      // active template dated inside the month is still upcoming.
      if (!r.active || r.nextDate.isAfter(end) || r.nextDate.isBefore(m)) {
        continue;
      }
      rows.add(_UpcomingRow(
        icon: Icons.event_repeat_outlined,
        color: DashColors.expense,
        title: r.name,
        subtitle:
            '${l.dashFixedDue} · ${r.nextDate.day} ${context.monthName(r.nextDate.month)}',
        amount: '-${fmt.format(r.amount)}',
      ));
    }

    return Card(
      elevation: 0,
      color: scheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: scheme.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(l.dashUpcoming,
                style:
                    const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            if (rows.isEmpty)
              Text(l.dashNothingUpcoming,
                  style:
                      TextStyle(fontSize: 13, color: scheme.onSurfaceVariant))
            else
              ...rows,
          ],
        ),
      ),
    );
  }
}

class _UpcomingRow extends StatelessWidget {
  const _UpcomingRow({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.amount,
    this.action,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final String amount;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w700)),
                Text(subtitle,
                    style: TextStyle(
                        fontSize: 11, color: scheme.onSurfaceVariant)),
              ],
            ),
          ),
          Text(amount,
              style: TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w800, color: color)),
          if (action != null) action!,
        ],
      ),
    );
  }
}
