/// A savings goal. [saved] is computed from the transaction history.
class SavingsGoal {
  const SavingsGoal({
    this.id,
    required this.name,
    required this.target,
    required this.color,
    required this.icon,
    this.note,
  });

  final int? id;
  final String name;
  final double target;
  final int color;
  final String icon;
  final String? note;

  SavingsGoal copyWith({String? name, double? target, int? color, String? icon, String? note}) =>
      SavingsGoal(
        id: id,
        name: name ?? this.name,
        target: target ?? this.target,
        color: color ?? this.color,
        icon: icon ?? this.icon,
        note: note ?? this.note,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'target': target,
        'color': color,
        'icon': icon,
        'note': note,
      };

  factory SavingsGoal.fromMap(Map<String, Object?> map) => SavingsGoal(
        id: map['id'] as int?,
        name: map['name'] as String,
        target: (map['target'] as num).toDouble(),
        color: (map['color'] as int?) ?? 0xFF6C4DF6,
        icon: (map['icon'] as String?) ?? 'savings',
        note: map['note'] as String?,
      );
}
