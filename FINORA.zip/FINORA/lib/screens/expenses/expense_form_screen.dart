import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/expense.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Add / edit an expense with full fields (amount, category, date/time,
/// note, payment method). The quick-add sheet is the faster path; this is
/// the complete form.
class ExpenseFormScreen extends ConsumerStatefulWidget {
  const ExpenseFormScreen({super.key, this.expense});

  final Expense? expense;

  @override
  ConsumerState<ExpenseFormScreen> createState() => _ExpenseFormScreenState();
}

class _ExpenseFormScreenState extends ConsumerState<ExpenseFormScreen> {
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  DateTime _date = DateTime.now();
  int? _categoryId;
  String? _paymentMethod;
  bool _saving = false;

  bool get _isEdit => widget.expense != null;

  @override
  void initState() {
    super.initState();
    final e = widget.expense;
    if (e != null) {
      _amountCtrl.text = e.amount.toStringAsFixed(2);
      _noteCtrl.text = e.note ?? '';
      _date = e.date;
      _categoryId = e.categoryId;
      _paymentMethod = e.paymentMethod;
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _save(int categoryId) async {
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final repo = ref.read(financeRepositoryProvider);
    final expense = Expense(
      id: widget.expense?.id,
      amount: amount,
      categoryId: categoryId,
      date: _date,
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
      paymentMethod: _paymentMethod,
      recurringSourceId: widget.expense?.recurringSourceId,
    );
    try {
      if (_isEdit) {
        await repo.updateExpense(expense);
      } else {
        await repo.addExpense(expense);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final catsAsync = ref.watch(categoriesProvider);

    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.expEdit : l.expAdd)),
      body: catsAsync.when(
        data: (cats) {
          if (_categoryId == null && cats.isNotEmpty) {
            _categoryId = cats.first.id;
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              AmountField(controller: _amountCtrl, hint: '0.00'),
              const SizedBox(height: 16),
              Text(l.commonCategory,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in cats)
                    CategoryChip(
                      category: c,
                      selected: _categoryId == c.id,
                      onTap: () => setState(() => _categoryId = c.id),
                    ),
                ],
              ),
              const SizedBox(height: 20),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_month_outlined),
                title: Text(l.commonDate,
                    style: const TextStyle(fontSize: 14)),
                trailing: Text(
                  '${_date.day} ${context.monthName(_date.month)} ${_date.year}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) setState(() => _date = picked);
                },
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _noteCtrl,
                decoration: InputDecoration(
                  labelText: '${l.commonNote} (${l.commonOptional})',
                  prefixIcon: const Icon(Icons.notes_outlined),
                ),
              ),
              const SizedBox(height: 14),
              Text(l.expPaymentMethod,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final m in PaymentMethods.all)
                    ChoiceChip(
                      label: Text(context.paymentLabel(m)),
                      selected: _paymentMethod == m,
                      onSelected: (_) =>
                          setState(() => _paymentMethod = m),
                    ),
                ],
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _saving || _categoryId == null
                    ? null
                    : () => _save(_categoryId!),
                style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15)),
                child: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(l.commonSave),
              ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }
}
