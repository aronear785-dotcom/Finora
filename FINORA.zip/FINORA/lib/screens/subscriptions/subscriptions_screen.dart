import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/subscription.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Subscriptions: totals (monthly / yearly estimate) + management.
class SubscriptionsScreen extends ConsumerWidget {
  const SubscriptionsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final items = ref.watch(subscriptionsProvider).valueOrNull ?? const [];
    final totals = ref.watch(subscriptionTotalsProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(title: Text(l.subTitle)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => const SubscriptionFormScreen()));
        },
        icon: const Icon(Icons.add),
        label: Text(l.subAdd),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          Card(
            elevation: 0,
            color: scheme.primaryContainer.withValues(alpha: 0.35),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.subMonthlyCost,
                            style: TextStyle(
                                fontSize: 12,
                                color: scheme.onSurfaceVariant)),
                        const SizedBox(height: 4),
                        Text(
                          totals != null
                              ? fmt.format(totals.monthly)
                              : fmt.format(0),
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: scheme.primary),
                        ),
                      ],
                    ),
                  ),
                  Container(width: 1, height: 40, color: scheme.outlineVariant),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(l.subYearlyCost,
                            style: TextStyle(
                                fontSize: 12,
                                color: scheme.onSurfaceVariant)),
                        const SizedBox(height: 4),
                        Text(
                          totals != null
                              ? fmt.format(totals.yearly)
                              : fmt.format(0),
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: scheme.primary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (items.isEmpty)
            EmptyState(
              icon: Icons.subscriptions_outlined,
              title: l.subEmpty,
              action: FilledButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const SubscriptionFormScreen())),
                icon: const Icon(Icons.add),
                label: Text(l.subAdd),
              ),
            )
          else
            for (final s in items)
              Card(
                elevation: 0,
                color: scheme.surface,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                  leading: Icon(
                    s.active
                        ? Icons.subscriptions_outlined
                        : Icons.subscriptions,
                    color: s.active ? scheme.primary : scheme.outline,
                  ),
                  title: Text(s.name,
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          decoration:
                              s.active ? null : TextDecoration.lineThrough)),
                  subtitle: Text(
                      '${s.period == 'monthly' ? l.recMonthly : l.recYearly} · '
                      '${s.nextBilling != null ? '${s.nextBilling!.day} ${context.monthName(s.nextBilling!.month)}' : ''}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('-${fmt.formatCompact(s.amount)}',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: scheme.error)),
                      PopupMenuButton<String>(
                        onSelected: (v) async {
                          switch (v) {
                            case 'edit':
                              await Navigator.of(context).push(
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          SubscriptionFormScreen(sub: s)));
                            case 'toggle':
                              await ref
                                  .read(planningRepositoryProvider)
                                  .updateSubscription(
                                      s.copyWith(active: !s.active));
                            case 'delete':
                              final ok = await confirmDialog(context,
                                  title: l.commonDelete,
                                  message: l.commonDeleteConfirm,
                                  confirmLabel: l.commonDelete,
                                  destructive: true);
                              if (ok) {
                                await ref
                                    .read(planningRepositoryProvider)
                                    .deleteSubscription(s.id!);
                              }
                          }
                        },
                        itemBuilder: (_) => [
                          PopupMenuItem(
                              value: 'edit', child: Text(l.commonEdit)),
                          PopupMenuItem(
                              value: 'toggle',
                              child: Text(s.active
                                  ? l.subDeactivate
                                  : l.subActivate)),
                          PopupMenuItem(
                              value: 'delete', child: Text(l.commonDelete)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

/// Add / edit a subscription.
class SubscriptionFormScreen extends ConsumerStatefulWidget {
  const SubscriptionFormScreen({super.key, this.sub});

  final Subscription? sub;

  @override
  ConsumerState<SubscriptionFormScreen> createState() =>
      _SubscriptionFormScreenState();
}

class _SubscriptionFormScreenState
    extends ConsumerState<SubscriptionFormScreen> {
  final _nameCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  String _period = 'monthly';
  bool _active = true;
  bool _saving = false;

  bool get _isEdit => widget.sub != null;

  @override
  void initState() {
    super.initState();
    final s = widget.sub;
    if (s != null) {
      _nameCtrl.text = s.name;
      _amountCtrl.text = s.amount.toStringAsFixed(2);
      _period = s.period;
      _active = s.active;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (name.isEmpty) {
      showSnack(context, context.l10n.errEmptyField);
      return;
    }
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final sub = Subscription(
      id: widget.sub?.id,
      name: name,
      amount: amount,
      period: _period,
      active: _active,
      nextBilling: DateTime.now().add(const Duration(days: 30)),
    );
    final repo = ref.read(planningRepositoryProvider);
    try {
      if (_isEdit) {
        await repo.updateSubscription(sub);
      } else {
        await repo.addSubscription(sub);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.subEdit : l.subAdd)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _nameCtrl,
            decoration: InputDecoration(
              labelText: l.commonName,
              prefixIcon: const Icon(Icons.subscriptions_outlined),
            ),
          ),
          const SizedBox(height: 14),
          AmountField(controller: _amountCtrl, hint: '0.00'),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _period,
            decoration: InputDecoration(labelText: l.subInterval),
            items: [
              DropdownMenuItem(value: 'monthly', child: Text(l.recMonthly)),
              DropdownMenuItem(value: 'yearly', child: Text(l.recYearly)),
            ],
            onChanged: (v) => v != null
                ? setState(() => _period = v)
                : null,
          ),
          const SizedBox(height: 14),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(l.recActive,
                style: const TextStyle(fontSize: 14)),
            value: _active,
            onChanged: (v) => setState(() => _active = v),
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: _saving ? null : _save,
            style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15)),
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : Text(l.commonSave),
          ),
        ],
      ),
    );
  }
}
