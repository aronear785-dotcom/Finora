import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../models/income.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Add / edit an income record. All fields validated; nothing is faked.
class IncomeFormScreen extends ConsumerStatefulWidget {
  const IncomeFormScreen({super.key, this.income});

  final Income? income;

  @override
  ConsumerState<IncomeFormScreen> createState() => _IncomeFormScreenState();
}

class _IncomeFormScreenState extends ConsumerState<IncomeFormScreen> {
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  DateTime _date = DateTime.now();
  int? _categoryId;
  bool _recurring = false;
  bool _saving = false;

  bool get _isEdit => widget.income != null;

  @override
  void initState() {
    super.initState();
    final i = widget.income;
    if (i != null) {
      _amountCtrl.text = i.amount.toStringAsFixed(2);
      _noteCtrl.text = i.note ?? '';
      _date = i.date;
      _categoryId = i.categoryId;
      _recurring = i.isRecurring;
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _save(int categoryId) async {
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final repo = ref.read(financeRepositoryProvider);
    final income = Income(
      id: widget.income?.id,
      amount: amount,
      categoryId: categoryId,
      date: _date,
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
      isRecurring: _recurring,
    );
    try {
      if (_isEdit) {
        await repo.updateIncome(income);
      } else {
        await repo.addIncome(income);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final catsAsync = ref.watch(incomeCategoriesProvider);

    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.incEdit : l.incAdd)),
      body: catsAsync.when(
        data: (cats) {
          if (_categoryId == null && cats.isNotEmpty) {
            _categoryId = cats.first.id;
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              AmountField(
                  controller: _amountCtrl, hint: '0.00'),
              const SizedBox(height: 16),
              Text(l.commonCategory,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in cats)
                    CategoryChip(
                      category: c,
                      selected: _categoryId == c.id,
                      onTap: () => setState(() => _categoryId = c.id),
                    ),
                ],
              ),
              const SizedBox(height: 20),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_month_outlined),
                title: Text(l.commonDate,
                    style: const TextStyle(fontSize: 14)),
                trailing: Text(
                  '${_date.day} ${context.monthName(_date.month)} ${_date.year}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) setState(() => _date = picked);
                },
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _noteCtrl,
                decoration: InputDecoration(
                  labelText: '${l.commonNote} (${l.commonOptional})',
                  prefixIcon: const Icon(Icons.notes_outlined),
                ),
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(l.incRecurring,
                    style: const TextStyle(fontSize: 14)),
                value: _recurring,
                onChanged: (v) => setState(() => _recurring = v),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed:
                    _saving || _categoryId == null ? null : () => _save(_categoryId!),
                style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15)),
                child: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(l.commonSave),
              ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }
}
