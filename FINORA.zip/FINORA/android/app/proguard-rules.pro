# FINORA release build rules.
# The app does not use code obfuscation or reflection-based libraries,
# so no extra keep rules are required for the default configuration.
