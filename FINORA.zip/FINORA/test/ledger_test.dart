import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:finora/database/app_database.dart';
import 'package:finora/domain/ledger_calculator.dart';
import 'package:finora/domain/money.dart';
import 'package:finora/models/budget.dart';
import 'package:finora/models/category.dart';
import 'package:finora/models/expense.dart';
import 'package:finora/models/income.dart';
import 'package:finora/models/savings_goal.dart';
import 'package:finora/models/savings_transaction.dart';
import 'package:finora/repositories/automation_repository.dart';
import 'package:finora/repositories/finance_repository.dart';
import 'package:finora/repositories/planning_repository.dart';

/// Financial business rules: fixed vs variable expenses, budgets, income
/// breakdown, savings, loans and decimal-safe arithmetic.
void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  final month = DateTime(2026, 3, 1);
  const monthKey = '2026-03';

  late AppDatabase db;
  late FinanceRepository finance;
  late PlanningRepository planning;
  late int food, rent, salary, freelance, loanIncome, other;
  late int goalId;

  Future<MonthLedger> ledger(AppDatabase d, {double expected = 0, double planned = 0}) async {
    final f = FinanceRepository(db: d);
    final p = PlanningRepository(db: d);
    final end = DateTime(2026, 3, 31, 23, 59, 59);
    return LedgerCalculator.build(
      incomes: await f.incomeBetween(month, end),
      expenses: await f.expensesBetween(month, end),
      savings: await p.savingsTransactionsBetween(month, end),
      categories: [...await f.categories(), ...await f.categories(income: true)],
      budgets: await p.budgetsForMonth(monthKey),
      expectedIncome: expected,
      plannedSavings: planned,
    );
  }

  Future<void> seed(AppDatabase d) async {
    final f = FinanceRepository(db: d);
    final p = PlanningRepository(db: d);
    food = await f.addCategory(const Category(name: 'food', icon: 'food', color: 0xFFFFB300));
    rent = await f.addCategory(const Category(
        name: 'rent', icon: 'home', color: 0xFF6C4DF6, expenseType: ExpenseType.fixed));
    salary = await f.addCategory(const Category(
        name: 'salary', icon: 'work', color: 0xFF66BB6A, isIncome: true));
    freelance = await f.addCategory(const Category(
        name: 'freelance', icon: 'laptop', color: 0xFF4C8DF6, isIncome: true));
    loanIncome = await f.addCategory(const Category(
        name: 'loan', icon: 'bank', color: 0xFF8E24AA, isIncome: true));
    other = await f.addCategory(const Category(
        name: 'other', icon: 'more', color: 0xFF9E9E9E, isIncome: true));
    goalId = await p.addSavingsGoal(const SavingsGoal(
        name: 'House', target: 100000, color: 0xFF6C4DF6, icon: 'house'));
    await p.setBudget(Budget(categoryId: food, amount: 1500, month: monthKey));
    await f.addIncome(Income(
        amount: 8000, categoryId: salary, date: DateTime(2026, 3, 1)));
  }

  setUp(() async {
    db = AppDatabase.forPath(inMemoryDatabasePath);
    finance = FinanceRepository(db: db);
    planning = PlanningRepository(db: db);
    await seed(db);
  });

  tearDown(() async {
    await db.close();
  });

  test('1. variable food expense reduces only the food budget and available',
      () async {
    final before = await ledger(db);
    await finance.addExpense(
        Expense(amount: 100, categoryId: food, date: DateTime(2026, 3, 5)));
    final after = await ledger(db);

    final line = after.budgetLines.single;
    expect(line.limit, 1500);
    expect(line.spent, 100);
    expect(line.remaining, 1400);
    expect(after.totalExpenses, 100);
    expect(after.variableExpenses, 100);
    expect(after.fixedExpenses, 0);
    expect(after.available, before.available - 100);
  });

  test('2. fixed rent increases expenses but never touches the food budget',
      () async {
    await finance.addExpense(
        Expense(amount: 3000, categoryId: rent, date: DateTime(2026, 3, 2)));
    final l = await ledger(db);
    expect(l.totalExpenses, 3000);
    expect(l.fixedExpenses, 3000);
    expect(l.variableExpenses, 0);
    expect(l.budgetLines.single.spent, 0);
    expect(l.budgetLines.single.remaining, 1500);
    expect(l.available, 5000);
  });

  test('3 & 4. editing recalculates and deleting reverses the effects',
      () async {
    final id = await finance.addExpense(
        Expense(amount: 100, categoryId: food, date: DateTime(2026, 3, 5)));
    await finance.updateExpense(Expense(
        id: id, amount: 250, categoryId: food, date: DateTime(2026, 3, 5)));
    var l = await ledger(db);
    expect(l.budgetLines.single.spent, 250);
    expect(l.available, 7750);

    await finance.deleteExpense(id);
    l = await ledger(db);
    expect(l.budgetLines.single.spent, 0);
    expect(l.totalExpenses, 0);
    expect(l.available, 8000);
  });

  test('5. reclassifying an expense moves its budget impact', () async {
    final id = await finance.addExpense(
        Expense(amount: 400, categoryId: food, date: DateTime(2026, 3, 5)));
    var l = await ledger(db);
    expect(l.budgetLines.single.spent, 400);
    expect(l.fixedExpenses, 0);

    await finance.updateExpense(Expense(
        id: id, amount: 400, categoryId: rent, date: DateTime(2026, 3, 5)));
    l = await ledger(db);
    expect(l.budgetLines.single.spent, 0); // food budget no longer charged
    expect(l.fixedExpenses, 400); // now a fixed obligation
    expect(l.totalExpenses, 400); // counted exactly once
  });

  test('a category cannot be fixed AND carry a variable budget', () async {
    await expectLater(
        planning.setBudget(Budget(categoryId: rent, amount: 100, month: monthKey)),
        throwsA(isA<FixedCategoryBudgetException>()));
    final foodCat = (await finance.categories()).firstWhere((c) => c.id == food);
    await expectLater(
        finance.updateCategory(foodCat.copyWith(expenseType: ExpenseType.fixed)),
        throwsA(isA<FixedCategoryHasBudgetException>()));
  });

  test('7. expected income never counts as received income or cash', () async {
    final l = await ledger(db, expected: 5000);
    expect(l.expectedIncome, 5000);
    expect(l.receivedIncome, 8000);
    expect(l.available, 8000);
  });

  test('8 & 9. planned savings are not savings; a transfer is deducted once',
      () async {
    var l = await ledger(db, planned: 800);
    expect(l.plannedSavings, 800);
    expect(l.actualSavings, 0);
    expect(l.available, 8000);

    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: goalId, amount: 800, date: DateTime(2026, 3, 1)));
    l = await ledger(db, planned: 800);
    expect(l.actualSavings, 800);
    expect(l.totalExpenses, 0); // not an expense as well
    expect(l.available, 7200); // 8000 - 800, once

    // Withdrawing gives the money back.
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: goalId, amount: -300, date: DateTime(2026, 3, 9)));
    l = await ledger(db);
    expect(l.actualSavings, 500);
    expect(l.available, 7500);
  });

  test('11 & 12. loans are separate from earned income and the breakdown reconciles',
      () async {
    await finance.addIncome(Income(
        amount: 1200.50, categoryId: freelance, date: DateTime(2026, 3, 8)));
    await finance.addIncome(Income(
        amount: 300, categoryId: other, date: DateTime(2026, 3, 9)));
    await finance.addIncome(Income(
        amount: 5000, categoryId: loanIncome, date: DateTime(2026, 3, 10)));
    final l = await ledger(db);

    double of(IncomeGroup g) =>
        l.incomeGroups.firstWhere((x) => x.group == g).amount;
    expect(of(IncomeGroup.salary), 8000);
    expect(of(IncomeGroup.freelance), 1200.50);
    expect(of(IncomeGroup.extra), 300);
    expect(of(IncomeGroup.loan), 5000);
    expect(l.loanIncome, 5000);
    expect(l.earnedIncome, 9500.50); // loans are not earned income

    // The breakdown adds up to the dashboard "Revenus" total, to the cent.
    expect(Money.sum(l.incomeGroups.map((g) => g.amount)), l.receivedIncome);
    expect(l.receivedIncome, 14500.50);
  });

  test('a bank loan installment is a fixed obligation', () async {
    final loan = await finance.addCategory(const Category(
        name: 'loan', icon: 'bank', color: 0xFFB71C1C, expenseType: ExpenseType.fixed));
    await finance.addExpense(
        Expense(amount: 1500, categoryId: loan, date: DateTime(2026, 3, 3)));
    final l = await ledger(db);
    expect(l.fixedExpenses, 1500);
    expect(l.budgetLines.single.spent, 0);
  });

  test('over-budget spending is a warning state, not an invalid percentage',
      () async {
    await finance.addExpense(
        Expense(amount: 1800, categoryId: food, date: DateTime(2026, 3, 6)));
    final line = (await ledger(db)).budgetLines.single;
    expect(line.isOver, isTrue);
    expect(line.remaining, -300);
    expect(line.progress, 1.0); // bar is clamped
    expect(line.percent, closeTo(120, 0.001)); // label shows the real value
  });

  test('13. budgets and totals are identical after an app restart', () async {
    final dir = await Directory.systemTemp.createTemp('finora_test');
    final path = '${dir.path}/restart.db';
    var d = AppDatabase.forPath(path);
    await seed(d);
    await FinanceRepository(db: d).addExpense(
        Expense(amount: 35, categoryId: food, date: DateTime(2026, 3, 7)));
    final before = await ledger(d);
    await d.close();

    d = AppDatabase.forPath(path); // "restart"
    final after = await ledger(d);
    expect(after.budgetLines.single.spent, before.budgetLines.single.spent);
    expect(after.budgetLines.single.remaining, 1465);
    expect(after.available, before.available);
    await d.close();
    await dir.delete(recursive: true);
  });

  test('14. insufficient funds need explicit confirmation', () {
    expect(LedgerCalculator.needsOverdrawConfirmation(100, 100.01), isTrue);
    expect(LedgerCalculator.needsOverdrawConfirmation(100, 100), isFalse);
    expect(LedgerCalculator.needsOverdrawConfirmation(-5, 1), isTrue);
  });

  test('15. money arithmetic has no floating-point drift', () {
    expect(0.1 + 0.2 == 0.3, isFalse); // plain doubles drift...
    expect(Money.sum([0.1, 0.2]), 0.3); // ...cents do not
    expect(Money.sum(List.filled(10, 0.1)), 1.0);
    expect(Money.subtract(1000.10, 1000.05), 0.05);
    expect(Money.exceeds(0.30000000000000004, 0.3), isFalse);
  });

  test('variable spending totals exclude fixed expenses', () async {
    await finance.addExpense(
        Expense(amount: 35, categoryId: food, date: DateTime(2026, 3, 4, 12)));
    await finance.addExpense(
        Expense(amount: 3000, categoryId: rent, date: DateTime(2026, 3, 4, 13)));
    final cats = await finance.categories();
    final exp = await finance.allExpenses();
    expect(
        LedgerCalculator.variableSpendingBetween(exp, cats,
            DateTime(2026, 3, 4), DateTime(2026, 3, 4, 23, 59, 59)),
        35);
  });

  test('7b. monthly recurrence handles February, leap years and day 31', () {
    expect(AutomationRepository.occurrence(DateTime(2028, 2, 1), 30),
        DateTime(2028, 2, 29)); // leap year
    expect(AutomationRepository.occurrence(DateTime(2027, 2, 1), 30),
        DateTime(2027, 2, 28));
    expect(AutomationRepository.occurrence(DateTime(2026, 4, 1), 31),
        DateTime(2026, 4, 30));
    expect(AutomationRepository.occurrence(DateTime(2026, 3, 1), 25),
        DateTime(2026, 3, 25));
  });
}
