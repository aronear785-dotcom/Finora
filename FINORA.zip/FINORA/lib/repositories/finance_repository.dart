import 'package:sqflite/sqflite.dart';

import '../core/utils/app_bus.dart';
import '../database/app_database.dart';
import '../models/category.dart';
import '../models/expense.dart';
import '../models/income.dart';

/// Data access for categories, income, expenses, budgets, savings.
/// Every write touches [AppBus] so providers refetch and the UI updates.
class FinanceRepository {
  FinanceRepository({AppDatabase? db}) : _db = db ?? AppDatabase.instance;

  final AppDatabase _db;

  Future<Database> get _database => _db.database;

  // ---------------------------------------------------------------- categories
  Future<List<Category>> categories({bool income = false}) async {
    final db = await _database;
    final rows = await db.query(
      'categories',
      where: income ? 'is_income = 1' : 'is_income = 0',
      orderBy: 'is_custom ASC, id ASC',
    );
    return rows.map(Category.fromMap).toList();
  }

  Future<int> addCategory(Category c) async {
    final db = await _database;
    final id = await db.insert('categories', c.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<int> updateCategory(Category c) async {
    final db = await _database;
    final id = await db.update('categories', c.toMap(),
        where: 'id = ?', whereArgs: [c.id]);
    AppBus.instance.bump();
    return id;
  }

  /// Deletes a category only when it is unused, otherwise throws.
  Future<void> deleteCategory(int id) async {
    final db = await _database;
    final expenseCount = Sqflite.firstIntValue(await db.rawQuery(
        'SELECT COUNT(*) FROM expenses WHERE category_id = ?', [id]));
    final incomeCount = Sqflite.firstIntValue(await db.rawQuery(
        'SELECT COUNT(*) FROM income WHERE category_id = ?', [id]));
    final budgetCount = Sqflite.firstIntValue(await db.rawQuery(
        'SELECT COUNT(*) FROM budgets WHERE category_id = ?', [id]));
    final recurringCount = Sqflite.firstIntValue(await db.rawQuery(
        'SELECT COUNT(*) FROM recurring_expenses WHERE category_id = ?', [id]));
    final subCount = Sqflite.firstIntValue(await db.rawQuery(
        'SELECT COUNT(*) FROM subscriptions WHERE category_id = ?', [id]));
    if ((expenseCount ?? 0) > 0 ||
        (incomeCount ?? 0) > 0 ||
        (budgetCount ?? 0) > 0 ||
        (recurringCount ?? 0) > 0 ||
        (subCount ?? 0) > 0) {
      throw CategoryInUseException();
    }
    await db.delete('categories', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  // ------------------------------------------------------------------- income
  Future<List<Income>> incomeBetween(DateTime start, DateTime end) async {
    final db = await _database;
    final rows = await db.query(
      'income',
      where: 'date >= ? AND date <= ?',
      whereArgs: [start.millisecondsSinceEpoch, end.millisecondsSinceEpoch],
      orderBy: 'date DESC',
    );
    return rows.map(Income.fromMap).toList();
  }

  Future<List<Income>> allIncome() async {
    final db = await _database;
    final rows = await db.query('income', orderBy: 'date DESC');
    return rows.map(Income.fromMap).toList();
  }

  Future<int> addIncome(Income income) async {
    final db = await _database;
    final id = await db.insert('income', income.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<int> updateIncome(Income income) async {
    final db = await _database;
    final id = await db
        .update('income', income.toMap(), where: 'id = ?', whereArgs: [income.id]);
    AppBus.instance.bump();
    return id;
  }

  Future<void> deleteIncome(int id) async {
    final db = await _database;
    await db.delete('income', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  // ------------------------------------------------------------------ expenses
  Future<List<Expense>> expensesBetween(DateTime start, DateTime end) async {
    final db = await _database;
    final rows = await db.query(
      'expenses',
      where: 'date >= ? AND date <= ?',
      whereArgs: [start.millisecondsSinceEpoch, end.millisecondsSinceEpoch],
      orderBy: 'date DESC',
    );
    return rows.map(Expense.fromMap).toList();
  }

  Future<List<Expense>> expensesOnDay(DateTime day) =>
      expensesBetween(day, day.add(const Duration(days: 1, milliseconds: -1)));

  Future<List<Expense>> expensesInMonth(int year, int month) =>
      expensesBetween(
        DateTime(year, month, 1),
        DateTime(year, month + 1, 0, 23, 59, 59),
      );

  Future<List<Expense>> allExpenses() async {
    final db = await _database;
    final rows = await db.query('expenses', orderBy: 'date DESC');
    return rows.map(Expense.fromMap).toList();
  }

  Future<int> addExpense(Expense expense) async {
    final db = await _database;
    final id = await db.insert('expenses', expense.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<int> updateExpense(Expense expense) async {
    final db = await _database;
    final id = await db.update('expenses', expense.toMap(),
        where: 'id = ?', whereArgs: [expense.id]);
    AppBus.instance.bump();
    return id;
  }

  Future<void> deleteExpense(int id) async {
    final db = await _database;
    await db.delete('expenses', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  // -------------------------------------------------- generic combined search
  /// Text search across transactions: expenses + income (lightweight,
  /// used by the Search screen - fully offline).
  Future<List<Map<String, Object?>>> searchAll({
    String? query,
    DateTime? from,
    DateTime? to,
    int? categoryId,
    bool expensesOnly = false,
  }) async {
    final db = await _database;
    final results = <Map<String, Object?>>[];
    final q = query == null ? null : query.trim();

    final eWhere = <String>[];
    final eArgs = <Object?>[];
    if (q != null && q.isNotEmpty) {
      eWhere.add('(note LIKE ? OR amount LIKE ? OR category_id IN '
          '(SELECT id FROM categories WHERE name LIKE ?))');
      eArgs.add('%$q%');
      eArgs.add('%$q%');
      eArgs.add('%$q%');
    }
    if (from != null) {
      eWhere.add('date >= ?');
      eArgs.add(from.millisecondsSinceEpoch);
    }
    if (to != null) {
      eWhere.add('date <= ?');
      eArgs.add(to.millisecondsSinceEpoch);
    }
    if (categoryId != null) {
      eWhere.add('category_id = ?');
      eArgs.add(categoryId);
    }
    final eRows = await db.query(
      'expenses',
      where: eWhere.isEmpty ? null : eWhere.join(' AND '),
      whereArgs: eArgs.isEmpty ? null : eArgs,
      orderBy: 'date DESC',
    );
    for (final r in eRows) {
      results.add({'type': 'expense', ...r});
    }

    if (!expensesOnly) {
      final iWhere = <String>[];
      final iArgs = <Object?>[];
      if (q != null && q.isNotEmpty) {
        iWhere.add('(note LIKE ? OR amount LIKE ? OR category_id IN '
            '(SELECT id FROM categories WHERE name LIKE ?))');
        iArgs.add('%$q%');
        iArgs.add('%$q%');
        iArgs.add('%$q%');
      }
      if (from != null) {
        iWhere.add('date >= ?');
        iArgs.add(from.millisecondsSinceEpoch);
      }
      if (to != null) {
        iWhere.add('date <= ?');
        iArgs.add(to.millisecondsSinceEpoch);
      }
      if (categoryId != null) {
        iWhere.add('category_id = ?');
        iArgs.add(categoryId);
      }
      final iRows = await db.query(
        'income',
        where: iWhere.isEmpty ? null : iWhere.join(' AND '),
        whereArgs: iArgs.isEmpty ? null : iArgs,
        orderBy: 'date DESC',
      );
      for (final r in iRows) {
        results.add({'type': 'income', ...r});
      }
    }

    results.sort((a, b) => (b['date'] as int).compareTo(a['date'] as int));
    return results;
  }
}

/// Thrown when a category that historical data depends on is deleted.
class CategoryInUseException implements Exception {
  const CategoryInUseException();
}
