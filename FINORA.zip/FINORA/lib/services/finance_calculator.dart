import '../models/budget.dart';
import '../models/expense.dart';
import '../models/income.dart';
import '../models/savings_transaction.dart';

/// Pure financial formulas. Every calculation the UI shows goes through
/// this class so it can be unit-tested. Division by zero is prevented and
/// negative values are handled explicitly.
class FinanceCalculator {
  FinanceCalculator._();

  /// Total income = sum of income records.
  static double totalIncome(List<Income> records) =>
      records.fold(0, (sum, r) => sum + r.amount);

  /// Total expenses = sum of expense records.
  static double totalExpenses(List<Expense> records) =>
      records.fold(0, (sum, r) => sum + r.amount);

  /// Savings = sum of signed savings transactions (withdrawals reduce it).
  static double totalSaved(List<SavingsTransaction> records) =>
      records.fold(0, (sum, r) => sum + r.amount);

  /// Available = Income - Expenses - Savings.
  static double available(double income, double expenses, double savings) =>
      income - expenses - savings;

  /// Budget progress in percent, clamped >= 0. No division by zero.
  static double budgetProgress(double spent, double budget) =>
      budget <= 0 ? 0 : (spent / budget * 100).clamp(0, double.infinity);

  /// Remaining budget (can be negative when over budget).
  static double remainingBudget(double budget, double spent) => budget - spent;

  static BudgetStatus budgetStatus(double spent, double budget, double warnAt) {
    if (budget <= 0) return BudgetStatus.normal;
    final ratio = spent / budget;
    if (ratio >= 1) return BudgetStatus.exceeded;
    if (ratio >= (warnAt / 100)) return BudgetStatus.approaching;
    return BudgetStatus.normal;
  }

  /// Savings goal progress in percent. Division by zero prevented.
  static double goalProgress(double saved, double target) =>
      target <= 0 ? 0 : (saved / target * 100).clamp(0, double.infinity);

  /// Savings plan: remaining amount, estimated months, estimated completion
  /// date. If monthly contribution is <= 0 the plan is unreachable.
  static SavingsPlanResult savingsPlan({
    required double target,
    required double current,
    required double monthly,
    DateTime? from,
  }) {
    final remaining = target - current;
    final base = from ?? DateTime.now();
    if (monthly <= 0 || remaining <= 0) {
      return SavingsPlanResult(
        remaining: remaining,
        months: monthly <= 0 ? null : 0,
        completionDate: remaining <= 0 && monthly > 0 ? base : null,
      );
    }
    final months = (remaining / monthly).ceil();
    return SavingsPlanResult(
      remaining: remaining,
      months: months,
      completionDate: DateTime(base.year, base.month + months, base.day),
    );
  }

  /// Automatic savings target = income * percentage / 100.
  static double automaticSavingsTarget(double income, double percent) =>
      income * (percent / 100);

  /// Expenses grouped per category id (real data only).
  static Map<int, double> expensesByCategory(List<Expense> records) {
    final out = <int, double>{};
    for (final e in records) {
      out[e.categoryId] = (out[e.categoryId] ?? 0) + e.amount;
    }
    return out;
  }

  /// Daily expense totals for each day between [start] and [end] inclusive
  /// (days without expenses are present with 0, so charts are honest).
  static Map<DateTime, double> dailyExpenses(
    List<Expense> records,
    DateTime start,
    DateTime end,
  ) {
    final out = <DateTime, double>{};
    var day = DateTime(start.year, start.month, start.day);
    final last = DateTime(end.year, end.month, end.day);
    while (!day.isAfter(last)) {
      out[day] = 0;
      day = day.add(const Duration(days: 1));
    }
    for (final e in records) {
      final k = DateTime(e.date.year, e.date.month, e.date.day);
      if (out.containsKey(k)) out[k] = out[k]! + e.amount;
    }
    return out;
  }

  /// Month-over-month difference, returns null when the previous value is 0
  /// so the UI can display a clean empty state instead of a fake percentage.
  static double? percentageChange(double current, double previous) {
    if (previous == 0) return null;
    return (current - previous) / previous * 100;
  }
}

enum BudgetStatus { normal, approaching, exceeded }

class SavingsPlanResult {
  const SavingsPlanResult({
    required this.remaining,
    required this.months,
    required this.completionDate,
  });

  final double remaining;
  final int? months;
  final DateTime? completionDate;
}

/// Aggregate snapshot used by the dashboard & reports.
class MonthTotals {
  const MonthTotals({
    required this.income,
    required this.expenses,
    required this.savings,
    required this.available,
  });

  final double income;
  final double expenses;
  final double savings;
  final double available;

  factory MonthTotals.fromParts(
    double income,
    double expenses,
    double savings,
  ) =>
      MonthTotals(
        income: income,
        expenses: expenses,
        savings: savings,
        available: FinanceCalculator.available(income, expenses, savings),
      );
}
