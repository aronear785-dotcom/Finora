import 'package:sqflite/sqflite.dart';

import '../core/utils/app_bus.dart';
import '../database/app_database.dart';
import '../domain/money.dart';
import '../models/loan.dart';

/// Bank loans / credits. Installments are generated as FIXED expenses by
/// `AutomationRepository.applyDue` (one per month, recorded in
/// `loan_payments`, so they can never be duplicated).
class LoanRepository {
  LoanRepository({AppDatabase? db}) : _db = db ?? AppDatabase.instance;

  final AppDatabase _db;

  Future<Database> get _database => _db.database;

  /// Returns the built-in "loan" category id, creating it when missing:
  /// the EXPENSE one is a fixed obligation (installments), the INCOME one is
  /// money received (never earned income).
  static Future<int> ensureLoanCategory(DatabaseExecutor db,
      {required bool income}) async {
    final rows = await db.query('categories',
        columns: ['id'],
        where: 'name = ? AND is_income = ?',
        whereArgs: ['loan', income ? 1 : 0],
        limit: 1);
    if (rows.isNotEmpty) return rows.first['id'] as int;
    return db.insert('categories', {
      'name': 'loan',
      'icon': 'bank',
      'color': income ? 0xFF8E24AA : 0xFFB71C1C,
      'is_income': income ? 1 : 0,
      'is_custom': 0,
      'expense_type': income ? 'variable' : 'fixed',
      'created_at': AppDatabase.now(),
    });
  }

  Future<List<Loan>> loans() async {
    final db = await _database;
    final rows = await db.query('loans', orderBy: 'id ASC');
    return rows.map(Loan.fromMap).toList();
  }

  /// All loans with their repayment progress.
  Future<List<LoanStatus>> statuses() async {
    final db = await _database;
    final out = <LoanStatus>[];
    for (final loan in await loans()) {
      final rows = await db.rawQuery(
          'SELECT COUNT(*) AS n, COALESCE(SUM(CAST(ROUND(amount * 100) AS INTEGER)),0) AS s '
          'FROM loan_payments WHERE loan_id = ?',
          [loan.id]);
      out.add(LoanStatus(
        loan: loan,
        paidCount: (rows.first['n'] as num).toInt(),
        paidAmount: Money.fromCents((rows.first['s'] as num).toInt()),
      ));
    }
    return out;
  }

  /// Creates the loan. When [receivedOn] is given, the borrowed amount is
  /// also recorded as income in the separate "loan received" category.
  Future<int> addLoan(Loan loan, {DateTime? receivedOn}) async {
    final db = await _database;
    late int id;
    await db.transaction((txn) async {
      id = await txn.insert('loans', {
        ...loan.toMap(),
        'created_at': AppDatabase.now(),
      });
      if (receivedOn != null) {
        final catId = await ensureLoanCategory(txn, income: true);
        await txn.insert('income', {
          'amount': loan.principal,
          'category_id': catId,
          'date': receivedOn.millisecondsSinceEpoch,
          'note': loan.name,
          'recurring': 0,
          'created_at': AppDatabase.now(),
        });
      }
    });
    AppBus.instance.bump();
    return id;
  }

  /// Edits future installments only: installments already recorded keep
  /// their amounts.
  Future<void> updateLoan(Loan loan) async {
    final db = await _database;
    await db.update('loans', loan.toMap(), where: 'id = ?', whereArgs: [loan.id]);
    AppBus.instance.bump();
  }

  /// Deletes the loan and its payment ledger; installments already recorded
  /// stay in the expense history.
  Future<void> deleteLoan(int id) async {
    final db = await _database;
    await db.delete('loans', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }
}
