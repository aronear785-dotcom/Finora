import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../providers/providers.dart';
import '../../repositories/finance_repository.dart';
import '../../widgets/common_widgets.dart';
import 'category_form_dialog.dart';

/// Manage spending categories: create custom categories, edit icon/color,
/// delete only when nothing references them (safe handling).
class CategoriesScreen extends ConsumerWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final catsAsync = ref.watch(categoriesProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l.catManage)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => const CategoryFormDialog()));
        },
        icon: const Icon(Icons.add),
        label: Text(l.catAdd),
      ),
      body: catsAsync.when(
        data: (cats) => ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
          itemCount: cats.length,
          separatorBuilder: (_, __) => const SizedBox(height: 6),
          itemBuilder: (_, i) {
            final c = cats[i];
            final color = AppColors.fromInt(c.color);
            return Card(
              elevation: 0,
              color: scheme.surface,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
              child: ListTile(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
                leading: Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: Icon(AppIcons.resolve(c.icon),
                      size: 20, color: color),
                ),
                title: Text(context.categoryLabel(c.name),
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w600)),
                subtitle: Text(c.isCustom ? l.catCustom : ''),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (v == 'edit') {
                      await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => CategoryFormDialog(category: c)));
                    } else if (v == 'delete') {
                      final ok = await confirmDialog(context,
                          title: l.catDelete,
                          message: l.commonDeleteConfirm,
                          confirmLabel: l.commonDelete,
                          destructive: true);
                      if (ok) {
                        try {
                          await ref
                              .read(financeRepositoryProvider)
                              .deleteCategory(c.id!);
                        } on CategoryInUseException {
                          if (context.mounted) {
                            showSnack(context, l.catInUseMsg);
                          }
                        }
                      }
                    }
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'edit', child: Text(l.commonEdit)),
                    if (c.isCustom)
                      PopupMenuItem(
                          value: 'delete', child: Text(l.commonDelete)),
                  ],
                ),
              ),
            );
          },
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }
}
