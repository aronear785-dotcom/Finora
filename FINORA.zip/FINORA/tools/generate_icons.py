# FINORA launcher icon / logo generator.
import os
import os
import math
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "android", "app", "src", "main", "res")
ASSETS = os.path.join(ROOT, "assets", "images")

PRIMARY = (108, 77, 246, 255)      # FINORA brand violet
DARK = (35, 31, 60, 255)

def rounded_rect_mask(size, radius):
    img = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    return img

def draw_logo(size, bg_color, fg_color):
    """FINORA 'F' monogram on a rounded square."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    mask = rounded_rect_mask(size, int(size * 0.22))
    bg = Image.new("RGBA", (size, size), bg_color)
    img.paste(bg, (0, 0), mask)

    d = ImageDraw.Draw(img)
    pad = size * 0.24
    w = size * 0.52
    h = size * 0.46
    x0, y0 = (size - w) / 2, (size - h) / 2 - size * 0.02

    # Vertical bar + two horizontal bars + baseline = "F"
    bar_w = w * 0.30
    d.rounded_rectangle([x0, y0, x0 + bar_w, y0 + h], radius=size*0.03, fill=fg_color)
    d.rounded_rectangle([x0 + bar_w*0.75, y0, x0 + w, y0 + h*0.26], radius=size*0.03, fill=fg_color)
    d.rounded_rectangle([x0 + bar_w*0.75, y0 + h*0.42, x0 + w*0.78, y0 + h*0.62], radius=size*0.03, fill=fg_color)
    return img

sizes = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

os.makedirs(ASSETS, exist_ok=True)
for folder, size in sizes.items():
    d = os.path.join(RES, folder)
    os.makedirs(d, exist_ok=True)
    logo = draw_logo(size, PRIMARY, (255, 255, 255, 255))
    logo.save(os.path.join(d, "ic_launcher.png"))
    print("wrote", os.path.join(d, "ic_launcher.png"))

# In-app logo (1024px) used by splash / onboarding / about
logo = draw_logo(1024, PRIMARY, (255, 255, 255, 255))
logo.save(os.path.join(ASSETS, "logo.png"))
print("wrote", os.path.join(ASSETS, "logo.png"))
print("DONE")
