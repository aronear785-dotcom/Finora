import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/date_utils.dart';
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/plan_run.dart';
import '../../models/recurring_income.dart';
import '../../models/savings_goal.dart';
import '../../models/savings_plan.dart';
import '../../providers/providers.dart';
import '../../providers/savings_providers.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/plan_summary_card.dart';
import '../loans/loans_screen.dart';
import 'automation_forms.dart';

/// Manage automatic monthly income and savings. Each item has a switch for
/// the SELECTED month: turning it off cancels that month only (an emergency),
/// turning it back on restores it. The plan itself and every other month stay
/// untouched. Manual savings are never affected.
class AutomationScreen extends ConsumerStatefulWidget {
  const AutomationScreen({super.key});

  @override
  ConsumerState<AutomationScreen> createState() => _AutomationScreenState();
}

class _AutomationScreenState extends ConsumerState<AutomationScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month, 1);

  Future<void> _toggleMonth({
    required PlanKind kind,
    required int planId,
    required bool enable,
  }) async {
    final l = context.l10n;
    final repo = ref.read(automationRepositoryProvider);
    final key = DateUtilsX.monthKey(_month);
    try {
      if (enable) {
        await repo.restoreMonth(kind, planId, key);
        if (mounted) showSnack(context, l.autoRestored);
      } else {
        final ok = await confirmDialog(context,
            title: l.autoThisMonth,
            message: l.autoSkipConfirm,
            destructive: true);
        if (!ok) return;
        await repo.skipMonth(kind, planId, key);
        if (mounted) showSnack(context, l.autoSkipped);
      }
    } catch (_) {
      if (mounted) showSnack(context, l.errDbError);
    }
  }

  Future<void> _confirmDelete(Future<void> Function() action) async {
    final l = context.l10n;
    final ok = await confirmDialog(context,
        title: l.commonDelete,
        message: l.autoDeleteConfirm,
        confirmLabel: l.commonDelete,
        destructive: true);
    if (ok) await action();
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final fmt = ref.watch(moneyFormatterProvider);
    final key = DateUtilsX.monthKey(_month);
    final incomes = ref.watch(recurringIncomesProvider).valueOrNull ??
        const <RecurringIncome>[];
    final plans =
        ref.watch(savingsPlansProvider).valueOrNull ?? const <SavingsPlan>[];
    final goals =
        ref.watch(goalsProvider).valueOrNull ?? const <SavingsGoal>[];
    final runs = ref.watch(planRunsProvider(key)).valueOrNull ?? const <PlanRun>[];

    bool skipped(PlanKind k, int? id) =>
        runs.any((r) => r.kind == k && r.planId == id && r.skipped);
    String goalName(int goalId) {
      for (final g in goals) {
        if (g.id == goalId) return g.name;
      }
      return '?';
    }

    return Scaffold(
      appBar: AppBar(title: Text(l.autoTitle)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          MonthHeader(
              month: _month, onChange: (m) => setState(() => _month = m)),
          const SizedBox(height: 8),
          PlanSummaryCard(month: _month),
          const SizedBox(height: 8),
          SectionTitle(
            title: l.autoIncome,
            action: TextButton.icon(
              onPressed: () => showRecurringIncomeSheet(context),
              icon: const Icon(Icons.add, size: 18),
              label: Text(l.commonAdd),
            ),
          ),
          if (incomes.isEmpty) _EmptyLine(text: l.autoEmpty),
          for (final p in incomes)
            _PlanTile(
              icon: Icons.arrow_downward_rounded,
              iconColor: Theme.of(context).colorScheme.primary,
              title: p.name,
              subtitle: _subtitle(l.autoDay, p.dayOfMonth, p.amount, fmt),
              active: p.active,
              applicable: p.startMonth.compareTo(key) <= 0,
              skipped: skipped(PlanKind.income, p.id),
              onToggle: (v) => _toggleMonth(
                  kind: PlanKind.income, planId: p.id!, enable: v),
              onEdit: () => showRecurringIncomeSheet(context, existing: p),
              onDelete: () => _confirmDelete(() => ref
                  .read(automationRepositoryProvider)
                  .deleteRecurringIncome(p.id!)),
            ),
          const SizedBox(height: 8),
          SectionTitle(
            title: l.autoSavings,
            action: TextButton.icon(
              onPressed: () => showSavingsPlanSheet(context),
              icon: const Icon(Icons.add, size: 18),
              label: Text(l.commonAdd),
            ),
          ),
          if (plans.isEmpty) _EmptyLine(text: l.autoEmpty),
          for (final p in plans)
            _PlanTile(
              icon: Icons.savings_outlined,
              iconColor: const Color(0xFF00BFA5),
              title: goalName(p.goalId),
              subtitle: _subtitle(l.autoDay, p.dayOfMonth, p.amount, fmt),
              active: p.active,
              applicable: p.startMonth.compareTo(key) <= 0,
              skipped: skipped(PlanKind.savings, p.id),
              onToggle: (v) => _toggleMonth(
                  kind: PlanKind.savings, planId: p.id!, enable: v),
              onEdit: () => showSavingsPlanSheet(context, existing: p),
              onDelete: () => _confirmDelete(() => ref
                  .read(automationRepositoryProvider)
                  .deleteSavingsPlan(p.id!)),
            ),
          const SizedBox(height: 8),
          Card(
            elevation: 0,
            color: Theme.of(context).colorScheme.surface,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              leading: const Icon(Icons.account_balance_outlined),
              title: Text(l.loanTitle,
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle:
                  Text(l.loanFixedHint, style: const TextStyle(fontSize: 11)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const LoansScreen())),
            ),
          ),
        ],
      ),
    );
  }

  String _subtitle(String dayLabel, int day, double amount, MoneyFormatter fmt) =>
      '$dayLabel $day  ·  ${fmt.format(amount)}';
}

class _EmptyLine extends StatelessWidget {
  const _EmptyLine({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        child: Text(text,
            style: TextStyle(
                fontSize: 13,
                color: Theme.of(context).colorScheme.onSurfaceVariant)),
      );
}

class _PlanTile extends StatelessWidget {
  const _PlanTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.active,
    required this.applicable,
    required this.skipped,
    required this.onToggle,
    required this.onEdit,
    required this.onDelete,
  });

  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final bool active;
  final bool applicable;
  final bool skipped;
  final ValueChanged<bool> onToggle;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final enabled = active && applicable;
    return Card(
      elevation: 0,
      color: scheme.surface,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: iconColor.withValues(alpha: 0.14),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      style: TextStyle(
                          fontSize: 12, color: scheme.onSurfaceVariant)),
                  if (enabled && skipped)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(l.autoSkippedThisMonth,
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: scheme.error)),
                    ),
                  if (!active)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text('— ${l.autoActive}: ${l.commonNo}',
                          style: TextStyle(
                              fontSize: 11, color: scheme.onSurfaceVariant)),
                    ),
                ],
              ),
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(l.autoThisMonth,
                    style: TextStyle(
                        fontSize: 10, color: scheme.onSurfaceVariant)),
                Switch(
                  value: enabled && !skipped,
                  onChanged: enabled ? onToggle : null,
                ),
              ],
            ),
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'edit') onEdit();
                if (v == 'delete') onDelete();
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'edit', child: Text(l.commonEdit)),
                PopupMenuItem(value: 'delete', child: Text(l.commonDelete)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
