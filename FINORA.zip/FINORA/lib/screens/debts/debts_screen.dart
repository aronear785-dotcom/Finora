import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/debt.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Debts: two tabs (I owe / Owed to me), statuses, mark-paid.
class DebtsScreen extends ConsumerStatefulWidget {
  const DebtsScreen({super.key});

  @override
  ConsumerState<DebtsScreen> createState() => _DebtsScreenState();
}

class _DebtsScreenState extends ConsumerState<DebtsScreen> {
  String _direction = Debt.owe;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final items = ref.watch(debtsProvider(_direction)).valueOrNull ?? const [];

    final totals = items.fold<double>(0, (s, d) => s + d.amount);
    final pending = items
        .where((d) => d.status == Debt.pending)
        .fold<double>(0, (s, d) => s + d.amount);

    return Scaffold(
      appBar: AppBar(title: Text(l.debtTitle)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => DebtFormScreen(direction: _direction)));
        },
        icon: const Icon(Icons.add),
        label: Text(l.debtAdd),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SegmentedButton<String>(
              segments: [
                ButtonSegment(value: Debt.owe, label: Text(l.debtIOwe)),
                ButtonSegment(value: Debt.owed, label: Text(l.debtOwedToMe)),
              ],
              selected: {_direction},
              onSelectionChanged: (s) => setState(() => _direction = s.first),
              showSelectedIcon: false,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              elevation: 0,
              color: scheme.surface,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: ListTile(
                leading: Icon(
                    _direction == Debt.owe
                        ? Icons.arrow_upward_rounded
                        : Icons.arrow_downward_rounded,
                    color: scheme.primary),
                title: Text(l.debtTitle,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w600)),
                subtitle: Text(
                    '${l.debtPending}: ${fmt.format(pending)}'),
                trailing: Text(fmt.format(totals),
                    style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: scheme.primary)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: items.isEmpty
                ? EmptyState(
                    icon: Icons.handshake_outlined,
                    title: l.debtEmpty,
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                    children: [
                      for (final d in items)
                        _DebtTile(debt: d, fmt: fmt),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

class _DebtTile extends ConsumerWidget {
  const _DebtTile({required this.debt, required this.fmt});

  final Debt debt;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final paid = debt.isPaid;
    return Card(
      elevation: 0,
      color: scheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
        leading: CircleAvatar(
          backgroundColor: scheme.primaryContainer.withValues(alpha: 0.5),
          child: Icon(
            paid ? Icons.check_circle_outline : Icons.person_outline,
            color: paid ? const Color(0xFF00BFA5) : scheme.primary,
          ),
        ),
        title: Text(debt.person,
            style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                decoration: paid ? TextDecoration.lineThrough : null)),
        subtitle: Text(
          '${debt.date.day} ${context.monthName(debt.date.month)} ${debt.date.year}'
          '${debt.note == null || debt.note!.isEmpty ? '' : ' · ${debt.note}'}',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 12),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(fmt.formatCompact(debt.amount),
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: paid ? const Color(0xFF00BFA5) : scheme.error)),
                Text(paid ? l.debtPaid : l.debtPending,
                    style: TextStyle(
                        fontSize: 10,
                        color: paid
                            ? const Color(0xFF00BFA5)
                            : scheme.onSurfaceVariant)),
              ],
            ),
            PopupMenuButton<String>(
              onSelected: (v) async {
                switch (v) {
                  case 'paid':
                    final ok = await confirmDialog(context,
                        title: l.debtMarkPaid,
                        message: l.debtConfirmPaid);
                    if (ok) {
                      await ref
                          .read(planningRepositoryProvider)
                          .markDebtPaid(debt.id!);
                    }
                  case 'edit':
                    await Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => DebtFormScreen(debt: debt)));
                  case 'delete':
                    final ok = await confirmDialog(context,
                        title: l.commonDelete,
                        message: l.commonDeleteConfirm,
                        confirmLabel: l.commonDelete,
                        destructive: true);
                    if (ok) {
                      await ref
                          .read(planningRepositoryProvider)
                          .deleteDebt(debt.id!);
                    }
                }
              },
              itemBuilder: (_) => [
                if (!paid)
                  PopupMenuItem(value: 'paid', child: Text(l.debtMarkPaid)),
                PopupMenuItem(value: 'edit', child: Text(l.commonEdit)),
                PopupMenuItem(value: 'delete', child: Text(l.commonDelete)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Add / edit a debt.
class DebtFormScreen extends ConsumerStatefulWidget {
  const DebtFormScreen({super.key, this.debt, this.direction = Debt.owe});

  final Debt? debt;
  final String direction;

  @override
  ConsumerState<DebtFormScreen> createState() => _DebtFormScreenState();
}

class _DebtFormScreenState extends ConsumerState<DebtFormScreen> {
  final _personCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  String _direction = Debt.owe;
  DateTime _date = DateTime.now();
  bool _saving = false;

  bool get _isEdit => widget.debt != null;

  @override
  void initState() {
    super.initState();
    final d = widget.debt;
    if (d != null) {
      _personCtrl.text = d.person;
      _amountCtrl.text = d.amount.toStringAsFixed(2);
      _noteCtrl.text = d.note ?? '';
      _direction = d.direction;
      _date = d.date;
    } else {
      _direction = widget.direction;
    }
  }

  @override
  void dispose() {
    _personCtrl.dispose();
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final person = _personCtrl.text.trim();
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (person.isEmpty) {
      showSnack(context, context.l10n.errEmptyField);
      return;
    }
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final debt = Debt(
      id: widget.debt?.id,
      person: person,
      amount: amount,
      direction: _direction,
      date: _date,
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
      status: widget.debt?.status ?? Debt.pending,
    );
    final repo = ref.read(planningRepositoryProvider);
    try {
      if (_isEdit) {
        await repo.updateDebt(debt);
      } else {
        await repo.addDebt(debt);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.debtEdit : l.debtAdd)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: Debt.owe, label: Text(l.debtIOwe)),
              ButtonSegment(value: Debt.owed, label: Text(l.debtOwedToMe)),
            ],
            selected: {_direction},
            onSelectionChanged: (s) => setState(() => _direction = s.first),
            showSelectedIcon: false,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _personCtrl,
            decoration: InputDecoration(
              labelText: l.debtPerson,
              prefixIcon: const Icon(Icons.person_outline),
            ),
          ),
          const SizedBox(height: 14),
          AmountField(controller: _amountCtrl, hint: '0.00'),
          const SizedBox(height: 14),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.calendar_month_outlined),
            title: Text(l.commonDate,
                style: const TextStyle(fontSize: 14)),
            trailing: Text(
              '${_date.day} ${context.monthName(_date.month)} ${_date.year}',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _date,
                firstDate: DateTime(2000),
                lastDate: DateTime(2100),
              );
              if (picked != null) setState(() => _date = picked);
            },
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _noteCtrl,
            decoration: InputDecoration(
              labelText: '${l.commonNote} (${l.commonOptional})',
              prefixIcon: const Icon(Icons.notes_outlined),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: _saving ? null : _save,
            style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15)),
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : Text(l.commonSave),
          ),
        ],
      ),
    );
  }
}
