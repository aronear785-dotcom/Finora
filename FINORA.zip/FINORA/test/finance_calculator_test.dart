import 'package:flutter_test/flutter_test.dart';

import 'package:finora/models/expense.dart';
import 'package:finora/models/income.dart';
import 'package:finora/models/savings_transaction.dart';
import 'package:finora/services/finance_calculator.dart';

void main() {
  group('FinanceCalculator', () {
    final now = DateTime(2026, 9, 16);

    test('available = income - expenses - savings', () {
      final income = [Income(amount: 15000, categoryId: 1, date: now)];
      final expenses = [Expense(amount: 8000, categoryId: 1, date: now)];
      final savings = [
        SavingsTransaction(goalId: 1, amount: 3000, date: now),
      ];
      expect(FinanceCalculator.totalIncome(income), 15000);
      expect(FinanceCalculator.totalExpenses(expenses), 8000);
      expect(FinanceCalculator.totalSaved(savings), 3000);
      expect(FinanceCalculator.available(15000, 8000, 3000), 4000);
    });

    test('negative available is handled explicitly', () {
      expect(FinanceCalculator.available(1000, 2000, 500), -1500);
    });

    test('budget progress, remaining and status', () {
      expect(FinanceCalculator.budgetProgress(1250, 2500), 50);
      expect(FinanceCalculator.remainingBudget(2500, 1250), 1250);
      expect(FinanceCalculator.budgetStatus(1250, 2500, 80),
          BudgetStatus.normal);
      expect(FinanceCalculator.budgetStatus(2000, 2500, 80),
          BudgetStatus.approaching);
      expect(FinanceCalculator.budgetStatus(2500, 2500, 80),
          BudgetStatus.exceeded);
      // No division by zero and negative spending yields 0 %.
      expect(FinanceCalculator.budgetProgress(1250, 0), 0);
    });

    test('savings goal progress is accurate', () {
      expect(FinanceCalculator.goalProgress(25000, 100000), 25);
      expect(FinanceCalculator.goalProgress(0, 100000), 0);
      expect(FinanceCalculator.goalProgress(0, 0), 0);
      expect(FinanceCalculator.goalProgress(120000, 100000), 100);
    });

    test('savings plan calculation is mathematically accurate', () {
      final plan = FinanceCalculator.savingsPlan(
        target: 120000,
        current: 35000,
        monthly: 5000,
        from: DateTime(2026, 9, 16),
      );
      expect(plan.remaining, 85000);
      expect(plan.months, 17);
      expect(plan.completionDate, DateTime(2028, 2, 16));

      // Reached target: no months left.
      final done = FinanceCalculator.savingsPlan(
        target: 1000,
        current: 1000,
        monthly: 100,
        from: DateTime(2026, 9, 16),
      );
      expect(done.remaining, 0);
      expect(done.months, 0);

      // Unreachable without monthly contribution.
      final unreachable = FinanceCalculator.savingsPlan(
        target: 1000,
        current: 0,
        monthly: 0,
        from: DateTime(2026, 9, 16),
      );
      expect(unreachable.months, isNull);
    });

    test('automatic savings percentage of income', () {
      expect(FinanceCalculator.automaticSavingsTarget(15000, 20), 3000);
      expect(FinanceCalculator.automaticSavingsTarget(15000, 5), 750);
      expect(FinanceCalculator.automaticSavingsTarget(15000, 100), 15000);
    });

    test('expenses grouped per category', () {
      final records = [
        Expense(amount: 120, categoryId: 1, date: now),
        Expense(amount: 30, categoryId: 2, date: now),
        Expense(amount: 80, categoryId: 1, date: now),
      ];
      final byCat = FinanceCalculator.expensesByCategory(records);
      expect(byCat[1], 200);
      expect(byCat[2], 30);
    });

    test('daily expenses fill every day of the range with zeros', () {
      final records = [
        Expense(amount: 50, categoryId: 1, date: DateTime(2026, 9, 2, 10)),
      ];
      final daily = FinanceCalculator.dailyExpenses(
          records, DateTime(2026, 9, 1), DateTime(2026, 9, 3));
      expect(daily.length, 3);
      expect(daily[DateTime(2026, 9, 1)], 0);
      expect(daily[DateTime(2026, 9, 2)], 50);
      expect(daily[DateTime(2026, 9, 3)], 0);
    });

    test('month-over-month percentage change', () {
      expect(FinanceCalculator.percentageChange(150, 100), 50);
      expect(FinanceCalculator.percentageChange(80, 100), -20);
      expect(FinanceCalculator.percentageChange(100, 0), isNull);
    });
  });
}
