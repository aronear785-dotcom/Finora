# FINORA - self-review of the automation / ledger work

Static review only (no Flutter SDK was available, nothing was compiled or run).

## Problems found in my previous changes -> fixes applied
1. **Duplicated calculation.** The plan summary card and the dashboard each
   computed totals separately (`summaryForMonth` vs `LedgerCalculator`).
   -> The card now reads `monthLedgerProvider` (single source of truth);
   `MonthLedger.planAdjustment` replaces the second formula.
2. **Floating-point leak.** Several SQL `SUM(amount)` queries (month summary,
   goal / total / period savings, loan progress) bypassed the cents rule.
   -> They now sum integer cents in SQL and convert once (`Money.fromCents`).
3. **Budgets vanished every month.** A new month had no budgets, so the
   budget overview was empty until the user re-entered them.
   -> `carryOverBudgets()` copies last month's VARIABLE budgets once at app
   start / resume (never overwrites, never copies fixed categories).
4. **Expected vs received.** Recurring salary was always auto-recorded.
   -> Per-plan "confirm receipt manually" mode: stays *expected* until the
   user taps "Mark received" (idempotent, ledger-protected).
5. **Open-ended plans.** -> Optional end month for recurring income (engine,
   summary and upcoming list respect it).
6. **Loans.** -> `loans` + `loan_payments` tables, automatic installments as
   FIXED expenses (once per month), outstanding balance, principal/interest
   split, optional "record received amount" as separate loan income.
7. **Quick add.** -> Most-used variable categories appear as shortcut chips.
8. **Migrations.** `ALTER TABLE` is now guarded (`_addColumnIfMissing`), so any
   upgrade path v1 -> v4 is safe even if a column already exists.

## Design decisions (kept on purpose)
* Three typed tables (income / expenses / savings transactions) instead of one
  generic `Transaction`: explicit types, simple queries, no data migration
  risk. Totals are derived (`LedgerCalculator`), never stored.
* Interest is split straight-line; the last installment absorbs cent rounding.

## Remaining limitations / suggestions
* Nothing here was compiled: run `flutter pub get`, `flutter analyze`,
  `flutter test` first.
* `recurring_expenses` still uses its own generator (separate from the
  `plan_runs` ledger). Unifying them would give one idempotency mechanism.
* One automatic savings plan per goal.
* Gradle 9 / AGP 9 / Kotlin 2.3 migration (Flutter's "will soon be dropped"
  warnings) is still pending and should be done once the build is green.
