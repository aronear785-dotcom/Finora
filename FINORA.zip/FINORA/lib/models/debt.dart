/// A simple debt. [direction] is 'owe' (I owe) or 'owed' (owed to me).
class Debt {
  const Debt({
    this.id,
    required this.person,
    required this.amount,
    required this.direction,
    required this.date,
    this.note,
    this.status = 'pending',
  });

  final int? id;
  final String person;
  final double amount;
  final String direction;
  final DateTime date;
  final String? note;
  final String status;

  static const owe = 'owe';
  static const owed = 'owed';
  static const pending = 'pending';
  static const paid = 'paid';

  bool get isPaid => status == paid;

  Debt copyWith({double? amount, String? person, String? status, String? note, DateTime? date}) =>
      Debt(
        id: id,
        person: person ?? this.person,
        amount: amount ?? this.amount,
        direction: direction,
        date: date ?? this.date,
        note: note ?? this.note,
        status: status ?? this.status,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'person': person,
        'amount': amount,
        'direction': direction,
        'date': date.millisecondsSinceEpoch,
        'note': note,
        'status': status,
      };

  factory Debt.fromMap(Map<String, Object?> map) => Debt(
        id: map['id'] as int?,
        person: map['person'] as String,
        amount: (map['amount'] as num).toDouble(),
        direction: (map['direction'] as String?) ?? owe,
        date: DateTime.fromMillisecondsSinceEpoch(map['date'] as int),
        note: map['note'] as String?,
        status: (map['status'] as String?) ?? pending,
      );
}
