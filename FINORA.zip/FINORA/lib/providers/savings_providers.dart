import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/savings_goal.dart';
import '../models/savings_transaction.dart';
import 'providers.dart';

/// Per-goal saved amount (refetched on every data change).
final savedForGoalProvider =
    FutureProvider.family<double?, int>((ref, goalId) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).savedForGoal(goalId);
});

/// Transactions of one goal.
final goalTransactionsProvider =
    FutureProvider.family<List<SavingsTransaction>, int>((ref, goalId) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).transactionsForGoal(goalId);
});

/// Saved-amount lookup merged onto goals list.
Future<Map<int, double>> savedForAll(WidgetRefLike ref, List<SavingsGoal> goals) async {
  final out = <int, double>{};
  for (final g in goals) {
    if (g.id != null) {
      out[g.id!] =
          await ref.read(planningRepositoryProvider).savedForGoal(g.id!);
    }
  }
  return out;
}

/// Minimal interface shim so this file stays importable without riverpod types.
typedef WidgetRefLike = dynamic;
