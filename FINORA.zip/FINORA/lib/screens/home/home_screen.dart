import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../models/expense.dart';
import '../../models/income.dart';
import '../../providers/providers.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/charts.dart';
import '../../widgets/common_widgets.dart';
import '../report/report_screen.dart';
import '../search/search_screen.dart';
import '../settings/settings_screen.dart';
import '../expenses/expense_day_screen.dart' show openDay;
import '../expenses/expense_form_screen.dart';

/// Financial dashboard for the selected month - all figures come from SQLite.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  DateTime _month = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final catsAsync = ref.watch(categoriesProvider);
    final incomeAsync = ref.watch(monthIncomeProvider(_month));
    final expensesAsync = ref.watch(monthExpensesProvider(_month));
    final savingsAsync = ref.watch(monthSavingsProvider(_month));
    final prevMonth = DateTime(_month.year, _month.month - 1, 1);
    final prevIncomeAsync = ref.watch(monthIncomeProvider(prevMonth));
    final prevExpensesAsync = ref.watch(monthExpensesProvider(prevMonth));
    final goalsAsync = ref.watch(goalsProvider);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text('FINORA',
                style: TextStyle(
                    color: scheme.primary,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5)),
            const SizedBox(width: 8),
            Expanded(
              child: Text(l.tagline,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: scheme.onSurfaceVariant)),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: l.seaTitle,
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const RecordSearchScreen())),
          ),
          IconButton(
            tooltip: l.repTitle,
            icon: const Icon(Icons.description_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const ReportScreen())),
          ),
          IconButton(
            tooltip: l.setTitle,
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(monthExpensesProvider(_month));
          ref.invalidate(monthIncomeProvider(_month));
          ref.invalidate(monthSavingsProvider(_month));
          ref.invalidate(goalsProvider);
          await Future<void>.delayed(const Duration(milliseconds: 300));
        },
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
          children: [
            MonthHeader(
              month: _month,
              onChange: (m) => setState(() => _month = m),
            ),
            const SizedBox(height: 12),
            incomeAsync.when(
              data: (incomes) => expensesAsync.when(
                data: (expenses) => savingsAsync.when(
                  data: (savings) => _SummaryGrid(
                    income: FinanceCalculator.totalIncome(incomes),
                    expenses: FinanceCalculator.totalExpenses(expenses),
                    savings: savings,
                    fmt: fmt,
                  ),
                  loading: () => const _HomeLoading(),
                  error: (_, __) => const _HomeLoading(),
                ),
                loading: () => const _HomeLoading(),
                error: (_, __) => const _HomeLoading(),
              ),
              loading: () => const _HomeLoading(),
              error: (_, __) => const _HomeLoading(),
            ),
            const SizedBox(height: 16),
            catsAsync.when(
              data: (cats) {
                final catMap = {for (final c in cats) c.id!: c};
                return Column(
                  children: [
                    ChartCard(
                      title: l.homeIncomeVsExpenses,
                      subtitle: l.homeVsPrevMonth,
                      child: incomeAsync.when(
                        data: (incomes) => expensesAsync.when(
                          data: (expenses) {
                            final i = FinanceCalculator.totalIncome(incomes);
                            final e = FinanceCalculator.totalExpenses(expenses);
                            if (i <= 0 && e <= 0) return const _NoChart();
                            return FinoraBarChart(
                              groups: [
                                BarGroup(
                                    x: 0,
                                    label: l.homeIncome,
                                    datum: BarDatum(
                                        color: scheme.primary, value: i)),
                                BarGroup(
                                    x: 1,
                                    label: l.homeExpenses,
                                    datum: BarDatum(
                                        color: scheme.error, value: e)),
                              ],
                              formatter: fmt,
                            );
                          },
                          loading: () => const SizedBox(height: 180),
                          error: (_, __) => const SizedBox(height: 180),
                        ),
                        loading: () => const SizedBox(height: 180),
                        error: (_, __) => const SizedBox(height: 180),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ChartCard(
                      title: l.homeExpensesByCategory,
                      child: expensesAsync.when(
                        data: (expenses) {
                          final byCat =
                              FinanceCalculator.expensesByCategory(expenses);
                          if (byCat.isEmpty) return const _NoChart();
                          final slices = byCat.entries.map((e) {
                            final c = catMap[e.key];
                            return PieSlice(
                              color:
                                  c != null ? AppColors.fromInt(c.color) : scheme.outline,
                              value: e.value,
                              label:
                                  c != null ? context.categoryLabel(c.name) : '?',
                            );
                          }).toList();
                          return ExpenseDonutChart(slices: slices, formatter: fmt);
                        },
                        loading: () => const SizedBox(height: 180),
                        error: (_, __) => const SizedBox(height: 180),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ChartCard(
                      title: l.homeSavingsProgress,
                      child: goalsAsync.when(
                        data: (goals) {
                          if (goals.isEmpty) return const _NoChart();
                          return Column(
                            children: goals.map((g) {
                              return FutureBuilder<double>(
                                future: ref
                                    .read(planningRepositoryProvider)
                                    .savedForGoal(g.id!),
                                builder: (_, snap) {
                                  final saved = snap.data ?? 0;
                                  final progress = FinanceCalculator.goalProgress(
                                      saved, g.target);
                                  return Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 6),
                                    child: Row(
                                      children: [
                                        Icon(AppIcons.resolve(g.icon),
                                            size: 20,
                                            color: AppColors.fromInt(g.color)),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: Text(g.name,
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: scheme
                                                                .onSurface)),
                                                  ),
                                                  Text(
                                                      '${progress.toStringAsFixed(0)}%',
                                                      style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          color: scheme.primary)),
                                                ],
                                              ),
                                              const SizedBox(height: 4),
                                              ProgressBar(
                                                value: progress / 100,
                                                color:
                                                    AppColors.fromInt(g.color),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              );
                            }).toList(),
                          );
                        },
                        loading: () => const SizedBox(height: 120),
                        error: (_, __) => const SizedBox(height: 120),
                      ),
                    ),
                    const SizedBox(height: 12),
                    _ComparisonCard(
                      month: _month,
                      fmt: fmt,
                      currentIncome: incomeAsync.valueOrNull,
                      currentExpenses: expensesAsync.valueOrNull,
                      currentSavings: savingsAsync.valueOrNull,
                      prevIncome: prevIncomeAsync.valueOrNull,
                      prevExpenses: prevExpensesAsync.valueOrNull,
                    ),
                    const SizedBox(height: 12),
                    _RecentSection(
                      month: _month,
                      categories: catMap,
                      fmt: fmt,
                    ),
                  ],
                );
              },
              loading: () => const SizedBox(height: 160),
              error: (_, __) => const SizedBox(height: 160),
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryGrid extends StatelessWidget {
  const _SummaryGrid({
    required this.income,
    required this.expenses,
    required this.savings,
    required this.fmt,
  });

  final double income;
  final double expenses;
  final double savings;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final available = FinanceCalculator.available(income, expenses, savings);
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.55,
      children: [
        SummaryCard(
          label: l.homeIncome,
          value: fmt.format(income),
          icon: Icons.arrow_downward_rounded,
          color: scheme.primary,
        ),
        SummaryCard(
          label: l.homeExpenses,
          value: fmt.format(expenses),
          icon: Icons.arrow_upward_rounded,
          color: scheme.error,
        ),
        SummaryCard(
          label: l.homeSavings,
          value: fmt.format(savings),
          icon: Icons.savings_outlined,
          color: const Color(0xFF00BFA5),
        ),
        SummaryCard(
          label: l.homeAvailable,
          value: fmt.format(available),
          icon: Icons.account_balance_wallet_outlined,
          color: available < 0 ? scheme.error : const Color(0xFFFFB300),
        ),
      ],
    );
  }
}

class _NoChart extends StatelessWidget {
  const _NoChart();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return SizedBox(
      height: 140,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.insights_outlined, color: scheme.outline, size: 28),
            const SizedBox(height: 8),
            Text(context.l10n.homeNoData,
                style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

class _HomeLoading extends StatelessWidget {
  const _HomeLoading();

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      height: 180,
      child: Center(child: CircularProgressIndicator()),
    );
  }
}

class _ComparisonCard extends StatelessWidget {
  const _ComparisonCard({
    required this.month,
    required this.fmt,
    required this.currentIncome,
    required this.currentExpenses,
    required this.currentSavings,
    required this.prevIncome,
    required this.prevExpenses,
  });

  final DateTime month;
  final MoneyFormatter fmt;
  final List<Income>? currentIncome;
  final List<Expense>? currentExpenses;
  final double? currentSavings;
  final List<Income>? prevIncome;
  final List<Expense>? prevExpenses;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    if (currentIncome == null ||
        currentExpenses == null ||
        prevIncome == null ||
        prevExpenses == null) {
      return const SizedBox.shrink();
    }
    final cI = FinanceCalculator.totalIncome(currentIncome!);
    final cE = FinanceCalculator.totalExpenses(currentExpenses!);
    final pI = FinanceCalculator.totalIncome(prevIncome!);
    final pE = FinanceCalculator.totalExpenses(prevExpenses!);
    final pS = currentSavings ?? 0;

    if (cI == 0 && cE == 0 && pS == 0 && pI == 0 && pE == 0) {
      return const SizedBox.shrink();
    }

    Widget diff(double current, double previous) {
      final d = current - previous;
      final color = d >= 0 ? const Color(0xFF00BFA5) : scheme.error;
      return Row(
        children: [
          Icon(d >= 0 ? Icons.trending_up : Icons.trending_down,
              size: 15, color: color),
          const SizedBox(width: 4),
          Text(
            '${d >= 0 ? '+' : ''}${fmt.formatCompact(d)}',
            style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w700, color: color),
          ),
        ],
      );
    }

    return ChartCard(
      title: l.homeMonthlyComparison,
      subtitle: l.homeVsPrevMonth,
      child: Column(
        children: [
          _row(scheme, l.homeDiffIncome, fmt.format(cI), diff(cI, pI)),
          const SizedBox(height: 10),
          _row(scheme, l.homeDiffExpenses, fmt.format(cE), diff(cE, pE)),
          const SizedBox(height: 10),
          _row(scheme, l.homeDiffSavings, fmt.format(pS), diff(pS, 0)),
        ],
      ),
    );
  }

  Widget _row(ColorScheme scheme, String label, String value, Widget delta) {
    return Row(
      children: [
        Expanded(
          child: Text(label,
              style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant)),
        ),
        Text(value,
            style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: scheme.onSurface)),
        const SizedBox(width: 12),
        delta,
      ],
    );
  }
}

class _RecentSection extends ConsumerWidget {
  const _RecentSection({
    required this.month,
    required this.categories,
    required this.fmt,
  });

  final DateTime month;
  final Map<int, Category> categories;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final expenses = ref
            .watch(monthExpensesProvider(month))
            .valueOrNull ??
        const <Expense>[];
    final incomes =
        ref.watch(monthIncomeProvider(month)).valueOrNull ?? const <Income>[];
    final items = <(bool, double, int, DateTime, String?)>[
      for (final e in expenses) (true, e.amount, e.categoryId, e.date, e.note),
      for (final i in incomes) (false, i.amount, i.categoryId, i.date, i.note),
    ]..sort((a, b) => b.$4.compareTo(a.$4));
    final recent = items.take(6).toList();
    if (recent.isEmpty) {
      return EmptyState(
        icon: Icons.receipt_long_outlined,
        title: l.expEmpty,
        subtitle: l.homeNoData,
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionTitle(title: l.homeRecent),
        Card(
          elevation: 0,
          color: scheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Column(
              children: [
                for (final (isExp, amount, catId, date, note) in recent)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: (categories[catId] != null
                                ? AppColors.fromInt(categories[catId]!.color)
                                : scheme.primary)
                            .withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        categories[catId] != null
                            ? AppIcons.resolve(categories[catId]!.icon)
                            : Icons.category_outlined,
                        size: 19,
                        color: categories[catId] != null
                            ? AppColors.fromInt(categories[catId]!.color)
                            : scheme.primary,
                      ),
                    ),
                    title: Text(
                      categories[catId] != null
                          ? context.categoryLabel(categories[catId]!.name)
                          : l.catOther,
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      note ?? '${date.day} ${context.monthName(date.month)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12),
                    ),
                    trailing: Text(
                      '${isExp ? '-' : '+'}${fmt.formatCompact(amount)}',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: isExp ? scheme.error : scheme.primary,
                      ),
                    ),
                    onTap: isExp
                        ? () => openDay(context, date,
                            categories: categories, fmt: fmt)
                        : null,
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
