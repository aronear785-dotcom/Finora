import 'package:flutter/foundation.dart';

/// In-memory change bus. Every repository write calls [bump] so Riverpod
/// providers that watch [AppBus.instance] re-run and the UI refreshes with
/// fresh SQLite data. This keeps widgets decoupled from the database.
class AppBus extends ChangeNotifier {
  AppBus._();

  static final AppBus instance = AppBus._();

  void bump() => notifyListeners();
}
