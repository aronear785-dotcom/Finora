import 'package:flutter/material.dart';

/// Global constants. No SQL and no business logic live in the UI:
/// these are pure display-level definitions.
class AppColors {
  AppColors._();

  static const Color seed = Color(0xFF6C4DF6);

  /// Category palette (ARGB ints stored in the database).
  static const List<int> palette = [
    0xFF6C4DF6, // violet
    0xFF4C8DF6, // blue
    0xFF00BFA5, // teal
    0xFF26A69A, // sea green
    0xFF66BB6A, // green
    0xFFFFB300, // amber
    0xFFFF8F00, // orange
    0xFFF4511E, // deep orange
    0xFFE53935, // red
    0xFFD81B60, // pink
    0xFF8E24AA, // purple
    0xFF00897B, // dark teal
    0xFF5C6BC0, // indigo
    0xFF78909C, // blue grey
  ];

  static Color fromInt(int value) => Color(value);
}

class AppIcons {
  AppIcons._();

  static const Map<String, IconData> catalog = {
    'home': Icons.home_outlined,
    'food': Icons.restaurant_outlined,
    'car': Icons.directions_car_outlined,
    'transport': Icons.directions_bus_outlined,
    'education': Icons.school_outlined,
    'health': Icons.favorite_outline,
    'electricity': Icons.bolt_outlined,
    'water': Icons.water_drop_outlined,
    'internet': Icons.wifi_outlined,
    'phone': Icons.phone_outlined,
    'shopping': Icons.shopping_bag_outlined,
    'clothing': Icons.checkroom_outlined,
    'entertainment': Icons.movie_outlined,
    'subscriptions': Icons.subscriptions_outlined,
    'chair': Icons.chair_outlined,
    'more': Icons.more_horiz,
    'work': Icons.work_outline,
    'laptop': Icons.laptop_mac_outlined,
    'gift': Icons.card_giftcard_outlined,
    'business': Icons.storefront_outlined,
    'investment': Icons.trending_up,
    'savings': Icons.savings_outlined,
    'bank': Icons.account_balance_outlined,
    'flight': Icons.flight_outlined,
    'house': Icons.house_outlined,
    'emergency': Icons.emergency_outlined,
    'phonelink': Icons.phonelink_outlined,
    'android': Icons.android_outlined,
    'cloud': Icons.cloud_outlined,
    'music': Icons.music_note_outlined,
    'fitness': Icons.fitness_center_outlined,
    'pets': Icons.pets_outlined,
    'cafe': Icons.local_cafe_outlined,
    'fastfood': Icons.fastfood_outlined,
    'healthcare': Icons.medical_services_outlined,
    'bed': Icons.bed_outlined,
    'lightbulb': Icons.lightbulb_outline,
    'receipt': Icons.receipt_outlined,
    'payments': Icons.payments_outlined,
    'wallet': Icons.wallet_outlined,
    'money': Icons.attach_money_outlined,
    'calendar': Icons.calendar_month_outlined,
    'flag': Icons.flag_outlined,
    'star': Icons.star_outline,
    'rocket': Icons.rocket_launch_outlined,
    'book': Icons.book_outlined,
    'language': Icons.language_outlined,
    'celebration': Icons.celebration_outlined,
    'category': Icons.category_outlined,
  };

  static IconData resolve(String name) =>
      catalog[name] ?? Icons.category_outlined;
}

class IncomeCategoryNames {
  IncomeCategoryNames._();
  static const seedNames = ['salary', 'freelance', 'bonus', 'business', 'investment', 'other'];
}

class Frequencies {
  Frequencies._();
  static const daily = 'daily';
  static const weekly = 'weekly';
  static const monthly = 'monthly';
  static const yearly = 'yearly';
  static const List<String> all = [daily, weekly, monthly, yearly];
}

class PaymentMethods {
  PaymentMethods._();
  static const List<String> all = ['cash', 'card', 'transfer', 'mobile'];
}
