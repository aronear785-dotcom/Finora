/// Which kind of automatic plan a [PlanRun] belongs to.
enum PlanKind { income, savings }

/// Ledger entry: what happened to one plan in one month.
/// `done`    - the transaction was generated (its id is [txId]).
/// `skipped` - the user cancelled that month only; nothing is generated.
/// A month with no ledger entry has not been processed yet.
class PlanRun {
  const PlanRun({
    required this.kind,
    required this.planId,
    required this.month,
    required this.skipped,
    this.txId,
  });

  final PlanKind kind;
  final int planId;
  final String month; // 'YYYY-MM'
  final bool skipped;
  final int? txId;

  factory PlanRun.fromMap(Map<String, Object?> map) => PlanRun(
        kind: map['kind'] == 'savings' ? PlanKind.savings : PlanKind.income,
        planId: map['plan_id'] as int,
        month: map['month'] as String,
        skipped: map['status'] == 'skipped',
        txId: map['tx_id'] as int?,
      );
}
