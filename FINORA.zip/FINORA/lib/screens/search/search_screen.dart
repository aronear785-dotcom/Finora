import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/date_utils.dart' as dutils;
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Powerful local search across expenses + income with filters
/// (today/week/month/prev month/custom dates, category) and sorting.
class RecordSearchScreen extends ConsumerStatefulWidget {
  const RecordSearchScreen({super.key});

  @override
  ConsumerState<RecordSearchScreen> createState() =>
      _RecordSearchScreenState();
}

enum _RangeChoice { today, week, month, prevMonth, custom, all }

class _RecordSearchScreenState extends ConsumerState<RecordSearchScreen> {
  final _queryCtrl = TextEditingController();
  _RangeChoice _range = _RangeChoice.all;
  int? _categoryId;
  String _sort = 'newest';
  DateTime? _customStart;
  DateTime? _customEnd;
  List<Map<String, Object?>> _results = [];
  bool _searching = false;

  @override
  void dispose() {
    _queryCtrl.dispose();
    super.dispose();
  }

  (DateTime?, DateTime?) _rangeBounds() {
    final now = DateTime.now();
    switch (_range) {
      case _RangeChoice.today:
        return (
          dutils.DateUtilsX.startOfDay(now),
          dutils.DateUtilsX.endOfDay(now)
        );
      case _RangeChoice.week:
        return (
          dutils.DateUtilsX.startOfWeek(now),
          dutils.DateUtilsX.endOfWeek(now)
        );
      case _RangeChoice.month:
        return (
          dutils.DateUtilsX.monthStart(now),
          dutils.DateUtilsX.monthEnd(now)
        );
      case _RangeChoice.prevMonth:
        final p = DateTime(now.year, now.month - 1, 1);
        return (p, dutils.DateUtilsX.monthEnd(p));
      case _RangeChoice.custom:
        if (_customStart == null || _customEnd == null) return (null, null);
        return (
          dutils.DateUtilsX.startOfDay(_customStart!),
          dutils.DateUtilsX.endOfDay(_customEnd!)
        );
      case _RangeChoice.all:
        return (null, null);
    }
  }

  Future<void> _run() async {
    setState(() => _searching = true);
    final (from, to) = _rangeBounds();
    final rows = await ref
        .read(financeRepositoryProvider)
        .searchAll(
          query: _queryCtrl.text,
          from: from,
          to: to,
          categoryId: _categoryId,
        );
    final sorted = [...rows];
    switch (_sort) {
      case 'oldest':
        sorted.sort((a, b) => (a['date'] as int).compareTo(b['date'] as int));
      case 'high':
        sorted.sort((a, b) =>
            (b['amount'] as num).compareTo(a['amount'] as num));
      case 'low':
        sorted.sort(
            (a, b) => (a['amount'] as num).compareTo(b['amount'] as num));
      default:
        sorted.sort((a, b) => (b['date'] as int).compareTo(a['date'] as int));
    }
    if (mounted) {
      setState(() {
        _results = sorted;
        _searching = false;
      });
    }
    return Future.value();
  }

  Future<void> _pickCustomRange() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDateRange: DateTimeRange(
          start: _customStart ?? DateTime.now(),
          end: _customEnd ?? DateTime.now()),
    );
    if (range != null) {
      setState(() {
        _customStart = range.start;
        _customEnd = range.end;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final cats = ref.watch(categoriesProvider).valueOrNull ?? const <Category>[];

    return Scaffold(
      appBar: AppBar(title: Text(l.seaTitle)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              controller: _queryCtrl,
              onChanged: (_) => _run(),
              decoration: InputDecoration(
                hintText: l.commonSearch,
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _queryCtrl.clear();
                    _run();
                  },
                ),
              ),
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _run(),
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              children: [
                for (final (value, label) in [
                  (_RangeChoice.all, l.commonAll),
                  (_RangeChoice.today, l.commonToday),
                  (_RangeChoice.week, l.seaThisWeek),
                  (_RangeChoice.month, l.seaThisMonth),
                  (_RangeChoice.prevMonth, l.seaPrevMonth),
                  (_RangeChoice.custom, l.seaCustom),
                ])
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(label),
                      selected: _range == value,
                      onSelected: (_) async {
                        setState(() => _range = value);
                        if (value == _RangeChoice.custom) {
                          await _pickCustomRange();
                        }
                        _run();
                      },
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int?>(
                    value: _categoryId,
                    decoration: InputDecoration(
                        labelText: l.commonCategory, isDense: true),
                    items: [
                      DropdownMenuItem<int?>(
                          value: null, child: Text(l.commonAll)),
                      for (final c in cats)
                        DropdownMenuItem<int?>(
                            value: c.id,
                            child: Text(context.categoryLabel(c.name))),
                    ],
                    onChanged: (v) {
                      setState(() => _categoryId = v);
                      _run();
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _sort,
                    decoration: InputDecoration(
                        labelText: l.seaSort, isDense: true),
                    items: [
                      DropdownMenuItem(value: 'newest', child: Text(l.seaNewest)),
                      DropdownMenuItem(value: 'oldest', child: Text(l.seaOldest)),
                      DropdownMenuItem(value: 'high', child: Text(l.seaHigh)),
                      DropdownMenuItem(value: 'low', child: Text(l.seaLow)),
                    ],
                    onChanged: (v) {
                      if (v != null) {
                        setState(() => _sort = v);
                        _run();
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 16),
          Expanded(
            child: _searching
                ? const Center(child: CircularProgressIndicator())
                : _results.isEmpty
                    ? EmptyState(
                        icon: Icons.search_off_outlined,
                        title: l.seaNoResults,
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                        itemCount: _results.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 6),
                        itemBuilder: (_, i) {
                          final row = _results[i];
                          final isExpense = row['type'] == 'expense';
                          Category? cat;
                          for (final c in cats) {
                            if (c.id == row['category_id']) {
                              cat = c;
                              break;
                            }
                          }
                          final color = cat != null
                              ? AppColors.fromInt(cat.color)
                              : scheme.primary;
                          final amount =
                              (row['amount'] as num).toDouble();
                          final date = DateTime.fromMillisecondsSinceEpoch(
                              row['date'] as int);
                          return Card(
                            elevation: 0,
                            color: scheme.surface,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14)),
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 0),
                              leading: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  color: color.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(11),
                                ),
                                child: Icon(
                                  cat != null
                                      ? AppIcons.resolve(cat.icon)
                                      : Icons.category_outlined,
                                  size: 19,
                                  color: color,
                                ),
                              ),
                              title: Text(
                                cat != null
                                    ? context.categoryLabel(cat.name)
                                    : (isExpense ? l.navExpenses : l.navHome),
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600),
                              ),
                              subtitle: Text(
                                row['note'] as String? ??
                                    '${date.day} ${context.monthName(date.month)} ${date.year}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 12),
                              ),
                              trailing: Text(
                                '${isExpense ? '-' : '+'}${fmt.formatCompact(amount)}',
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: isExpense
                                        ? scheme.error
                                        : scheme.primary),
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
