import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/utils/app_bus.dart';
import '../core/utils/date_utils.dart';
import '../domain/ledger_calculator.dart';
import '../core/utils/money_formatter.dart';
import '../models/app_settings.dart';
import '../models/budget.dart';
import '../models/category.dart';
import '../models/debt.dart';
import '../models/expense.dart';
import '../models/income.dart';
import '../models/loan.dart';
import '../models/plan_run.dart';
import '../models/recurring_income.dart';
import '../models/recurring_expense.dart';
import '../models/savings_goal.dart';
import '../models/subscription.dart';
import '../repositories/automation_repository.dart';
import '../repositories/finance_repository.dart';
import '../repositories/loan_repository.dart';
import '../repositories/planning_repository.dart';
import '../services/settings_service.dart';

/// Glue between the repository layer and the UI. These providers rebuild
/// whenever [AppBus] notifies (i.e. after every database write), so charts
/// and lists always reflect what is actually stored in SQLite.

final appBusProvider = ChangeNotifierProvider<AppBus>((ref) => AppBus.instance);

final financeRepositoryProvider = Provider<FinanceRepository>(
  (ref) => FinanceRepository(),
);

final planningRepositoryProvider = Provider<PlanningRepository>(
  (ref) => PlanningRepository(),
);

final settingsServiceProvider = Provider<SettingsService>(
  (ref) => SettingsService(),
);

final settingsProvider = FutureProvider<AppSettings>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(settingsServiceProvider).load();
});

final moneyFormatterProvider = Provider<MoneyFormatter>((ref) {
  final settings =
      ref.watch(settingsProvider).valueOrNull ?? AppSettings.defaults;
  return MoneyFormatter(settings.currency);
});

final categoriesProvider = FutureProvider<List<Category>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(financeRepositoryProvider).categories();
});

final incomeCategoriesProvider = FutureProvider<List<Category>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(financeRepositoryProvider).categories(income: true);
});

final monthExpensesProvider =
    FutureProvider.family<List<Expense>, DateTime>((ref, month) async {
  ref.watch(appBusProvider);
  final m = DateTime(month.year, month.month, 1);
  return ref.read(financeRepositoryProvider).expensesBetween(
      m, DateTime(m.year, m.month + 1, 0, 23, 59, 59));
});

final dayExpensesProvider =
    FutureProvider.family<List<Expense>, DateTime>((ref, day) async {
  ref.watch(appBusProvider);
  final d = DateTime(day.year, day.month, day.day);
  return ref.read(financeRepositoryProvider).expensesBetween(
      d, d.add(const Duration(hours: 24, milliseconds: -1)));
});

final monthIncomeProvider =
    FutureProvider.family<List<Income>, DateTime>((ref, month) async {
  ref.watch(appBusProvider);
  final m = DateTime(month.year, month.month, 1);
  return ref.read(financeRepositoryProvider).incomeBetween(
      m, DateTime(m.year, m.month + 1, 0, 23, 59, 59));
});

final monthSavingsProvider =
    FutureProvider.family<double, DateTime>((ref, month) async {
  ref.watch(appBusProvider);
  final m = DateTime(month.year, month.month, 1);
  return ref.read(planningRepositoryProvider).savedBetween(
      m, DateTime(m.year, m.month + 1, 0, 23, 59, 59));
});

final budgetsProvider =
    FutureProvider.family<List<Budget>, String>((ref, month) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).budgetsForMonth(month);
});

final goalsProvider = FutureProvider<List<SavingsGoal>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).savingsGoals();
});

final recurringProvider = FutureProvider<List<RecurringExpense>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).recurringExpenses();
});

final subscriptionsProvider = FutureProvider<List<Subscription>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).subscriptions();
});

final debtsProvider =
    FutureProvider.family<List<Debt>, String>((ref, direction) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).debts(direction: direction);
});

final subscriptionTotalsProvider =
    FutureProvider<({double monthly, double yearly})>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(planningRepositoryProvider).subscriptionTotals();
});

// ------------------------------------------------- automatic income & savings
final automationRepositoryProvider = Provider<AutomationRepository>(
  (ref) => AutomationRepository(),
);

final recurringIncomesProvider =
    FutureProvider<List<RecurringIncome>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(automationRepositoryProvider).recurringIncomes();
});

/// Ledger rows (done / skipped) for one month key ('YYYY-MM').
final planRunsProvider =
    FutureProvider.family<List<PlanRun>, String>((ref, month) async {
  ref.watch(appBusProvider);
  return ref.read(automationRepositoryProvider).runsForMonth(month);
});

/// Expected automatic income - automatic savings - expenses = actual
/// remaining balance, for the month containing the given date.
final monthPlanSummaryProvider =
    FutureProvider.family<MonthPlanSummary, DateTime>((ref, month) async {
  ref.watch(appBusProvider);
  return ref
      .read(automationRepositoryProvider)
      .summaryForMonth(DateTime(month.year, month.month, 1));
});

/// Single source of truth for the dashboard figures of a month: every total
/// is derived from the stored transactions by [LedgerCalculator].
final monthLedgerProvider =
    FutureProvider.family<MonthLedger, DateTime>((ref, month) async {
  ref.watch(appBusProvider);
  final m = DateTime(month.year, month.month, 1);
  final end = DateUtilsX.monthEnd(m);
  final finance = ref.read(financeRepositoryProvider);
  final planning = ref.read(planningRepositoryProvider);
  final plan = await ref.read(automationRepositoryProvider).summaryForMonth(m);
  return LedgerCalculator.build(
    incomes: await finance.incomeBetween(m, end),
    expenses: await finance.expensesBetween(m, end),
    savings: await planning.savingsTransactionsBetween(m, end),
    categories: [
      ...await finance.categories(),
      ...await finance.categories(income: true),
    ],
    budgets: await planning.budgetsForMonth(DateUtilsX.monthKey(m)),
    expectedIncome: plan.expectedIncome,
    plannedSavings: plan.autoSavings,
  );
});

final loanRepositoryProvider = Provider<LoanRepository>(
  (ref) => LoanRepository(),
);

/// Bank loans with repayment progress and outstanding balance.
final loansProvider = FutureProvider<List<LoanStatus>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(loanRepositoryProvider).statuses();
});

/// Most-used variable expense categories (quick-add shortcuts).
final frequentCategoriesProvider = FutureProvider<List<int>>((ref) async {
  ref.watch(appBusProvider);
  return ref.read(financeRepositoryProvider).frequentExpenseCategoryIds();
});
