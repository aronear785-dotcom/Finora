import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/date_utils.dart' as dutils;
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/budget.dart';
import '../../models/category.dart';
import '../../models/expense.dart';
import '../../models/income.dart';
import '../../models/savings_goal.dart';
import '../../providers/providers.dart';
import '../../services/export_service.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/common_widgets.dart';

/// Monthly financial report with PDF + CSV export. All numbers are real
/// SQLite data; exports are generated locally and shared via the system
/// share sheet (no network).
class ReportScreen extends ConsumerStatefulWidget {
  const ReportScreen({super.key});

  @override
  ConsumerState<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends ConsumerState<ReportScreen> {
  DateTime _month = DateTime.now();

  Future<void> _exportCsv() async {
    try {
      final svc = ExportService();
      final cats = await ref.read(financeRepositoryProvider).categories();
      final catMap = {for (final c in cats) c.id!: c};
      final csv = await svc.buildTransactionsCsv(
        categories: catMap,
        from: dutils.DateUtilsX.monthStart(_month),
        to: dutils.DateUtilsX.monthEnd(_month),
      );
      await svc.shareTextFile(
          csv, 'finora_${dutils.DateUtilsX.monthKey(_month)}.csv', 'FINORA CSV');
    } catch (_) {
      if (mounted) showSnack(context, context.l10n.repExportFailed);
    }
  }

  Future<void> _exportPdf() async {
    try {
      final svc = ExportService();
      final repo = ref.read(financeRepositoryProvider);
      final planning = ref.read(planningRepositoryProvider);
      final cats = await repo.categories();
      final catMap = {for (final c in cats) c.id!: c};
      final expenses = await repo.expensesBetween(
          dutils.DateUtilsX.monthStart(_month),
          dutils.DateUtilsX.monthEnd(_month));
      final incomes = await repo.incomeBetween(
          dutils.DateUtilsX.monthStart(_month),
          dutils.DateUtilsX.monthEnd(_month));
      final savingsTxs = await planning.savingsTransactionsBetween(
          dutils.DateUtilsX.monthStart(_month),
          dutils.DateUtilsX.monthEnd(_month));
      final goals = await planning.savingsGoals();
      final budgets = await planning.budgetsForMonth(
          dutils.DateUtilsX.monthKey(_month));

      final l = context.l10n;
      final bytes = await svc.buildMonthlyReportPdf(
        month: _month,
        currency:
            ref.watch(settingsProvider).valueOrNull?.currency ?? 'MAD',
        categories: catMap,
        expenses: expenses,
        incomes: incomes,
        savingsTxs: savingsTxs,
        goals: goals,
        budgets: budgets,
        monthLabel: context.monthlyLabel(_month),
        tagline: l.tagline,
        lIncome: l.repIncome,
        lExpenses: l.repExpenses,
        lSavings: l.repSavings,
        lAvailable: l.repAvailable,
        lTopCategories: l.repTopCategories,
        lBudgetStatus: l.repBudgetStatus,
        lSavingsProgress: l.savProgress,
        lOverBudget: l.budExceeded,
        lApproaching: l.budApproaching,
        lOnTrack: l.budNormal,
        lGeneratedBy: l.repGeneratedBy,
      );
      await svc.shareBytes(bytes,
          'finora_report_${dutils.DateUtilsX.monthKey(_month)}.pdf',
          'FINORA PDF');
      if (mounted) showSnack(context, l.repExported);
    } catch (_) {
      if (mounted) showSnack(context, context.l10n.repExportFailed);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final expensesAsync = ref.watch(monthExpensesProvider(_month));
    final incomesAsync = ref.watch(monthIncomeProvider(_month));
    final savingsAsync = ref.watch(monthSavingsProvider(_month));
    final budgetsAsync =
        ref.watch(budgetsProvider(dutils.DateUtilsX.monthKey(_month)));
    final goalsAsync = ref.watch(goalsProvider);
    final catsAsync = ref.watch(categoriesProvider);
    final prevMonth = DateTime(_month.year, _month.month - 1, 1);

    return Scaffold(
      appBar: AppBar(
        title: Text(l.repTitle),
        actions: [
          IconButton(
            tooltip: l.repExportCsv,
            icon: const Icon(Icons.table_chart_outlined),
            onPressed: _exportCsv,
          ),
          IconButton(
            tooltip: l.repExportPdf,
            icon: const Icon(Icons.picture_as_pdf_outlined),
            onPressed: _exportPdf,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          MonthHeader(month: _month, onChange: (m) => setState(() => _month = m)),
          const SizedBox(height: 10),
          expensesAsync.when(
            data: (expenses) => incomesAsync.when(
              data: (incomes) => savingsAsync.when(
                data: (savings) {
                  final income = FinanceCalculator.totalIncome(incomes);
                  final expense = FinanceCalculator.totalExpenses(expenses);
                  final available =
                      FinanceCalculator.available(income, expense, savings);
                  final prevExpenses = ref
                          .watch(monthExpensesProvider(prevMonth))
                          .valueOrNull ??
                      const <Expense>[];
                  final prevIncome = ref
                          .watch(monthIncomeProvider(prevMonth))
                          .valueOrNull ??
                      const <Income>[];
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Card(
                        elevation: 0,
                        color: scheme.surface,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20)),
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            children: [
                              _row(scheme, l.repIncome, fmt.format(income),
                                  scheme.primary),
                              const SizedBox(height: 10),
                              _row(scheme, l.repExpenses, fmt.format(expense),
                                  scheme.error),
                              const SizedBox(height: 10),
                              _row(scheme, l.repSavings, fmt.format(savings),
                                  const Color(0xFF00BFA5)),
                              const Divider(height: 20),
                              _row(
                                  scheme,
                                  l.repAvailable,
                                  fmt.format(available),
                                  available < 0
                                      ? scheme.error
                                      : const Color(0xFFFFB300)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        '${l.repCompPrev}: ${fmt.format(expense - FinanceCalculator.totalExpenses(prevExpenses))}'
                        ' · ${fmt.format(income - FinanceCalculator.totalIncome(prevIncome))}',
                        style: TextStyle(
                            fontSize: 12, color: scheme.onSurfaceVariant),
                      ),
                      const SizedBox(height: 12),
                      if (catsAsync.valueOrNull != null &&
                          catsAsync.valueOrNull!.isNotEmpty)
                        _TopCategories(
                            expenses: expenses,
                            catMap: {
                              for (final c in catsAsync.valueOrNull!)
                                c.id!: c
                            },
                            fmt: fmt),
                      if (budgetsAsync.valueOrNull != null &&
                          budgetsAsync.valueOrNull!.isNotEmpty)
                        _BudgetStatusList(
                            budgets: budgetsAsync.valueOrNull!,
                            expenses: expenses,
                            catMap: {
                              for (final c in catsAsync.valueOrNull!) c.id!: c
                            },
                            fmt: fmt),
                      if (goalsAsync.valueOrNull != null &&
                          goalsAsync.valueOrNull!.isNotEmpty)
                        _SavingsProgressList(
                            goals: goalsAsync.valueOrNull!, fmt: fmt),
                    ],
                  );
                },
                loading: () => const SizedBox(
                    height: 180, child: Center(child: CircularProgressIndicator())),
                error: (_, __) => Center(child: Text(l.commonError)),
              ),
              loading: () => const SizedBox(
                  height: 180, child: Center(child: CircularProgressIndicator())),
              error: (_, __) => Center(child: Text(l.commonError)),
            ),
            loading: () => const SizedBox(
                height: 180, child: Center(child: CircularProgressIndicator())),
            error: (_, __) => Center(child: Text(l.commonError)),
          ),
        ],
      ),
    );
  }

  Widget _row(ColorScheme scheme, String label, String value, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(fontSize: 14, color: scheme.onSurfaceVariant)),
        Text(value,
            style:
                TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: color)),
      ],
    );
  }
}

class _TopCategories extends StatelessWidget {
  const _TopCategories({
    required this.expenses,
    required this.catMap,
    required this.fmt,
  });

  final List<Expense> expenses;
  final Map<int, Category> catMap;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final byCat = FinanceCalculator.expensesByCategory(expenses);
    final sorted = byCat.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final total = sorted.fold<double>(0, (s, e) => s + e.value);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionTitle(title: l.repTopCategories),
        Card(
          elevation: 0,
          color: Theme.of(context).colorScheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                for (final e in sorted.take(5))
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            catMap[e.key] != null
                                ? context.categoryLabel(catMap[e.key]!.name)
                                : l.catOther,
                            style: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                        ),
                        Text(
                            total == 0
                                ? '0%'
                                : '${(e.value / total * 100).toStringAsFixed(0)}%',
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: Theme.of(context)
                                    .colorScheme
                                    .primary)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _BudgetStatusList extends StatelessWidget {
  const _BudgetStatusList({
    required this.budgets,
    required this.expenses,
    required this.catMap,
    required this.fmt,
  });

  final List<Budget> budgets;
  final List<Expense> expenses;
  final Map<int, Category> catMap;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final byCat = FinanceCalculator.expensesByCategory(expenses);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionTitle(title: l.repBudgetStatus),
        Card(
          elevation: 0,
          color: Theme.of(context).colorScheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                for (final b in budgets)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            catMap[b.categoryId] != null
                                ? context.categoryLabel(catMap[b.categoryId]!.name)
                                : l.catOther,
                            style: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                        ),
                        Text(
                          '${fmt.formatCompact(byCat[b.categoryId] ?? 0)} / ${fmt.formatCompact(b.amount)} · '
                          '${FinanceCalculator.budgetProgress(byCat[b.categoryId] ?? 0, b.amount).toStringAsFixed(0)}%',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _SavingsProgressList extends ConsumerWidget {
  const _SavingsProgressList({required this.goals, required this.fmt});

  final List<SavingsGoal> goals;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionTitle(title: l.savProgress),
        Card(
          elevation: 0,
          color: Theme.of(context).colorScheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                for (final g in goals)
                  FutureBuilder<double>(
                    future:
                        ref.read(planningRepositoryProvider).savedForGoal(g.id!),
                    builder: (_, snap) {
                      final saved = snap.data ?? 0;
                      final p = FinanceCalculator.goalProgress(saved, g.target);
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(g.name,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600)),
                            ),
                            Text(
                                '${fmt.formatCompact(saved)} / ${fmt.formatCompact(g.target)} · ${p.toStringAsFixed(0)}%',
                                style: const TextStyle(fontSize: 12)),
                          ],
                        ),
                      );
                    },
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
