import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/date_utils.dart' as dutils;
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../providers/providers.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/common_widgets.dart';

/// Savings plan calculator: target / current / monthly -> remaining, months,
/// completion date. Mathematically exact (ceil of remaining/monthly).
class SavingsPlanScreen extends ConsumerStatefulWidget {
  const SavingsPlanScreen({super.key});

  @override
  ConsumerState<SavingsPlanScreen> createState() => _SavingsPlanScreenState();
}

class _SavingsPlanScreenState extends ConsumerState<SavingsPlanScreen> {
  final _targetCtrl = TextEditingController();
  final _currentCtrl = TextEditingController();
  final _monthlyCtrl = TextEditingController();
  DateTime _from = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);

    final target = double.tryParse(_targetCtrl.text.trim().replaceAll(',', '.'));
    final current =
        double.tryParse(_currentCtrl.text.trim().replaceAll(',', '.'));
    final monthly =
        double.tryParse(_monthlyCtrl.text.trim().replaceAll(',', '.'));
    final plan = (target != null && current != null && monthly != null)
        ? FinanceCalculator.savingsPlan(
            target: target,
            current: current,
            monthly: monthly,
            from: _from,
          )
        : null;

    String monthsLabel(int? months) {
      if (months == null) return '∞';
      return '$months ${l.savEstMonths.split(' ').first}';
    }

    return Scaffold(
      appBar: AppBar(title: Text(l.savPlan)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(l.savPlanHint,
              style: TextStyle(
                  fontSize: 13, color: scheme.onSurfaceVariant)),
          const SizedBox(height: 18),
          _input(_targetCtrl, l.savTargetAmount, Icons.flag_outlined),
          const SizedBox(height: 12),
          _input(_currentCtrl, l.savCurrent, Icons.savings_outlined),
          const SizedBox(height: 12),
          _input(_monthlyCtrl, l.savMonthly, Icons.calendar_month_outlined),
          const SizedBox(height: 12),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event_outlined),
            title: Text(l.commonDate,
                style: const TextStyle(fontSize: 14)),
            trailing: Text(
              '${_from.day} ${context.monthName(_from.month)} ${_from.year}',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _from,
                firstDate: DateTime(2000),
                lastDate: DateTime(2100),
              );
              if (picked != null) setState(() => _from = picked);
            },
          ),
          const SizedBox(height: 20),
          if (plan != null)
            Card(
              elevation: 0,
              color: scheme.primaryContainer.withOpacity(0.35),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _resultRow(scheme, l.savRemaining,
                        fmt.format(plan.remaining), scheme.onSurface),
                    const SizedBox(height: 8),
                    _resultRow(scheme, l.savEstMonths,
                        plan.months == null
                            ? (plan.remaining <= 0
                                ? l.savDone
                                : '∞')
                            : '${plan.months}',
                        scheme.primary),
                    const SizedBox(height: 8),
                    _resultRow(
                      scheme,
                      l.savCompletion,
                      plan.completionDate == null
                          ? '∞'
                          : '${plan.completionDate!.day} ${context.monthName(plan.completionDate!.month)} ${plan.completionDate!.year}',
                      plan.remaining <= 0 ? const Color(0xFF00BFA5) : scheme.onSurface,
                    ),
                  ],
                ),
              ),
            )
          else
            EmptyState(
              icon: Icons.calculate_outlined,
              title: l.savPlan,
              subtitle:
                  '${l.savTargetAmount} / ${l.savCurrent} / ${l.savMonthly}',
            ),
        ],
      ),
    );
  }

  Widget _input(TextEditingController c, String label, IconData icon) {
    return TextField(
      controller: c,
      onChanged: (_) => setState(() {}),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
    );
  }

  Widget _resultRow(ColorScheme scheme, String label, String value, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant)),
        Text(value,
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w800, color: color)),
      ],
    );
  }
}
