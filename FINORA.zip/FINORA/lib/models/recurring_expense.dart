import '../core/constants.dart';

/// A recurring expense template. [nextDate] is the next date a transaction
/// should be auto-generated for.
class RecurringExpense {
  const RecurringExpense({
    this.id,
    required this.name,
    required this.amount,
    required this.categoryId,
    required this.frequency,
    required this.nextDate,
    this.active = true,
  });

  final int? id;
  final String name;
  final double amount;
  final int categoryId;
  final String frequency;
  final DateTime nextDate;
  final bool active;

  RecurringExpense copyWith({
    String? name,
    double? amount,
    int? categoryId,
    String? frequency,
    DateTime? nextDate,
    bool? active,
  }) =>
      RecurringExpense(
        id: id,
        name: name ?? this.name,
        amount: amount ?? this.amount,
        categoryId: categoryId ?? this.categoryId,
        frequency: frequency ?? this.frequency,
        nextDate: nextDate ?? this.nextDate,
        active: active ?? this.active,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'amount': amount,
        'category_id': categoryId,
        'frequency': frequency,
        'next_date': nextDate.millisecondsSinceEpoch,
        'active': active ? 1 : 0,
      };

  factory RecurringExpense.fromMap(Map<String, Object?> map) => RecurringExpense(
        id: map['id'] as int?,
        name: map['name'] as String,
        amount: (map['amount'] as num).toDouble(),
        categoryId: map['category_id'] as int,
        frequency: (map['frequency'] as String?) ?? Frequencies.monthly,
        nextDate: DateTime.fromMillisecondsSinceEpoch(map['next_date'] as int),
        active: (map['active'] as int? ?? 1) == 1,
      );
}
