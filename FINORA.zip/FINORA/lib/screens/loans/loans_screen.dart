import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/loan.dart';
import '../../providers/providers.dart';
import '../../repositories/automation_repository.dart';
import '../../widgets/common_widgets.dart';
import '../automation/automation_forms.dart' show DayOfMonthPicker;

/// Bank loans & credits: repayment progress, outstanding balance and the
/// automatic monthly installment (recorded as a FIXED expense).
class LoansScreen extends ConsumerWidget {
  const LoansScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final fmt = ref.watch(moneyFormatterProvider);
    final loansAsync = ref.watch(loansProvider);
    return Scaffold(
      appBar: AppBar(title: Text(l.loanTitle)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showLoanSheet(context),
        icon: const Icon(Icons.add),
        label: Text(l.loanAdd),
      ),
      body: loansAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const SizedBox.shrink(),
        data: (loans) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(l.loanFixedHint,
                  style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
            if (loans.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 32),
                child: Center(child: Text(l.loanEmpty)),
              ),
            for (final s in loans)
              _LoanCard(
                status: s,
                fmt: fmt,
                onEdit: () => _showLoanSheet(context, existing: s.loan),
                onDelete: () async {
                  final ok = await confirmDialog(context,
                      title: l.commonDelete,
                      message: l.loanDeleteConfirm,
                      confirmLabel: l.commonDelete,
                      destructive: true);
                  if (ok) {
                    await ref.read(loanRepositoryProvider).deleteLoan(s.loan.id!);
                  }
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _LoanCard extends StatelessWidget {
  const _LoanCard({
    required this.status,
    required this.fmt,
    required this.onEdit,
    required this.onDelete,
  });

  final LoanStatus status;
  final MoneyFormatter fmt;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final loan = status.loan;
    Widget kv(String k, String v, {bool bold = false}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(
            children: [
              Expanded(
                  child: Text(k,
                      style: TextStyle(
                          fontSize: 12.5, color: scheme.onSurfaceVariant))),
              Text(v,
                  style: TextStyle(
                      fontSize: bold ? 16 : 13,
                      fontWeight: bold ? FontWeight.w800 : FontWeight.w600)),
            ],
          ),
        );
    return Card(
      elevation: 0,
      color: scheme.surface,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: scheme.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 6, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.account_balance_outlined, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(loan.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w800)),
                ),
                PopupMenuButton<String>(
                  onSelected: (v) => v == 'edit' ? onEdit() : onDelete(),
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'edit', child: Text(l.commonEdit)),
                    PopupMenuItem(value: 'delete', child: Text(l.commonDelete)),
                  ],
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ProgressBar(value: status.progress, color: scheme.primary),
                  const SizedBox(height: 4),
                  Text(
                      '${status.paidCount}/${loan.installments} ${l.loanPaidCount}'
                      '${status.finished ? '  ·  ${l.loanFinished}' : ''}',
                      style: TextStyle(
                          fontSize: 12, color: scheme.onSurfaceVariant)),
                  const SizedBox(height: 8),
                  kv(l.loanOutstanding, fmt.format(status.outstanding),
                      bold: true),
                  kv(l.loanMonthly, fmt.format(loan.regularInstallment)),
                  kv(l.loanPrincipalPart,
                      fmt.format(loan.principalPerInstallment)),
                  kv(l.loanInterestPart,
                      fmt.format(loan.interestPerInstallment)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Future<void> _showLoanSheet(BuildContext context, {Loan? existing}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => _LoanSheet(existing: existing),
  );
}

class _LoanSheet extends ConsumerStatefulWidget {
  const _LoanSheet({this.existing});

  final Loan? existing;

  @override
  ConsumerState<_LoanSheet> createState() => _LoanSheetState();
}

class _LoanSheetState extends ConsumerState<_LoanSheet> {
  final _nameCtrl = TextEditingController();
  final _principalCtrl = TextEditingController();
  final _interestCtrl = TextEditingController();
  final _countCtrl = TextEditingController();
  int _day = 1;
  bool _recordReceived = false;
  bool _saving = false;

  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _nameCtrl.text = e.name;
      _principalCtrl.text = e.principal.toStringAsFixed(2);
      _interestCtrl.text = e.totalInterest.toStringAsFixed(2);
      _countCtrl.text = '${e.installments}';
      _day = e.dayOfMonth;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _principalCtrl.dispose();
    _interestCtrl.dispose();
    _countCtrl.dispose();
    super.dispose();
  }

  double? _num(String t) => double.tryParse(t.trim().replaceAll(',', '.'));

  Loan? _draft() {
    final principal = _num(_principalCtrl.text);
    final interest =
        _interestCtrl.text.trim().isEmpty ? 0.0 : _num(_interestCtrl.text);
    final count = int.tryParse(_countCtrl.text.trim());
    if (principal == null || principal <= 0) return null;
    if (interest == null || interest < 0) return null;
    if (count == null || count <= 0 || count > 600) return null;
    final old = widget.existing;
    return Loan(
      id: old?.id,
      name: _nameCtrl.text.trim(),
      principal: principal,
      totalInterest: interest,
      installments: count,
      startMonth:
          old?.startMonth ?? AutomationRepository.nextStartMonth(_day),
      dayOfMonth: _day,
      active: old?.active ?? true,
    );
  }

  Future<void> _save() async {
    final l = context.l10n;
    final loan = _draft();
    if (loan == null) {
      showSnack(context, l.errInvalidAmount);
      return;
    }
    if (loan.name.isEmpty) {
      showSnack(context, l.errEmptyField);
      return;
    }
    setState(() => _saving = true);
    try {
      final repo = ref.read(loanRepositoryProvider);
      if (_isEdit) {
        await repo.updateLoan(loan);
      } else {
        await repo.addLoan(loan,
            receivedOn: _recordReceived ? DateTime.now() : null);
      }
      await ref.read(automationRepositoryProvider).applyDue();
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, l.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final fmt = ref.watch(moneyFormatterProvider);
    final scheme = Theme.of(context).colorScheme;
    final draft = _draft();
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_isEdit ? l.loanEdit : l.loanAdd,
                style:
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            TextField(
              controller: _nameCtrl,
              decoration: InputDecoration(
                labelText: l.commonName,
                prefixIcon: const Icon(Icons.account_balance_outlined),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _principalCtrl,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(labelText: l.loanPrincipal),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _interestCtrl,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(labelText: l.loanInterest),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _countCtrl,
              keyboardType: TextInputType.number,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(labelText: l.loanInstallments),
            ),
            const SizedBox(height: 12),
            DayOfMonthPicker(
                value: _day, onChanged: (d) => setState(() => _day = d)),
            if (draft != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(
                    '${l.loanMonthly}: ${fmt.format(draft.regularInstallment)}',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: scheme.primary)),
              ),
            if (!_isEdit) ...[
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(l.loanRecordReceived),
                subtitle: Text(l.loanReceivedHint,
                    style: const TextStyle(fontSize: 11)),
                value: _recordReceived,
                onChanged: (v) => setState(() => _recordReceived = v),
              ),
              Text(l.autoStartsNext,
                  style: TextStyle(
                      fontSize: 12, color: scheme.onSurfaceVariant)),
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _saving ? null : _save,
                style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15)),
                child: Text(l.commonSave),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
