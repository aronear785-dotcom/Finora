#!/usr/bin/env python3
import json, glob

def camel(k):
    parts = k.split('.')
    if len(parts) == 1:
        return k
    return parts[0] + ''.join(p[:1].upper() + p[1:] for p in parts[1:])

def main():
    en = json.load(open('assets/l10n/app_en.arb', encoding='utf-8'))
    keys = [k for k in en if not k.startswith('@')]
    langs = ['en','fr','ar','es','zh','ru']
    L = []
    L.append('// GENERATED FILE - do not edit by hand. Run: python3 tools/generate_strings.py')
    L.append("import 'dart:convert';")
    L.append("import 'package:flutter/material.dart';")
    L.append("import 'package:flutter/services.dart';")
    L.append('')
    L.append('/// Hand-rolled localizations (no codegen). Loads ARB-style JSON at startup.')
    L.append('class AppLocalizations {')
    L.append('  AppLocalizations(this._map);')
    L.append('  final Map<String, String> _map;')
    L.append('')
    L.append('  static const List<Locale> supportedLocales = [')
    L.append('    ' + ', '.join("Locale('%s')" % l for l in langs) + ',')
    L.append('  ];')
    L.append('')
    L.append('  static Future<AppLocalizations> load(Locale locale) async {')
    L.append('    final lang = locale.languageCode;')
    L.append("    final fallback = jsonDecode(await rootBundle.loadString('assets/l10n/app_en.arb')) as Map<String, dynamic>;")
    L.append('    Map<String, String> map = {};')
    L.append("    if (lang != 'en') {")
    L.append('      try {')
    L.append("        final own = jsonDecode(await rootBundle.loadString('assets/l10n/app_%s.arb')) as Map<String, dynamic>;" % '{lang}')
    L.append('        own.forEach((k, v) => map[k] = v.toString());')
    L.append('      } catch (_) {/* fall back to English */}')
    L.append('    }')
    L.append('    fallback.forEach((k, v) => map.putIfAbsent(k, () => v.toString()));')
    L.append('    return AppLocalizations(map);')
    L.append('  }')
    L.append('')
    L.append('  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();')
    L.append('')
    L.append("  String t(String key) => _map[key] ?? key;")
    L.append('')
    for k in keys:
        L.append("  String get %s => _map['%s'] ?? '%s';" % (camel(k), k, k))
    L.append('}')
    L.append('')
    L.append('class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {')
    L.append('  const _AppLocalizationsDelegate();')
    L.append('  @override')
    L.append('  bool isSupported(Locale locale) => AppLocalizations.supportedLocales.any((l) => l.languageCode == locale.languageCode);')
    L.append('  @override')
    L.append('  Future<AppLocalizations> load(Locale locale) => AppLocalizations.load(locale);')
    L.append('  @override')
    L.append('  bool shouldReload(_AppLocalizationsDelegate old) => false;')
    L.append('}')
    open('lib/l10n/app_localizations.dart', 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('wrote lib/l10n/app_localizations.dart with', len(keys), 'keys')

if __name__ == '__main__':
    main()
