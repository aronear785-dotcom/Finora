import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Create / edit a custom expense category (name, icon, color).
class CategoryFormDialog extends ConsumerStatefulWidget {
  const CategoryFormDialog({super.key, this.category});

  final Category? category;

  @override
  ConsumerState<CategoryFormDialog> createState() =>
      _CategoryFormDialogState();
}

class _CategoryFormDialogState extends ConsumerState<CategoryFormDialog> {
  final _nameCtrl = TextEditingController();
  int _color = 0xFF6C4DF6;
  String _icon = 'category';
  bool _saving = false;

  bool get _isEdit => widget.category != null;

  @override
  void initState() {
    super.initState();
    final c = widget.category;
    if (c != null) {
      _nameCtrl.text = c.isCustom ? c.name : '';
      _color = c.color;
      _icon = c.icon;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      showSnack(context, context.l10n.errEmptyField);
      return;
    }
    setState(() => _saving = true);
    final repo = ref.read(financeRepositoryProvider);
    final existing = widget.category;
    final category = Category(
      id: existing?.id,
      name: name,
      icon: _icon,
      color: _color,
      isIncome: existing?.isIncome ?? false,
      isCustom: true,
    );
    try {
      if (_isEdit && existing != null) {
        await repo.updateCategory(category);
      } else {
        await repo.addCategory(category);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.catEdit : l.catAdd)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _nameCtrl,
            decoration: InputDecoration(
              labelText: l.catName,
              prefixIcon: const Icon(Icons.label_outline),
            ),
          ),
          const SizedBox(height: 20),
          Text(l.catColor,
              style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          ColorChoiceBar(
              selected: _color, onSelect: (c) => setState(() => _color = c)),
          const SizedBox(height: 20),
          Text(l.catIcon,
              style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.fromInt(_color).withOpacity(0.14),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(AppIcons.resolve(_icon),
                    color: AppColors.fromInt(_color)),
              ),
              const SizedBox(width: 12),
              OutlinedButton.icon(
                onPressed: () async {
                  final picked = await pickIcon(context, current: _icon);
                  if (picked != null) setState(() => _icon = picked);
                },
                icon: const Icon(Icons.grid_view_outlined),
                label: Text(l.commonSelect),
              ),
            ],
          ),
          const SizedBox(height: 28),
          FilledButton(
            onPressed: _saving ? null : _save,
            style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15)),
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : Text(l.commonSave),
          ),
        ],
      ),
    );
  }
}
