import 'package:sqflite/sqflite.dart';

import '../core/constants.dart';
import '../core/utils/app_bus.dart';
import '../database/app_database.dart';
import '../models/budget.dart';
import '../models/debt.dart';
import '../models/income.dart';
import '../models/recurring_expense.dart';
import '../models/savings_goal.dart';
import '../models/savings_transaction.dart';
import '../models/subscription.dart';
import '../services/finance_calculator.dart';
import 'finance_repository.dart';

/// Budgets, savings goals & transactions, recurring expenses,
/// subscriptions, debts - all with real SQLite persistence.
/// Accepts an injected [AppDatabase] so tests can run against an in-memory DB.
class PlanningRepository {
  PlanningRepository({FinanceRepository? finance, AppDatabase? db})
      : _finance = finance,
        _db = db ?? AppDatabase.instance;

  final FinanceRepository? _finance;
  final AppDatabase _db;

  Future<Database> get _database => _db.database;

  // ------------------------------------------------------------------- budgets
  Future<List<Budget>> budgetsForMonth(String month) async {
    final db = await _database;
    final rows = await db.query(
      'budgets',
      where: 'month = ?',
      whereArgs: [month],
      orderBy: 'id ASC',
    );
    return rows.map(Budget.fromMap).toList();
  }

  Future<List<Budget>> allBudgets() async {
    final db = await _database;
    final rows = await db.query('budgets', orderBy: 'month DESC, id ASC');
    return rows.map(Budget.fromMap).toList();
  }

  Future<Budget?> budgetFor(int categoryId, String month) async {
    final db = await _database;
    final rows = await db.query(
      'budgets',
      where: 'category_id = ? AND month = ?',
      whereArgs: [categoryId, month],
      limit: 1,
    );
    return rows.isEmpty ? null : Budget.fromMap(rows.first);
  }

  /// Saves a budget for a category/month (upsert on the unique pair).
  Future<void> setBudget(Budget budget) async {
    final db = await _database;
    await db.transaction((txn) async {
      final existing = await txn.query(
        'budgets',
        where: 'category_id = ? AND month = ?',
        whereArgs: [budget.categoryId, budget.month],
        limit: 1,
      );
      if (existing.isNotEmpty) {
        final old = Budget.fromMap(existing.first);
        await txn.update(
          'budgets',
          budget.copyWith(id: old.id).toMap(),
          where: 'id = ?',
          whereArgs: [old.id],
        );
      } else {
        await txn.insert('budgets', budget.toMap());
      }
    });
    AppBus.instance.bump();
  }

  /// Copies the given budgets to the next month. Existing budgets there are
  /// left untouched to avoid silent overwrites.
  Future<void> copyBudgetsToNextMonth(String fromMonth) async {
    final db = await _database;
    final parts = fromMonth.split('-');
    final year = int.parse(parts[0]);
    final month = int.parse(parts[1]);
    final next = DateTime(year, month + 1, 1);
    final key = '${next.year.toString().padLeft(4, '0')}-'
        '${next.month.toString().padLeft(2, '0')}';
    final budgets = await budgetsForMonth(fromMonth);
    await db.transaction((txn) async {
      for (final b in budgets) {
        final exists = await txn.query(
          'budgets',
          where: 'category_id = ? AND month = ?',
          whereArgs: [b.categoryId, key],
          limit: 1,
        );
        if (exists.isEmpty) {
          await txn.insert('budgets',
              Budget(categoryId: b.categoryId, amount: b.amount, month: key).toMap());
        }
      }
    });
    AppBus.instance.bump();
  }

  // ------------------------------------------------------------ savings goals
  Future<List<SavingsGoal>> savingsGoals() async {
    final db = await _database;
    final rows = await db.query('savings_goals', orderBy: 'id DESC');
    return rows.map(SavingsGoal.fromMap).toList();
  }

  Future<SavingsGoal?> savingsGoal(int id) async {
    final db = await _database;
    final rows = await db.query('savings_goals', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : SavingsGoal.fromMap(rows.first);
  }

  Future<int> addSavingsGoal(SavingsGoal goal) async {
    final db = await _database;
    final id = await db.insert('savings_goals', goal.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<void> updateSavingsGoal(SavingsGoal goal) async {
    final db = await _database;
    await db.update('savings_goals', goal.toMap(),
        where: 'id = ?', whereArgs: [goal.id]);
    AppBus.instance.bump();
  }

  /// Deleting a goal cascades to its transactions (FK ON DELETE CASCADE).
  Future<void> deleteSavingsGoal(int id) async {
    final db = await _database;
    await db.delete('savings_goals', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  /// Saved amount for a goal = sum of its signed transactions.
  Future<double> savedForGoal(int goalId) async {
    final db = await _database;
    final rows = await db.rawQuery(
        'SELECT COALESCE(SUM(amount),0) AS s FROM savings_transactions WHERE goal_id = ?',
        [goalId]);
    return (rows.first['s'] as num).toDouble();
  }

  Future<List<SavingsTransaction>> transactionsForGoal(int goalId) async {
    final db = await _database;
    final rows = await db.query(
      'savings_transactions',
      where: 'goal_id = ?',
      whereArgs: [goalId],
      orderBy: 'date DESC',
    );
    return rows.map(SavingsTransaction.fromMap).toList();
  }

  /// Total saved across ALL goals = sum of all savings transactions.
  Future<double> totalSaved() async {
    final db = await _database;
    final rows = await db.rawQuery(
        'SELECT COALESCE(SUM(amount),0) AS s FROM savings_transactions');
    return (rows.first['s'] as num).toDouble();
  }

  /// Saved amount between two dates (for monthly "savings" figures).
  Future<double> savedBetween(DateTime start, DateTime end) async {
    final db = await _database;
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(amount),0) AS s FROM savings_transactions WHERE date >= ? AND date <= ?',
      [start.millisecondsSinceEpoch, end.millisecondsSinceEpoch],
    );
    return (rows.first['s'] as num).toDouble();
  }

  /// Signed savings transactions between two dates (for period analysis).
  Future<List<SavingsTransaction>> savingsTransactionsBetween(
      DateTime start, DateTime end) async {
    final db = await _database;
    final rows = await db.query(
      'savings_transactions',
      where: 'date >= ? AND date <= ?',
      whereArgs: [start.millisecondsSinceEpoch, end.millisecondsSinceEpoch],
      orderBy: 'date ASC',
    );
    return rows.map(SavingsTransaction.fromMap).toList();
  }

  Future<int> addSavingsTransaction(SavingsTransaction tx) async {
    final db = await _database;
    final id = await db.insert('savings_transactions', tx.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<void> updateSavingsTransaction(SavingsTransaction tx) async {
    final db = await _database;
    await db.update('savings_transactions', tx.toMap(),
        where: 'id = ?', whereArgs: [tx.id]);
    AppBus.instance.bump();
  }

  Future<void> deleteSavingsTransaction(int id) async {
    final db = await _database;
    await db.delete('savings_transactions', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  // ------------------------------------------------------- recurring expenses
  Future<List<RecurringExpense>> recurringExpenses({bool onlyActive = false}) async {
    final db = await _database;
    final rows = await db.query(
      'recurring_expenses',
      where: onlyActive ? 'active = 1' : null,
      orderBy: 'next_date ASC',
    );
    return rows.map(RecurringExpense.fromMap).toList();
  }

  Future<int> addRecurringExpense(RecurringExpense r) async {
    final db = await _database;
    final id = await db.insert('recurring_expenses', r.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<void> updateRecurringExpense(RecurringExpense r) async {
    final db = await _database;
    await db.update('recurring_expenses', r.toMap(),
        where: 'id = ?', whereArgs: [r.id]);
    AppBus.instance.bump();
  }

  Future<void> deleteRecurringExpense(int id) async {
    final db = await _database;
    await db.delete('recurring_expenses', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  /// Generates expense rows for every due recurring template since [since]
  /// (default: the last 6 months, capped to the last [maxPerTemplate] payments
  /// per template so a long-paused template cannot flood the ledger).
  ///
  /// Duplicate prevention: every generated transaction stores its source
  /// template id + occurrence date ([recurring_source_id]). Before inserting,
  /// previously generated transactions for each template inside the window
  /// are deleted, then re-inserted fresh - so re-running this service can
  /// never create duplicates, while edits to a template are reflected.
  Future<int> generateDueTransactions({
    DateTime? since,
    int maxPerTemplate = 60,
  }) async {
    final db = await _database;
    final templates = await recurringExpenses(onlyActive: true);
    if (templates.isEmpty) return 0;

    final cutoff = since?.millisecondsSinceEpoch ??
        DateTime.now().subtract(const Duration(days: 180)).millisecondsSinceEpoch;
    final now = DateTime.now();
    var generated = 0;

    await db.transaction((txn) async {
      for (final t in templates) {
        final occurrences = <DateTime>[];
        var next = DateTime.fromMillisecondsSinceEpoch(t.nextDate.millisecondsSinceEpoch);
        next = DateTime(next.year, next.month, next.day);
        while (!next.isAfter(now) && occurrences.length < maxPerTemplate) {
          occurrences.add(next);
          next = _advance(next, t.frequency);
        }
        if (occurrences.isEmpty) continue;

        final windowStart = occurrences.first.millisecondsSinceEpoch;
        final windowEnd = occurrences.last.millisecondsSinceEpoch;
        await txn.delete(
          'expenses',
          where: 'recurring_source_id = ? AND date >= ? AND date <= ?',
          whereArgs: [t.id, windowStart, windowEnd],
        );
        for (final occ in occurrences) {
          if (occ.millisecondsSinceEpoch < cutoff) continue;
          await txn.insert('expenses', {
            'amount': t.amount,
            'category_id': t.categoryId,
            'date': occ.millisecondsSinceEpoch,
            'note': t.name,
            'recurring_source_id': t.id,
            'created_at': AppDatabase.now(),
          });
          generated++;
        }
        final newNext = _advance(occurrences.last, t.frequency);
        await txn.update(
          'recurring_expenses',
          {'next_date': newNext.millisecondsSinceEpoch},
          where: 'id = ?',
          whereArgs: [t.id],
        );
      }
    });
    AppBus.instance.bump();
    return generated;
  }

  DateTime _advance(DateTime d, String freq) {
    switch (freq) {
      case Frequencies.daily:
        return d.add(const Duration(days: 1));
      case Frequencies.weekly:
        return d.add(const Duration(days: 7));
      case Frequencies.yearly:
        return DateTime(d.year + 1, d.month, d.day);
      case Frequencies.monthly:
      default:
        return DateTime(d.year, d.month + 1, d.day);
    }
  }

  // ------------------------------------------------------------ subscriptions
  Future<List<Subscription>> subscriptions() async {
    final db = await _database;
    final rows = await db.query('subscriptions', orderBy: 'id DESC');
    return rows.map(Subscription.fromMap).toList();
  }

  Future<int> addSubscription(Subscription s) async {
    final db = await _database;
    final id = await db.insert('subscriptions', s.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<void> updateSubscription(Subscription s) async {
    final db = await _database;
    await db.update('subscriptions', s.toMap(),
        where: 'id = ?', whereArgs: [s.id]);
    AppBus.instance.bump();
  }

  Future<void> deleteSubscription(int id) async {
    final db = await _database;
    await db.delete('subscriptions', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  /// Monthly + yearly totals of ACTIVE subscriptions (planning figures).
  Future<({double monthly, double yearly})> subscriptionTotals() async {
    final list = await subscriptions();
    var monthly = 0.0;
    for (final s in list.where((s) => s.active)) {
      monthly += s.period == 'monthly' ? s.amount : s.amount / 12;
    }
    return (monthly: monthly, yearly: monthly * 12);
  }

  // --------------------------------------------------------------------- debts
  Future<List<Debt>> debts({String? direction}) async {
    final db = await _database;
    final rows = await db.query(
      'debts',
      where: direction == null ? null : 'direction = ?',
      whereArgs: direction == null ? null : [direction],
      orderBy: 'status ASC, date DESC',
    );
    return rows.map(Debt.fromMap).toList();
  }

  Future<int> addDebt(Debt d) async {
    final db = await _database;
    final id = await db.insert('debts', d.toMap());
    AppBus.instance.bump();
    return id;
  }

  Future<void> updateDebt(Debt d) async {
    final db = await _database;
    await db.update('debts', d.toMap(), where: 'id = ?', whereArgs: [d.id]);
    AppBus.instance.bump();
  }

  Future<void> deleteDebt(int id) async {
    final db = await _database;
    await db.delete('debts', where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  Future<void> markDebtPaid(int id) async {
    final db = await _database;
    await db.update('debts', {'status': 'paid'}, where: 'id = ?', whereArgs: [id]);
    AppBus.instance.bump();
  }

  // ------------------------------------------------------------------ helpers
  /// Income sum between dates (kept here so screens don't do SQL).
  Future<double> incomeBetween(DateTime start, DateTime end) async {
    final rows = _finance == null
        ? const <Income>[] as List<Income>
        : await _finance!.incomeBetween(start, end);
    return FinanceCalculator.totalIncome(rows);
  }
}
