/// A transfer in/out of a savings goal. Positive amount = add, negative = withdraw.
class SavingsTransaction {
  const SavingsTransaction({
    this.id,
    required this.goalId,
    required this.amount,
    required this.date,
    this.note,
  });

  final int? id;
  final int goalId;
  final double amount;
  final DateTime date;
  final String? note;

  SavingsTransaction copyWith({double? amount, DateTime? date, String? note}) =>
      SavingsTransaction(
        id: id,
        goalId: goalId,
        amount: amount ?? this.amount,
        date: date ?? this.date,
        note: note ?? this.note,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'goal_id': goalId,
        'amount': amount,
        'date': date.millisecondsSinceEpoch,
        'note': note,
      };

  factory SavingsTransaction.fromMap(Map<String, Object?> map) => SavingsTransaction(
        id: map['id'] as int?,
        goalId: map['goal_id'] as int,
        amount: (map['amount'] as num).toDouble(),
        date: DateTime.fromMillisecondsSinceEpoch(map['date'] as int),
        note: map['note'] as String?,
      );
}
