import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/date_utils.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/recurring_income.dart';
import '../../models/savings_plan.dart';
import '../../providers/providers.dart';
import '../../repositories/automation_repository.dart';
import '../../widgets/common_widgets.dart';

/// Add / edit an automatic monthly income.
Future<void> showRecurringIncomeSheet(BuildContext context,
    {RecurringIncome? existing}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => _IncomePlanSheet(existing: existing),
  );
}

/// Add / edit an automatic monthly savings installment (one per goal).
Future<void> showSavingsPlanSheet(BuildContext context,
    {SavingsPlan? existing}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => _SavingsPlanSheet(existing: existing),
  );
}

double? _parseAmount(String text) =>
    double.tryParse(text.trim().replaceAll(',', '.'));

/// Day-of-month picker (1-31; short months use their last day).
class DayOfMonthPicker extends StatelessWidget {
  const DayOfMonthPicker({super.key, required this.value, required this.onChanged});

  final int value;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return InputDecorator(
      decoration: InputDecoration(
        labelText: l.autoDayOfMonth,
        helperText: l.autoDayHint,
        prefixIcon: const Icon(Icons.event_repeat_outlined),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<int>(
          value: value,
          isDense: true,
          isExpanded: true,
          items: [
            for (var d = 1; d <= 31; d++)
              DropdownMenuItem(value: d, child: Text('$d')),
          ],
          onChanged: (v) {
            if (v != null) onChanged(v);
          },
        ),
      ),
    );
  }
}

class _SheetFrame extends StatelessWidget {
  const _SheetFrame({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style:
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            ...children,
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------- income
class _IncomePlanSheet extends ConsumerStatefulWidget {
  const _IncomePlanSheet({this.existing});

  final RecurringIncome? existing;

  @override
  ConsumerState<_IncomePlanSheet> createState() => _IncomePlanSheetState();
}

class _IncomePlanSheetState extends ConsumerState<_IncomePlanSheet> {
  final _nameCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  int? _categoryId;
  int _day = 1;
  bool _active = true;
  bool _saving = false;
  String? _endMonth;
  bool _autoReceive = true;

  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _endMonth = e.endMonth;
      _autoReceive = e.autoReceive;
      _nameCtrl.text = e.name;
      _amountCtrl.text = e.amount.toStringAsFixed(2);
      _categoryId = e.categoryId;
      _day = e.dayOfMonth;
      _active = e.active;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final l = context.l10n;
    final amount = _parseAmount(_amountCtrl.text);
    final categoryId = _categoryId;
    if (amount == null || amount <= 0) {
      showSnack(context, l.errInvalidAmount);
      return;
    }
    if (categoryId == null) return;
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      showSnack(context, l.errEmptyField);
      return;
    }
    setState(() => _saving = true);
    final repo = ref.read(automationRepositoryProvider);
    try {
      final old = widget.existing;
      // A new plan - or one that was paused and is re-activated - starts at
      // its next due date, so nothing in the past is back-filled.
      final reactivated = old != null && !old.active && _active;
      final startMonth = (old == null || reactivated)
          ? AutomationRepository.nextStartMonth(_day)
          : old.startMonth;
      final endMonth = _endMonth;
      if (endMonth != null && endMonth.compareTo(startMonth) < 0) {
        setState(() => _saving = false);
        showSnack(context, l.autoErrEnd);
        return;
      }
      final plan = RecurringIncome(
        id: old?.id,
        name: name,
        amount: amount,
        categoryId: categoryId,
        dayOfMonth: _day,
        startMonth: startMonth,
        endMonth: endMonth,
        autoReceive: _autoReceive,
        active: _active,
      );
      if (old == null) {
        await repo.addRecurringIncome(plan);
      } else {
        await repo.updateRecurringIncome(plan);
      }
      await repo.applyDue();
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, l.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final catsAsync = ref.watch(incomeCategoriesProvider);
    return _SheetFrame(
      title: _isEdit ? l.autoEditIncome : l.autoAddIncome,
      children: [
        TextField(
          controller: _nameCtrl,
          decoration: InputDecoration(
            labelText: l.commonName,
            prefixIcon: const Icon(Icons.badge_outlined),
          ),
        ),
        const SizedBox(height: 12),
        AmountField(controller: _amountCtrl, hint: '0.00'),
        const SizedBox(height: 12),
        catsAsync.when(
          data: (cats) {
            _categoryId ??= cats.isEmpty ? null : cats.first.id;
            return Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in cats)
                  ChoiceChip(
                    label: Text(context.incomeLabel(c.name)),
                    selected: _categoryId == c.id,
                    onSelected: (_) => setState(() => _categoryId = c.id),
                  ),
              ],
            );
          },
          loading: () => const SizedBox(height: 40),
          error: (_, __) => const SizedBox(height: 40),
        ),
        const SizedBox(height: 12),
        DayOfMonthPicker(value: _day, onChanged: (d) => setState(() => _day = d)),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () async {
            final now = DateTime.now();
            final picked = await showDatePicker(
              context: context,
              initialDate: now,
              firstDate: DateTime(now.year - 1),
              lastDate: DateTime(now.year + 30),
            );
            if (picked != null) {
              setState(() => _endMonth = DateUtilsX.monthKey(picked));
            }
          },
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: l.autoEndMonth,
              prefixIcon: const Icon(Icons.event_busy_outlined),
              suffixIcon: _endMonth == null
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () => setState(() => _endMonth = null),
                    ),
            ),
            child: Text(_endMonth ?? l.autoNoEnd),
          ),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(l.autoConfirmReceipt),
          subtitle: Text(l.autoConfirmReceiptHint,
              style: const TextStyle(fontSize: 11)),
          value: !_autoReceive,
          onChanged: (v) => setState(() => _autoReceive = !v),
        ),
        if (_isEdit)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(l.autoActive),
            value: _active,
            onChanged: (v) => setState(() => _active = v),
          )
        else
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(l.autoStartsNext,
                style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: _saving ? null : _save,
            style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15)),
            child: Text(l.commonSave),
          ),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------ savings
class _SavingsPlanSheet extends ConsumerStatefulWidget {
  const _SavingsPlanSheet({this.existing});

  final SavingsPlan? existing;

  @override
  ConsumerState<_SavingsPlanSheet> createState() => _SavingsPlanSheetState();
}

class _SavingsPlanSheetState extends ConsumerState<_SavingsPlanSheet> {
  final _amountCtrl = TextEditingController();
  int? _goalId;
  int _day = 1;
  bool _active = true;
  bool _saving = false;

  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _amountCtrl.text = e.amount.toStringAsFixed(2);
      _goalId = e.goalId;
      _day = e.dayOfMonth;
      _active = e.active;
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final l = context.l10n;
    final amount = _parseAmount(_amountCtrl.text);
    final goalId = _goalId;
    if (amount == null || amount <= 0) {
      showSnack(context, l.errInvalidAmount);
      return;
    }
    if (goalId == null) return;
    setState(() => _saving = true);
    final repo = ref.read(automationRepositoryProvider);
    try {
      final old = widget.existing;
      final reactivated = old != null && !old.active && _active;
      final startMonth = (old == null || reactivated || old.goalId != goalId)
          ? AutomationRepository.nextStartMonth(_day)
          : old.startMonth;
      await repo.saveSavingsPlan(SavingsPlan(
        id: old?.id,
        goalId: goalId,
        amount: amount,
        dayOfMonth: _day,
        startMonth: startMonth,
        active: _active,
      ));
      await repo.applyDue();
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, l.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final goalsAsync = ref.watch(goalsProvider);
    return _SheetFrame(
      title: _isEdit ? l.autoEditSavings : l.autoAddSavings,
      children: [
        goalsAsync.when(
          data: (goals) {
            if (goals.isEmpty) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(l.autoNoGoal),
              );
            }
            _goalId ??= goals.first.id;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l.quickGoal,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final g in goals)
                      ChoiceChip(
                        avatar: Icon(AppIcons.resolve(g.icon),
                            size: 16, color: AppColors.fromInt(g.color)),
                        label: Text(g.name),
                        selected: _goalId == g.id,
                        onSelected: (_) => setState(() => _goalId = g.id),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                AmountField(controller: _amountCtrl, hint: '0.00'),
                const SizedBox(height: 12),
                DayOfMonthPicker(
                    value: _day, onChanged: (d) => setState(() => _day = d)),
                if (_isEdit)
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(l.autoActive),
                    value: _active,
                    onChanged: (v) => setState(() => _active = v),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(l.autoStartsNext,
                        style: TextStyle(
                            fontSize: 12,
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant)),
                  ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _saving ? null : _save,
                    style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 15)),
                    child: Text(l.commonSave),
                  ),
                ),
              ],
            );
          },
          loading: () => const SizedBox(
              height: 80, child: Center(child: CircularProgressIndicator())),
          error: (_, __) => const SizedBox(height: 80),
        ),
      ],
    );
  }
}
