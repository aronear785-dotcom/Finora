import '../domain/money.dart';

/// A bank loan / credit that is repaid in fixed monthly installments.
///
/// * The installments are recorded as FIXED expenses (category "loan"), so
///   they reduce the available balance but never a variable budget.
/// * The money received when the loan was taken is income in the separate
///   "loan received" category, never earned income.
/// * Principal / interest are split straight-line (equal parts per
///   installment); the last installment absorbs cent rounding.
class Loan {
  const Loan({
    this.id,
    required this.name,
    required this.principal,
    this.totalInterest = 0,
    required this.installments,
    required this.startMonth,
    this.dayOfMonth = 1,
    this.active = true,
  });

  final int? id;
  final String name;
  final double principal;

  /// Interest and fees over the whole loan.
  final double totalInterest;
  final int installments;
  final String startMonth; // 'YYYY-MM' of the first installment
  final int dayOfMonth;
  final bool active;

  double get totalOwed => Money.sum([principal, totalInterest]);

  /// Amount of installment [number] (1-based).
  double installmentAmount(int number) {
    final total = Money.toCents(totalOwed);
    final base = total ~/ installments;
    final cents = number == installments ? total - base * (installments - 1) : base;
    return Money.fromCents(cents);
  }

  double get regularInstallment => installmentAmount(1);
  double get principalPerInstallment => principal / installments;
  double get interestPerInstallment => totalInterest / installments;

  Loan copyWith({
    String? name,
    double? principal,
    double? totalInterest,
    int? installments,
    String? startMonth,
    int? dayOfMonth,
    bool? active,
  }) =>
      Loan(
        id: id,
        name: name ?? this.name,
        principal: principal ?? this.principal,
        totalInterest: totalInterest ?? this.totalInterest,
        installments: installments ?? this.installments,
        startMonth: startMonth ?? this.startMonth,
        dayOfMonth: dayOfMonth ?? this.dayOfMonth,
        active: active ?? this.active,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'principal': principal,
        'total_interest': totalInterest,
        'installments': installments,
        'start_month': startMonth,
        'day_of_month': dayOfMonth,
        'active': active ? 1 : 0,
      };

  factory Loan.fromMap(Map<String, Object?> map) => Loan(
        id: map['id'] as int?,
        name: map['name'] as String,
        principal: (map['principal'] as num).toDouble(),
        totalInterest: (map['total_interest'] as num?)?.toDouble() ?? 0,
        installments: map['installments'] as int,
        startMonth: map['start_month'] as String,
        dayOfMonth: (map['day_of_month'] as int?) ?? 1,
        active: (map['active'] as int? ?? 1) == 1,
      );
}

/// A loan with its repayment progress.
class LoanStatus {
  const LoanStatus({
    required this.loan,
    required this.paidCount,
    required this.paidAmount,
  });

  final Loan loan;
  final int paidCount;
  final double paidAmount;

  /// Amount still owed (never negative).
  double get outstanding {
    final left = Money.subtract(loan.totalOwed, paidAmount);
    return left < 0 ? 0 : left;
  }

  bool get finished => paidCount >= loan.installments;

  double get progress => loan.totalOwed <= 0
      ? 1
      : (paidAmount / loan.totalOwed).clamp(0.0, 1.0).toDouble();

  /// Principal repaid so far (straight-line split).
  double get principalPaid => loan.principalPerInstallment * paidCount;
}
