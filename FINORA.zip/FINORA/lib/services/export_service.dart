import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart' hide Category;
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

import '../core/utils/app_bus.dart';
import '../database/app_database.dart';
import '../models/budget.dart';
import '../models/category.dart';
import '../models/expense.dart';
import '../models/income.dart';
import '../models/savings_goal.dart';
import '../models/savings_transaction.dart';
import '../repositories/finance_repository.dart';
import '../repositories/planning_repository.dart';
import 'finance_calculator.dart';

/// Export & backup: CSV of transactions, JSON full backup with strict restore
/// validation, and a locally-rendered PDF monthly report.
class ExportService {
  ExportService({FinanceRepository? finance, PlanningRepository? planning})
      : _finance = finance ?? FinanceRepository(),
        _planning = planning ?? PlanningRepository();

  final FinanceRepository _finance;
  final PlanningRepository _planning;

  String _escapeCsv(String v) {
    if (v.contains(',') || v.contains('"') || v.contains('\n')) {
      return '"${v.replaceAll('"', '""')}"';
    }
    return v;
  }

  /// CSV with all transactions (expenses + income), UTF-8 with BOM so Excel
  /// opens it correctly in any locale. Headers are localized by the caller.
  Future<String> buildTransactionsCsv({
    required Map<int, Category> categories,
    DateTime? from,
    DateTime? to,
    List<String> headers = const ['type', 'date', 'amount', 'category', 'note'],
  }) async {
    final expenses = from == null
        ? await _finance.allExpenses()
        : await _finance.expensesBetween(from, to ?? DateTime.now());
    final incomes = from == null
        ? await _finance.allIncome()
        : await _finance.incomeBetween(from, to ?? DateTime.now());

    final sb = StringBuffer('\uFEFF');
    sb.writeln(headers.join(','));
    for (final e in expenses) {
      final cat = categories[e.categoryId];
      sb.writeln(
          'expense,${_escapeCsv(_isoDate(e.date))},${e.amount},${_escapeCsv(cat?.name ?? 'other')},${_escapeCsv(e.note ?? '')}');
    }
    for (final i in incomes) {
      final cat = categories[i.categoryId];
      sb.writeln(
          'income,${_escapeCsv(_isoDate(i.date))},${i.amount},${_escapeCsv(cat?.name ?? 'other')},${_escapeCsv(i.note ?? '')}');
    }
    return sb.toString();
  }

  /// Full JSON backup (includes settings). Restored by [restoreBackup].
  Future<String> buildJsonBackup() async {
    final db = await AppDatabase.instance.database;
    final data = <String, Object?>{
      'app': 'FINORA',
      'version': 1,
      'exported_at': DateTime.now().toIso8601String(),
      'settings': await db.query('settings'),
      'categories': await db.query('categories'),
      'income': await db.query('income'),
      'expenses': await db.query('expenses'),
      'budgets': await db.query('budgets'),
      'savings_goals': await db.query('savings_goals'),
      'savings_transactions': await db.query('savings_transactions'),
      'recurring_expenses': await db.query('recurring_expenses'),
      'subscriptions': await db.query('subscriptions'),
      'debts': await db.query('debts'),
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  /// Restores a backup after strict validation. Throws [FormatException] on
  /// any structural problem; nothing is written until everything validates.
  Future<void> restoreBackup(String jsonString) async {
    final Map<String, dynamic> data;
    try {
      data = jsonDecode(jsonString) as Map<String, dynamic>;
    } catch (_) {
      throw const FormatException('invalid JSON');
    }
    if (data['app'] != 'FINORA') {
      throw const FormatException('not a FINORA backup');
    }
    const requiredTables = [
      'settings',
      'categories',
      'income',
      'expenses',
      'budgets',
      'savings_goals',
      'savings_transactions',
      'recurring_expenses',
      'subscriptions',
      'debts',
    ];
    for (final t in requiredTables) {
      if (data[t] is! List) throw FormatException('missing table $t');
    }

    final db = await AppDatabase.instance.database;
    final tables = [
      'savings_transactions',
      'savings_goals',
      'income',
      'expenses',
      'budgets',
      'recurring_expenses',
      'subscriptions',
      'debts',
      'categories',
    ];
    await db.transaction((txn) async {
      for (final t in tables) {
        await txn.delete(t);
      }
      for (final t in tables) {
        final rows = data[t] as List<dynamic>;
        for (final row in rows.cast<Map<String, dynamic>>()) {
          await txn.insert(t, row);
        }
      }
      final settings = (data['settings'] as List).cast<Map<String, dynamic>>();
      if (settings.isNotEmpty) {
        await txn.delete('settings');
        await txn.insert('settings', settings.first);
      }
    });
    AppBus.instance.bump();
  }

  /// Local PDF monthly report (bundled DejaVu font = full Latin/Cyrillic
  /// glyph coverage). Localized labels are passed in by the caller.
  Future<Uint8List> buildMonthlyReportPdf({
    required DateTime month,
    required String currency,
    required Map<int, Category> categories,
    required List<Expense> expenses,
    required List<Income> incomes,
    required List<SavingsTransaction> savingsTxs,
    required List<SavingsGoal> goals,
    required List<Budget> budgets,
    required String monthLabel,
    required String tagline,
    required String lIncome,
    required String lExpenses,
    required String lSavings,
    required String lAvailable,
    required String lTopCategories,
    required String lBudgetStatus,
    required String lSavingsProgress,
    required String lOverBudget,
    required String lApproaching,
    required String lOnTrack,
    required String lGeneratedBy,
  }) async {
    final incomeTotal = FinanceCalculator.totalIncome(incomes);
    final expenseTotal = FinanceCalculator.totalExpenses(expenses);
    final savedTotal = savingsTxs.fold<double>(0, (s, t) => s + t.amount);
    final available = FinanceCalculator.available(incomeTotal, expenseTotal, savedTotal);

    final byCat = FinanceCalculator.expensesByCategory(expenses);
    final topCats = byCat.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final font = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf'));

    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(base: font, bold: bold),
        pageFormat: PdfPageFormat.a4,
        build: (_) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Text('FINORA',
                  style: pw.TextStyle(font: bold, fontSize: 26, color: PdfColor.fromInt(0xFF6C4DF6))),
              pw.Text(monthLabel, style: pw.TextStyle(font: bold, fontSize: 14)),
            ],
          ),
          pw.SizedBox(height: 4),
          pw.Text(tagline,
              style: pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
          pw.SizedBox(height: 18),
          pw.TableHelper.fromTextArray(
            headers: [lIncome, lExpenses, lSavings, lAvailable],
            data: [
              [
                _fmt(incomeTotal, currency),
                _fmt(expenseTotal, currency),
                _fmt(savedTotal, currency),
                _fmt(available, currency),
              ],
            ],
            headerStyle: pw.TextStyle(font: bold, fontSize: 10, color: PdfColors.white),
            headerDecoration:
                pw.BoxDecoration(color: PdfColor.fromInt(0xFF6C4DF6)),
            cellStyle: pw.TextStyle(font: bold, fontSize: 11),
            cellPadding: const pw.EdgeInsets.all(6),
            border: pw.TableBorder.all(color: PdfColors.grey300),
          ),
          pw.SizedBox(height: 22),
          _section(lTopCategories, bold),
          ...topCats.take(5).map((e) {
            final cat = categories[e.key];
            final pct = expenseTotal == 0 ? 0 : e.value / expenseTotal * 100;
            return pw.Padding(
              padding: const pw.EdgeInsets.symmetric(vertical: 2),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('${cat?.name ?? 'other'}  (${pct.toStringAsFixed(1)}%)'),
                  pw.Text(_fmt(e.value, currency)),
                ],
              ),
            );
          }).toList(),
          pw.SizedBox(height: 22),
          _section(lBudgetStatus, bold),
          ...budgets.map((b) {
            final spent = byCat[b.categoryId] ?? 0;
            final st = FinanceCalculator.budgetStatus(spent, b.amount, b.warnAt);
            final label = switch (st) {
              BudgetStatus.exceeded => lOverBudget,
              BudgetStatus.approaching => lApproaching,
              BudgetStatus.normal => lOnTrack,
            };
            return pw.Padding(
              padding: const pw.EdgeInsets.symmetric(vertical: 2),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('${categories[b.categoryId]?.name ?? 'other'} - $label',
                      style: pw.TextStyle(font: bold, fontSize: 10)),
                  pw.Text(
                      '${_fmt(spent, currency)} / ${_fmt(b.amount, currency)} (${FinanceCalculator.budgetProgress(spent, b.amount).toStringAsFixed(0)}%)'),
                ],
              ),
            );
          }).toList(),
          pw.SizedBox(height: 22),
          _section(lSavingsProgress, bold),
          ...goals.map((g) {
            final saved = savingsTxs
                .where((t) => t.goalId == g.id)
                .fold<double>(0, (s, t) => s + t.amount);
            return pw.Padding(
              padding: const pw.EdgeInsets.symmetric(vertical: 2),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text(g.name),
                  pw.Text(
                      '${_fmt(saved, currency)} / ${_fmt(g.target, currency)} (${FinanceCalculator.goalProgress(saved, g.target).toStringAsFixed(0)}%)'),
                ],
              ),
            );
          }).toList(),
          pw.SizedBox(height: 28),
          pw.Text(lGeneratedBy,
              style: pw.TextStyle(fontSize: 8, color: PdfColors.grey500)),
        ],
      ),
    );
    return doc.save();
  }

  pw.Widget _section(String title, pw.Font bold) => pw.Padding(
        padding: const pw.EdgeInsets.only(bottom: 6),
        child: pw.Text(title,
            style: pw.TextStyle(font: bold, fontSize: 14, color: PdfColor.fromInt(0xFF6C4DF6))),
      );

  String _fmt(double v, String currency) {
    final s = v.toStringAsFixed(2);
    final symbol = switch (currency) {
      'EUR' => '\u20AC',
      'USD' => r'$',
      'CAD' => r'C$',
      'GBP' => '\u00A3',
      _ => 'MAD',
    };
    return '$symbol$s';
  }

  String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// Shares bytes via the system share sheet (no network involved).
  Future<void> shareBytes(Uint8List bytes, String filename, String text) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$filename');
    await file.writeAsBytes(bytes);
    await Share.shareXFiles([XFile(file.path)], text: text);
  }

  Future<void> shareTextFile(String content, String filename, String text) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$filename');
    await file.writeAsString(content);
    await Share.shareXFiles([XFile(file.path)], text: text);
  }
}
