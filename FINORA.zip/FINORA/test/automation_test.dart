import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:finora/database/app_database.dart';
import 'package:finora/models/category.dart';
import 'package:finora/models/plan_run.dart';
import 'package:finora/models/recurring_income.dart';
import 'package:finora/models/savings_goal.dart';
import 'package:finora/models/savings_plan.dart';
import 'package:finora/models/savings_transaction.dart';
import 'package:finora/models/expense.dart';
import 'package:finora/repositories/automation_repository.dart';
import 'package:finora/repositories/finance_repository.dart';
import 'package:finora/repositories/planning_repository.dart';

/// Automatic monthly income & savings: generation, idempotency, per-month
/// skip/restore, manual savings independence and the monthly summary.
void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late AppDatabase db;
  late FinanceRepository finance;
  late PlanningRepository planning;
  late AutomationRepository auto;
  late int incomeCat;
  late int expenseCat;
  late int goalId;

  setUp(() async {
    db = AppDatabase.forPath(inMemoryDatabasePath);
    finance = FinanceRepository(db: db);
    planning = PlanningRepository(finance: finance, db: db);
    auto = AutomationRepository(db: db);
    incomeCat = await finance.addCategory(const Category(
        name: 'salary', icon: 'cash', color: 0xFF00BFA5, isIncome: true));
    expenseCat = await finance
        .addCategory(const Category(name: 'food', icon: 'food', color: 0xFFFFB300));
    goalId = await planning.addSavingsGoal(const SavingsGoal(
        name: 'Emergency', target: 10000, color: 0xFF6C4DF6, icon: 'savings'));
  });

  tearDown(() async {
    await db.close();
  });

  Future<void> addPlans({String startMonth = '2026-01', int day = 1}) async {
    await auto.addRecurringIncome(RecurringIncome(
        name: 'Salary',
        amount: 5000,
        categoryId: incomeCat,
        dayOfMonth: day,
        startMonth: startMonth));
    await auto.saveSavingsPlan(SavingsPlan(
        goalId: goalId, amount: 800, dayOfMonth: day, startMonth: startMonth));
  }

  test('applyDue generates one income + one savings per due month, once',
      () async {
    await addPlans();
    final now = DateTime(2026, 3, 15);
    final created = await auto.applyDue(now: now);
    expect(created, 6); // Jan, Feb, Mar x (income + savings)

    // Running again never duplicates.
    expect(await auto.applyDue(now: now), 0);
    expect((await finance.allIncome()).length, 3);
    expect(await planning.savedForGoal(goalId), 2400);
  });

  test('a plan is not applied before its day of month', () async {
    await addPlans(startMonth: '2026-03', day: 20);
    expect(await auto.applyDue(now: DateTime(2026, 3, 10)), 0);
    expect(await auto.applyDue(now: DateTime(2026, 3, 20)), 2);
  });

  test('day 31 falls back to the last day of short months', () {
    expect(AutomationRepository.occurrence(DateTime(2026, 2, 1), 31),
        DateTime(2026, 2, 28));
    expect(AutomationRepository.occurrence(DateTime(2026, 4, 1), 31),
        DateTime(2026, 4, 30));
  });

  test('nextStartMonth never back-fills a day that already passed', () {
    expect(AutomationRepository.nextStartMonth(1, now: DateTime(2026, 3, 15)),
        '2026-04');
    expect(AutomationRepository.nextStartMonth(20, now: DateTime(2026, 3, 15)),
        '2026-03');
    expect(AutomationRepository.nextStartMonth(15, now: DateTime(2026, 3, 15)),
        '2026-03');
  });

  test('skipMonth cancels ONE month only and removes its generated entry',
      () async {
    await addPlans();
    final now = DateTime(2026, 3, 15);
    await auto.applyDue(now: now);
    final plan = (await auto.savingsPlans()).single;

    await auto.skipMonth(PlanKind.savings, plan.id!, '2026-03');
    expect(await planning.savedForGoal(goalId), 1600); // Jan + Feb remain
    expect((await finance.allIncome()).length, 3); // income plan untouched

    // Running again does not recreate the skipped month.
    expect(await auto.applyDue(now: now), 0);
    expect(await planning.savedForGoal(goalId), 1600);

    // Next month is generated normally.
    await auto.applyDue(now: DateTime(2026, 4, 2));
    expect(await planning.savedForGoal(goalId), 2400);
  });

  test('skipping a month before it runs prevents generation; restore applies it',
      () async {
    await addPlans(startMonth: '2026-03');
    final plan = (await auto.savingsPlans()).single;
    await auto.skipMonth(PlanKind.savings, plan.id!, '2026-03');
    await auto.applyDue(now: DateTime(2026, 3, 5));
    expect(await planning.savedForGoal(goalId), 0);

    await auto.restoreMonth(PlanKind.savings, plan.id!, '2026-03',
        now: DateTime(2026, 3, 5));
    expect(await planning.savedForGoal(goalId), 800);
    expect((await auto.runsForMonth('2026-03')).where((r) => r.skipped), isEmpty);
  });

  test('manual savings are independent of the automatic plan', () async {
    await addPlans(startMonth: '2026-03');
    await auto.applyDue(now: DateTime(2026, 3, 5));
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: goalId, amount: 250, date: DateTime(2026, 3, 7)));

    final plan = (await auto.savingsPlans()).single;
    await auto.skipMonth(PlanKind.savings, plan.id!, '2026-03');
    // Only the automatic installment was removed; the manual deposit stays.
    expect(await planning.savedForGoal(goalId), 250);
    expect(plan.amount, 800); // plan itself is untouched
  });

  test('deleting a generated income by hand does not recreate it', () async {
    await addPlans(startMonth: '2026-03');
    await auto.applyDue(now: DateTime(2026, 3, 5));
    final income = (await finance.allIncome()).single;
    await finance.deleteIncome(income.id!);
    expect(await auto.applyDue(now: DateTime(2026, 3, 6)), 0);
    expect(await finance.allIncome(), isEmpty);
  });

  test('paused plans generate nothing', () async {
    await addPlans(startMonth: '2026-03');
    final inc = (await auto.recurringIncomes()).single;
    await auto.updateRecurringIncome(inc.copyWith(active: false));
    await auto.applyDue(now: DateTime(2026, 3, 5));
    expect(await finance.allIncome(), isEmpty);
  });

  test('summary: expected income - automatic savings - expenses = remaining',
      () async {
    await addPlans(startMonth: '2026-03');
    await auto.applyDue(now: DateTime(2026, 3, 5));
    await finance.addExpense(Expense(
        amount: 1200, categoryId: expenseCat, date: DateTime(2026, 3, 4)));

    var s = await auto.summaryForMonth(DateTime(2026, 3, 1));
    expect(s.expectedIncome, 5000);
    expect(s.autoSavings, 800);
    expect(s.expenses, 1200);
    expect(s.remaining, 3000); // 5000 - 800 - 1200
    expect(s.adjustment, closeTo(0, 0.001));

    // Manual savings lower the actual remaining and show as an adjustment.
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: goalId, amount: 200, date: DateTime(2026, 3, 8)));
    s = await auto.summaryForMonth(DateTime(2026, 3, 1));
    expect(s.remaining, 2800);
    expect(s.adjustment, closeTo(-200, 0.001));

    // Skipping the automatic savings for that month removes it from the plan.
    final plan = (await auto.savingsPlans()).single;
    await auto.skipMonth(PlanKind.savings, plan.id!, '2026-03');
    s = await auto.summaryForMonth(DateTime(2026, 3, 1));
    expect(s.autoSavings, 0);
    expect(s.remaining, 3600); // 5000 - 200 manual - 1200
  });

  test('deleting a goal removes its automatic plan and ledger', () async {
    await addPlans(startMonth: '2026-03');
    await auto.applyDue(now: DateTime(2026, 3, 5));
    await planning.deleteSavingsGoal(goalId);
    expect(await auto.savingsPlans(), isEmpty);
    final runs = await auto.runsForMonth('2026-03');
    expect(runs.where((r) => r.kind == PlanKind.savings), isEmpty);
  });

  test('a category used by an automatic income cannot be deleted', () async {
    await addPlans();
    await expectLater(finance.deleteCategory(incomeCat),
        throwsA(isA<CategoryInUseException>()));
  });
}
