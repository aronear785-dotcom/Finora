# FINORA

> **Your money. Your plan.**

FINORA is a simple, modern, beautiful, **privacy-first** personal finance application
for Android. Enter income, set a budget, track expenses in seconds, understand where
your money goes, and save toward specific goals — **100 % offline**, no account, no
server, no analytics. Your financial data never leaves your device.

![platform](https://img.shields.io/badge/platform-Android-3ddc84)
![offline](https://img.shields.io/badge/offline-first-yes-00bfa5)
![languages](https://img.shields.io/badge/l10n-6%20languages-6c4df6)
![license](https://img.shields.io/badge/license-MIT-black)

---

## Features

- **Home dashboard** — total income, expenses, savings and available money for the
  selected month, with income-vs-expense chart, donut of expenses by category,
  savings progress and month-over-month comparison (all charts use *real* SQLite data).
- **Income management** — salary, freelance, bonus, business, investment, other;
  add / edit / delete, history, search & filter.
- **Expense tracking** — record an expense in a few seconds with the Quick-Add
  bottom sheet (amount → category → save, current date/time by default); optional
  note and payment method. Expenses are grouped **by day**, with a **calendar view**.
- **16 default categories** (Rent, Food, Car, Transport, Education, Health,
  Electricity, Water, Internet, Phone, Shopping, Clothing, Entertainment,
  Subscriptions, Home, Other) + **custom categories** with icon & color.
  Categories used by history are never deleted (safe handling).
- **Monthly & per-category budgets** — budget / spent / remaining / progress bars,
  “approaching” warning at a configurable threshold (default 80 %), “exceeded”
  state, and copy budgets to next month.
- **Savings goals** — unlimited goals, add / withdraw money, per-goal history,
  progress rings, auto-savings percentage of income, and an accurate
  **savings plan calculator** (remaining, estimated months, completion date).
- **Recurring expenses** — monthly/weekly/daily/yearly occurrences generated
  automatically with **duplicate prevention**.
- **Subscription tracker** — monthly and yearly cost, activate / deactivate.
- **Debts** — “I owe” / “Owed to me”, pending / paid, mark as paid.
- **Analysis** — total income, expenses, savings, available; charts for expenses
  by category, daily expenses, income vs expenses, monthly comparison, savings
  progress, budget usage; periods: current / previous month, 3 / 6 / 12 months,
  custom range.
- **Monthly report** — clean summary with top categories, budget status, savings
  progress and comparison with the previous month; export to **PDF** and **CSV**
  (generated locally, shared via the system share sheet).
- **Search & filter** — by category, note, amount, date; filters (today, week,
  month, previous month, custom dates, category); sorting (newest, oldest,
  highest, lowest amount).
- **Settings** — language (6 languages + system), currency (MAD, EUR, USD, CAD,
  GBP), theme (light / dark / system), daily reminder, export (CSV / PDF / JSON
  backup), restore, delete-all-data with strong confirmation, sample data mode,
  privacy statement and About.
- **Localization** — English, French, Arabic (with full **RTL** layout), Spanish,
  Chinese, Russian. Automatic device-language detection, manual override in
  Settings, English fallback.
- **Material 3** — modern rounded cards, light & dark themes, smooth animations,
  accessible tap targets, scalable text.

---

## Screenshots

| Dashboard | Expenses | Budget | Savings | Analysis |
|-----------|----------|--------|---------|----------|
| `docs/screenshots/home.png` | `docs/screenshots/expenses.png` | `docs/screenshots/budget.png` | `docs/screenshots/savings.png` | `docs/screenshots/analysis.png` |

> Placeholders — add real captures under `docs/screenshots/` before publishing.

---

## Architecture

Clean, layered architecture; the UI never touches SQL directly.

```
lib/
├── core/          constants, utilities (dates, money, app event bus)
├── database/      SQLite schema, migrations, indexes (AppDatabase)
├── models/        plain Dart models (Category, Expense, Income, Budget, …)
├── repositories/  data access: FinanceRepository, PlanningRepository
├── services/      pure logic: FinanceCalculator, ExportService, SettingsService,
│                  ReminderService, DemoDataService
├── providers/     Riverpod providers gluing repositories to the UI
├── screens/       one folder per feature (home, expenses, budget, savings, …)
├── widgets/       shared widgets (cards, empty states, charts, dialogs)
├── theme/         Material 3 light & dark themes
├── l10n/          hand-written AppLocalizations + delegate loading ARB JSON
└── main.dart      bootstrap
```

A global `AppBus` change-notifier invalidates the Riverpod providers after every
database write, so charts and lists always reflect the real, current data.

## Technology stack

| Layer | Choice |
|-------|--------|
| UI | Flutter + Material 3 |
| State | Riverpod (`flutter_riverpod`) |
| Storage | SQLite (`sqflite`), versioned schema, foreign keys, indexes, migrations |
| Charts | `fl_chart` (real data only) |
| Dates / numbers | `intl` |
| PDF reports | `pdf` + `printing` + `share_plus` |
| CSV / backup | `csv`, hand-rolled JSON backup |
| Files / reminders | `path_provider`, `file_picker`, `flutter_local_notifications`, `timezone` |

No Firebase. No backend. No external API. Fully offline.

## Database

Relational schema with primary keys, foreign keys and indexes on hot query columns:

`categories`, `income`, `expenses`, `budgets`, `savings_goals`,
`savings_transactions`, `recurring_expenses`, `subscriptions`, `debts`, `settings`.

Migrations are handled with SQLite `version` + `onUpgrade` hooks in
`lib/database/app_database.dart`.

## Localization

- ARB files: `assets/l10n/app_{en,fr,ar,es,zh,ru}.arb` (312 keys each, full parity).
- A hand-written `AppLocalizations` class (`lib/l10n/`) loads the ARB JSON from
  assets — no code-generation required.
- Device language is detected automatically; unsupported languages fall back to
  English; the user can override the language in Settings.
- Arabic renders in **RTL** (layout + text + navigation) via Flutter's locale
  resolution — the Material widgets handle direction automatically.

### Adding a new language

1. Copy `assets/l10n/app_en.arb` to `app_<code>.arb` and translate every value
   (keep the exact same key set).
2. Register the locale in `lib/l10n/app_localizations.dart`
   (`supportedLocales` + add the map entry).
3. Optionally add it to the language selector in
   `lib/screens/settings/settings_screen.dart`.

## Getting started

### 1. Install Flutter

Follow the official guide: https://docs.flutter.dev/get-started/install

Then verify:

```bash
flutter doctor
```

### 2. Get dependencies

```bash
flutter pub get
```

### 3. Run the app

```bash
flutter run
```

First launch shows a short onboarding (welcome → track → budget → savings →
choose currency), then the dashboard.

### 4. Build the Android APK

```bash
flutter build apk --release
```

The APK is generated at:

```
build/app/outputs/flutter-apk/app-release.apk
```

(You can also produce a split APK per ABI with `flutter build apk --release
--split-per-abi`.)

### 5. Run tests

```bash
flutter test
```

## Uploading to GitHub

1. Create an empty repository at https://github.com/new (e.g. `FINORA`).
2. From the project folder:

```bash
git init
git add .
git commit -m "Initial commit: FINORA - Your money. Your plan."
git branch -M main
git remote add origin https://github.com/<you>/FINORA.git
git push -u origin main
```

The included `.gitignore` keeps build outputs, caches and local files out of the
repository.

## Modifying categories

Default categories are seeded on first launch from
`lib/services/settings_service.dart`. To change defaults, edit the seed list and
bump the schema version (or delete the app data once). Inside the app:
**Expenses → Settings (gear) → Manage categories** lets you add custom categories,
pick an icon and a color, edit them, and delete them (safely — only when nothing
references them).

## Privacy

FINORA is **privacy-first**:

- No account required, no registration.
- No server, no analytics, no tracking.
- All data stays on-device in SQLite.
- Exports/backups are generated locally; you choose where to share them.
- Exported files contain your financial information — keep them safe.

## License

MIT — see `LICENSE` (add the file before publishing if you intend to release).
