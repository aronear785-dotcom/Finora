import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/income.dart';
import '../../providers/providers.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/common_widgets.dart';
import 'income_form_screen.dart';

/// Income history for the selected month with total; add/edit/delete.
class IncomeScreen extends ConsumerStatefulWidget {
  const IncomeScreen({super.key});

  @override
  ConsumerState<IncomeScreen> createState() => _IncomeScreenState();
}

class _IncomeScreenState extends ConsumerState<IncomeScreen> {
  DateTime _month = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final catsAsync = ref.watch(incomeCategoriesProvider);
    final incomeAsync = ref.watch(monthIncomeProvider(_month));

    return Scaffold(
      appBar: AppBar(title: Text(l.incHistory)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => const IncomeFormScreen()));
        },
        icon: const Icon(Icons.add),
        label: Text(l.incAdd),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: MonthHeader(
              month: _month,
              onChange: (m) => setState(() => _month = m),
            ),
          ),
          incomeAsync.when(
            data: (incomes) {
              final total = FinanceCalculator.totalIncome(incomes);
              return Expanded(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                      child: Card(
                        elevation: 0,
                        color: scheme.primaryContainer.withOpacity(0.35),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18)),
                        child: ListTile(
                          leading: Icon(Icons.arrow_downward_rounded,
                              color: scheme.primary),
                          title: Text(l.homeTotalIncome,
                              style: const TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w600)),
                          trailing: Text(fmt.format(total),
                              style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: scheme.primary)),
                        ),
                      ),
                    ),
                    Expanded(
                      child: incomes.isEmpty
                          ? EmptyState(
                              icon: Icons.payments_outlined,
                              title: l.incEmpty,
                            )
                          : ListView.separated(
                              padding:
                                  const EdgeInsets.fromLTRB(16, 4, 16, 96),
                              itemCount: incomes.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 8),
                              itemBuilder: (_, i) {
                                final inc = incomes[i];
                                return _IncomeTile(
                                  income: inc,
                                  categories: catsAsync.valueOrNull ?? const [],
                                  fmt: fmt,
                                  onTap: () async {
                                    final edited = await Navigator.of(context)
                                        .push(MaterialPageRoute(
                                            builder: (_) => IncomeFormScreen(
                                                income: inc)));
                                    if (edited == true) {
                                      setState(() {});
                                    }
                                  },
                                  onDelete: () async {
                                    final ok = await confirmDialog(context,
                                        title: l.commonDelete,
                                        message: l.commonDeleteConfirm,
                                        confirmLabel: l.commonDelete,
                                        destructive: true);
                                    if (ok) {
                                      await ref
                                          .read(financeRepositoryProvider)
                                          .deleteIncome(inc.id!);
                                    }
                                  },
                                );
                              },
                            ),
                    ),
                  ],
                ),
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) =>
                Center(child: Text(context.l10n.commonError)),
          ),
        ],
      ),
    );
  }
}

class _IncomeTile extends StatelessWidget {
  const _IncomeTile({
    required this.income,
    required this.categories,
    required this.fmt,
    required this.onTap,
    required this.onDelete,
  });

  final Income income;
  final List<dynamic> categories;
  final MoneyFormatter fmt;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final cat = categories.cast<dynamic>().firstWhere(
        (c) => c.id == income.categoryId,
        orElse: () => null);
    final color = cat != null
        ? Color(cat.color as int)
        : scheme.primary;
    final icon = cat != null ? (cat.icon as String) : 'payments';
    return Card(
      elevation: 0,
      color: scheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color.withOpacity(0.14),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(iconName(icon), size: 20, color: color),
        ),
        title: Text(
          cat != null ? context.incomeLabel(cat.name as String) : '—',
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          income.note ??
              '${income.date.day} ${context.monthName(income.date.month)}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 12),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('+${fmt.formatCompact(income.amount)}',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: scheme.primary)),
            PopupMenuButton<String>(
              onSelected: (v) => v == 'edit' ? onTap() : onDelete(),
              itemBuilder: (_) => [
                PopupMenuItem(
                    value: 'edit', child: Text(context.l10n.commonEdit)),
                PopupMenuItem(
                    value: 'delete', child: Text(context.l10n.commonDelete)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  IconData iconName(String name) => switch (name) {
        'salary' => Icons.work_outline,
        'freelance' => Icons.laptop_mac_outlined,
        'bonus' => Icons.card_giftcard_outlined,
        'business' => Icons.storefront_outlined,
        'investment' => Icons.trending_up,
        'other' => Icons.more_horiz,
        _ => Icons.payments_outlined,
      };
}
