import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/expense.dart';
import '../../models/income.dart';
import '../../models/savings_transaction.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';
import '../expenses/expense_form_screen.dart';
import '../income/income_form_screen.dart';
import '../savings/savings_form_screen.dart';
import '../savings/savings_tx_screen.dart';

enum _QuickMode { expense, income, savings }

/// The "few seconds" entry sheet: pick Expense / Income / Savings, type the
/// amount (auto-focused numeric keyboard), pick a category or goal, save.
/// Date/time defaults to now. Manual savings added here are independent of
/// any automatic savings plan.
class QuickAddSheet extends ConsumerStatefulWidget {
  const QuickAddSheet({super.key, this.initialMode = 'expense'});

  /// 'expense' | 'income' | 'savings'
  final String initialMode;

  @override
  ConsumerState<QuickAddSheet> createState() => _QuickAddSheetState();
}

class _QuickAddSheetState extends ConsumerState<QuickAddSheet> {
  final _amountCtrl = TextEditingController();
  late _QuickMode _mode = switch (widget.initialMode) {
    'income' => _QuickMode.income,
    'savings' => _QuickMode.savings,
    _ => _QuickMode.expense,
  };
  int? _categoryId;
  int? _incomeCategoryId;
  int? _goalId;
  bool _saving = false;

  @override
  void dispose() {
    _amountCtrl.dispose();
    super.dispose();
  }

  int? get _selectedId => switch (_mode) {
        _QuickMode.expense => _categoryId,
        _QuickMode.income => _incomeCategoryId,
        _QuickMode.savings => _goalId,
      };

  Future<void> _save() async {
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    final selected = _selectedId;
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    if (selected == null) return;
    setState(() => _saving = true);
    try {
      final now = DateTime.now();
      switch (_mode) {
        case _QuickMode.expense:
          await ref.read(financeRepositoryProvider).addExpense(
              Expense(amount: amount, categoryId: selected, date: now));
        case _QuickMode.income:
          await ref.read(financeRepositoryProvider).addIncome(
              Income(amount: amount, categoryId: selected, date: now));
        case _QuickMode.savings:
          await ref.read(planningRepositoryProvider).addSavingsTransaction(
              SavingsTransaction(goalId: selected, amount: amount, date: now));
      }
      if (mounted) {
        Navigator.of(context).pop();
        showSnack(context, context.l10n.commonSuccess);
      }
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  void _openFullForm() {
    final navigator = Navigator.of(context);
    final goalId = _goalId;
    navigator.pop();
    switch (_mode) {
      case _QuickMode.expense:
        navigator.push(
            MaterialPageRoute(builder: (_) => const ExpenseFormScreen()));
      case _QuickMode.income:
        navigator
            .push(MaterialPageRoute(builder: (_) => const IncomeFormScreen()));
      case _QuickMode.savings:
        navigator.push(MaterialPageRoute(
            builder: (_) => goalId == null
                ? const SavingsFormScreen()
                : SavingsTxScreen(goalId: goalId)));
    }
  }

  Widget _grid(List<Widget> tiles) => SizedBox(
        height: 150,
        child: GridView.count(
          crossAxisCount: 4,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: tiles,
        ),
      );

  Widget _selector() {
    const loading = SizedBox(
        height: 150, child: Center(child: CircularProgressIndicator()));
    const failed = SizedBox(height: 150, child: Center(child: Text('')));
    switch (_mode) {
      case _QuickMode.expense:
        return ref.watch(categoriesProvider).when(
              data: (cats) {
                _categoryId ??= cats.isEmpty ? null : cats.first.id;
                return _grid([
                  for (final c in cats)
                    _QuickTile(
                      icon: AppIcons.resolve(c.icon),
                      color: AppColors.fromInt(c.color),
                      label: context.categoryLabel(c.name),
                      selected: _categoryId == c.id,
                      onTap: () => setState(() => _categoryId = c.id),
                    ),
                ]);
              },
              loading: () => loading,
              error: (_, __) => failed,
            );
      case _QuickMode.income:
        return ref.watch(incomeCategoriesProvider).when(
              data: (cats) {
                _incomeCategoryId ??= cats.isEmpty ? null : cats.first.id;
                return _grid([
                  for (final c in cats)
                    _QuickTile(
                      icon: AppIcons.resolve(c.icon),
                      color: AppColors.fromInt(c.color),
                      label: context.incomeLabel(c.name),
                      selected: _incomeCategoryId == c.id,
                      onTap: () => setState(() => _incomeCategoryId = c.id),
                    ),
                ]);
              },
              loading: () => loading,
              error: (_, __) => failed,
            );
      case _QuickMode.savings:
        return ref.watch(goalsProvider).when(
              data: (goals) {
                if (goals.isEmpty) {
                  return SizedBox(
                    height: 150,
                    child: Center(
                      child: TextButton.icon(
                        onPressed: _openFullForm,
                        icon: const Icon(Icons.add),
                        label: Text(context.l10n.savNewGoal),
                      ),
                    ),
                  );
                }
                _goalId ??= goals.first.id;
                return _grid([
                  for (final g in goals)
                    _QuickTile(
                      icon: AppIcons.resolve(g.icon),
                      color: AppColors.fromInt(g.color),
                      label: g.name,
                      selected: _goalId == g.id,
                      onTap: () => setState(() => _goalId = g.id),
                    ),
                ]);
              },
              loading: () => loading,
              error: (_, __) => failed,
            );
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 8,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(l.expQuick,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w800)),
                const Spacer(),
                TextButton(
                  onPressed: _openFullForm,
                  child: Text(l.expAdd),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<_QuickMode>(
                segments: [
                  ButtonSegment(
                      value: _QuickMode.expense,
                      icon: const Icon(Icons.arrow_upward_rounded),
                      label: Text(l.quickExpense)),
                  ButtonSegment(
                      value: _QuickMode.income,
                      icon: const Icon(Icons.arrow_downward_rounded),
                      label: Text(l.quickIncome)),
                  ButtonSegment(
                      value: _QuickMode.savings,
                      icon: const Icon(Icons.savings_outlined),
                      label: Text(l.quickSavings)),
                ],
                selected: {_mode},
                onSelectionChanged: (s) => setState(() => _mode = s.first),
                showSelectedIcon: false,
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _amountCtrl,
              autofocus: true,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
              ],
              textAlign: TextAlign.end,
              style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800),
              decoration: InputDecoration(
                hintText: '0.00',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 14),
            _selector(),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _saving || _selectedId == null ? null : _save,
                style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15)),
                child: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(l.commonSave),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickTile extends StatelessWidget {
  const _QuickTile({
    required this.icon,
    required this.color,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final Color color;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: selected
              ? color.withValues(alpha: 0.16)
              : scheme.surfaceContainerHighest.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(14),
          border: selected ? Border.all(color: color, width: 1.4) : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                size: 22, color: selected ? color : scheme.onSurfaceVariant),
            const SizedBox(height: 5),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                      color: scheme.onSurface)),
            ),
          ],
        ),
      ),
    );
  }
}
