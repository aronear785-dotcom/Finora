import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';
import 'expense_form_screen.dart';

/// Navigates to the day screen.
Future<void> openDay(
  BuildContext context,
  DateTime day, {
  required Map<int, Category> categories,
  required MoneyFormatter fmt,
}) {
  return Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => ExpenseDayScreen(
      day: day,
      categories: categories,
      fmt: fmt,
    ),
  ));
}

/// All transactions of one day with daily total, edit & delete.
class ExpenseDayScreen extends ConsumerWidget {
  const ExpenseDayScreen({
    super.key,
    required this.day,
    required this.categories,
    required this.fmt,
  });

  final DateTime day;
  final Map<int, Category> categories;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final expenses =
        ref.watch(dayExpensesProvider(day)).valueOrNull ?? const [];
    final total = expenses.fold<double>(0, (s, e) => s + e.amount);

    return Scaffold(
      appBar: AppBar(
        title: Text(context.shortDayLabel(day)),
        actions: [
          IconButton(
            tooltip: l.expAdd,
            icon: const Icon(Icons.add_box_outlined),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => ExpenseFormScreen())),
          ),
        ],
      ),
      body: expenses.isEmpty
          ? EmptyState(
              icon: Icons.event_busy_outlined,
              title: l.expNoTransactions,
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              children: [
                Card(
                  elevation: 0,
                  color: scheme.primaryContainer.withValues(alpha: 0.35),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18)),
                  child: ListTile(
                    leading: Icon(Icons.summarize_outlined,
                        color: scheme.primary),
                    title: Text(l.expDayTotal,
                        style: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600)),
                    trailing: Text(fmt.format(total),
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: scheme.error)),
                  ),
                ),
                const SizedBox(height: 12),
                for (final e in expenses)
                  Card(
                    elevation: 0,
                    color: scheme.surface,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    child: ListTile(
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 14),
                      leading: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: catColor(e.categoryId).withValues(alpha: 0.14),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(catIcon(e.categoryId),
                            size: 20, color: catColor(e.categoryId)),
                      ),
                      title: Text(catLabel(e.categoryId),
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w600)),
                      subtitle: Text(
                        e.note ?? '',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('-${fmt.formatCompact(e.amount)}',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: scheme.error)),
                          PopupMenuButton<String>(
                            onSelected: (v) async {
                              if (v == 'edit') {
                                await Navigator.of(context).push(
                                    MaterialPageRoute(
                                        builder: (_) =>
                                            ExpenseFormScreen(expense: e)));
                              } else if (v == 'delete') {
                                final ok = await confirmDialog(context,
                                    title: l.commonDelete,
                                    message: l.commonDeleteConfirm,
                                    confirmLabel: l.commonDelete,
                                    destructive: true);
                                if (ok) {
                                  await ref
                                      .read(financeRepositoryProvider)
                                      .deleteExpense(e.id!);
                                }
                              }
                            },
                            itemBuilder: (_) => [
                              PopupMenuItem(
                                  value: 'edit',
                                  child: Text(l.commonEdit)),
                              PopupMenuItem(
                                  value: 'delete',
                                  child: Text(l.commonDelete)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
    );
  }

  Color catColor(int id) =>
      categories[id] != null
          ? AppColors.fromInt(categories[id]!.color)
          : const Color(0xFF6C4DF6);

  IconData catIcon(int id) => AppIcons.resolve(categories[id]?.icon ?? 'category');

  String catLabel(int id) {
    final c = categories[id];
    if (c == null) return '—';
    final label = context_l10n_t('cat.${c.name}');
    return label;
  }

  String context_l10n_t(String key) {
    return l10n.t(key);
  }
}
