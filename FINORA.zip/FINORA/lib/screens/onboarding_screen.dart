import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../l10n/l10n_ext.dart';
import '../models/app_settings.dart';
import '../providers/providers.dart';

/// Simple onboarding: welcome + 3 feature pages + currency selection.
/// No registration, no account - data stays on device.
class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;
  String _currency = 'MAD';

  static const _currencies = ['MAD', 'EUR', 'USD', 'CAD', 'GBP'];

  Future<void> _finish() async {
    final service = ref.read(settingsServiceProvider);
    final current = ref.read(settingsProvider).valueOrNull ??
        AppSettings.defaults;
    await service.save(current.copyWith(
      currency: _currency,
      onboardingDone: true,
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final pages = [
      _Page(
        icon: Icons.account_balance_wallet_outlined,
        title: l.onboardingWelcome,
        subtitle: l.tagline,
      ),
      _Page(
        icon: Icons.receipt_long_outlined,
        title: l.onboardingT1,
        subtitle: l.onboardingD1,
      ),
      _Page(
        icon: Icons.pie_chart_outline,
        title: l.onboardingT2,
        subtitle: l.onboardingD2,
      ),
      _Page(
        icon: Icons.savings_outlined,
        title: l.onboardingT3,
        subtitle: l.onboardingD3,
      ),
    ];
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: AlignmentDirectional.topEnd,
              child: TextButton(
                onPressed: () {
                  _controller.jumpToPage(pages.length);
                  setState(() => _page = pages.length);
                },
                child: Text(l.onboardingSkip),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: pages.length + 1,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (_, i) {
                  if (i == pages.length) {
                    // Last page: choose currency.
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.currency_exchange,
                              size: 64, color: scheme.primary),
                          const SizedBox(height: 18),
                          Text(l.onboardingChooseCurrency,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: scheme.onSurface)),
                          const SizedBox(height: 20),
                          Wrap(
                            spacing: 10,
                            runSpacing: 10,
                            children: [
                              for (final c in _currencies)
                                ChoiceChip(
                                  label: Text(c),
                                  selected: _currency == c,
                                  onSelected: (_) =>
                                      setState(() => _currency = c),
                                ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }
                  return pages[i];
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 8, 28, 24),
              child: Row(
                children: [
                  for (var i = 0; i <= pages.length; i++)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: i == _page ? 22 : 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: i == _page
                            ? scheme.primary
                            : scheme.outlineVariant,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  const Spacer(),
                  FilledButton(
                    onPressed: () {
                      if (_page < pages.length) {
                        _controller.nextPage(
                            duration: const Duration(milliseconds: 250),
                            curve: Curves.easeOut);
                      } else {
                        _finish();
                      }
                    },
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 26, vertical: 14),
                    ),
                    child: Text(_page < pages.length
                        ? l.commonNext
                        : l.onboardingStart),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Page extends StatelessWidget {
  const _Page({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 36),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 110,
            height: 110,
            decoration: BoxDecoration(
              color: scheme.primaryContainer.withValues(alpha: 0.5),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 52, color: scheme.primary),
          ),
          const SizedBox(height: 30),
          Text(title,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: scheme.onSurface)),
          const SizedBox(height: 12),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: scheme.onSurfaceVariant)),
        ],
      ),
    );
  }
}
