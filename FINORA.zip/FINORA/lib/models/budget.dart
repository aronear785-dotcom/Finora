/// A monthly budget for one category. [month] is a 'yyyy-MM' key.
class Budget {
  const Budget({
    this.id,
    required this.categoryId,
    required this.amount,
    required this.month,
    this.warnAt = 80,
  });

  final int? id;
  final int categoryId;
  final double amount;
  final String month;
  final double warnAt;

  Budget copyWith({double? amount, double? warnAt}) => Budget(
        id: id,
        categoryId: categoryId,
        amount: amount ?? this.amount,
        month: month,
        warnAt: warnAt ?? this.warnAt,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'category_id': categoryId,
        'amount': amount,
        'month': month,
        'warn_at': warnAt,
      };

  factory Budget.fromMap(Map<String, Object?> map) => Budget(
        id: map['id'] as int?,
        categoryId: map['category_id'] as int,
        amount: (map['amount'] as num).toDouble(),
        month: map['month'] as String,
        warnAt: (map['warn_at'] as num?)?.toDouble() ?? 80,
      );
}
