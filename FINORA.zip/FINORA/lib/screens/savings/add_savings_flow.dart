import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../l10n/l10n_ext.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';
import 'savings_form_screen.dart';
import 'savings_tx_screen.dart';

/// "Add savings" in one tap from anywhere. Manual savings are ordinary
/// savings transactions: they never touch the automatic plan.
///  - no goal yet  -> opens the new-goal form
///  - one goal     -> opens the add-money screen for it
///  - several      -> asks which goal first
Future<void> openAddSavings(BuildContext context, WidgetRef ref) async {
  final goals = await ref.read(planningRepositoryProvider).savingsGoals();
  if (!context.mounted) return;
  if (goals.isEmpty) {
    showSnack(context, context.l10n.autoNoGoal);
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const SavingsFormScreen()));
    return;
  }
  int? goalId = goals.length == 1 ? goals.first.id : null;
  if (goalId == null) {
    goalId = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(ctx.l10n.quickGoal,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            for (final g in goals)
              ListTile(
                leading: Icon(AppIcons.resolve(g.icon),
                    color: AppColors.fromInt(g.color)),
                title: Text(g.name),
                onTap: () => Navigator.of(ctx).pop(g.id),
              ),
          ],
        ),
      ),
    );
  }
  if (goalId == null || !context.mounted) return;
  await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SavingsTxScreen(goalId: goalId!)));
}
