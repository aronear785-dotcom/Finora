/// User preferences persisted in the settings table (single row, id = 1).
class AppSettings {
  const AppSettings({
    this.language = 'system',
    this.currency = 'MAD',
    this.theme = 'system',
    this.remindersEnabled = false,
    this.reminderHour = 20,
    this.reminderMinute = 0,
    this.onboardingDone = false,
    this.sampleLoaded = false,
    this.savingsPercent = 20,
  });

  final String language; // 'system' | 'en' | 'fr' | 'ar' | 'es' | 'zh' | 'ru'
  final String currency; // 'MAD' | 'EUR' | 'USD' | 'CAD' | 'GBP'
  final String theme; // 'system' | 'light' | 'dark'
  final bool remindersEnabled;
  final int reminderHour;
  final int reminderMinute;
  final bool onboardingDone;
  final bool sampleLoaded;

  /// Automatic savings rate (%) used by the planning feature. This never
  /// moves real money; it is a budgeting/planning calculation only.
  final double savingsPercent;

  AppSettings copyWith({
    String? language,
    String? currency,
    String? theme,
    bool? remindersEnabled,
    int? reminderHour,
    int? reminderMinute,
    bool? onboardingDone,
    bool? sampleLoaded,
    double? savingsPercent,
  }) =>
      AppSettings(
        language: language ?? this.language,
        currency: currency ?? this.currency,
        theme: theme ?? this.theme,
        remindersEnabled: remindersEnabled ?? this.remindersEnabled,
        reminderHour: reminderHour ?? this.reminderHour,
        reminderMinute: reminderMinute ?? this.reminderMinute,
        onboardingDone: onboardingDone ?? this.onboardingDone,
        sampleLoaded: sampleLoaded ?? this.sampleLoaded,
        savingsPercent: savingsPercent ?? this.savingsPercent,
      );

  Map<String, Object?> toMap() => {
        'id': 1,
        'language': language,
        'currency': currency,
        'theme': theme,
        'reminders_enabled': remindersEnabled ? 1 : 0,
        'reminder_hour': reminderHour,
        'reminder_minute': reminderMinute,
        'onboarding_done': onboardingDone ? 1 : 0,
        'sample_loaded': sampleLoaded ? 1 : 0,
        'savings_percent': savingsPercent,
      };

  factory AppSettings.fromMap(Map<String, Object?> map) => AppSettings(
        language: (map['language'] as String?) ?? 'system',
        currency: (map['currency'] as String?) ?? 'MAD',
        theme: (map['theme'] as String?) ?? 'system',
        remindersEnabled: (map['reminders_enabled'] as int? ?? 0) == 1,
        reminderHour: (map['reminder_hour'] as int?) ?? 20,
        reminderMinute: (map['reminder_minute'] as int?) ?? 0,
        onboardingDone: (map['onboarding_done'] as int? ?? 0) == 1,
        sampleLoaded: (map['sample_loaded'] as int? ?? 0) == 1,
        savingsPercent: (map['savings_percent'] as num?)?.toDouble() ?? 20,
      );

  static const defaults = AppSettings();
}
