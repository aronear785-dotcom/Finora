/// An expense record.
class Expense {
  const Expense({
    this.id,
    required this.amount,
    required this.categoryId,
    required this.date,
    this.note,
    this.paymentMethod,
    this.recurringSourceId,
  });

  final int? id;
  final double amount;
  final int categoryId;
  final DateTime date;
  final String? note;
  final String? paymentMethod;
  final int? recurringSourceId;

  Expense copyWith({
    double? amount,
    int? categoryId,
    DateTime? date,
    String? note,
    String? paymentMethod,
  }) =>
      Expense(
        id: id,
        amount: amount ?? this.amount,
        categoryId: categoryId ?? this.categoryId,
        date: date ?? this.date,
        note: note ?? this.note,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        recurringSourceId: recurringSourceId,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'amount': amount,
        'category_id': categoryId,
        'date': date.millisecondsSinceEpoch,
        'note': note,
        'payment_method': paymentMethod,
        'recurring_source_id': recurringSourceId,
      };

  factory Expense.fromMap(Map<String, Object?> map) => Expense(
        id: map['id'] as int?,
        amount: (map['amount'] as num).toDouble(),
        categoryId: map['category_id'] as int,
        date: DateTime.fromMillisecondsSinceEpoch(map['date'] as int),
        note: map['note'] as String?,
        paymentMethod: map['payment_method'] as String?,
        recurringSourceId: map['recurring_source_id'] as int?,
      );
}
