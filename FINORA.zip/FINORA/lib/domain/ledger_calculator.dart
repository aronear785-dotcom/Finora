import '../models/budget.dart';
import '../models/category.dart';
import '../models/expense.dart';
import '../models/income.dart';
import '../models/savings_transaction.dart';
import 'money.dart';

/// Income groups shown in the income breakdown.
enum IncomeGroup { salary, freelance, extra, loan }

class IncomeGroupTotal {
  const IncomeGroupTotal({required this.group, required this.amount});

  final IncomeGroup group;
  final double amount;
}

/// One variable budget with its real spending (fixed expenses excluded).
class BudgetLine {
  const BudgetLine({
    required this.category,
    required this.budget,
    required this.spent,
  });

  final Category category;
  final Budget budget;
  final double spent;

  double get limit => budget.amount;
  double get remaining => Money.subtract(limit, spent);
  bool get isOver => remaining < 0;

  /// 0..1 for the progress bar (clamped; over-budget is shown as a full bar
  /// plus a warning state, never an overflowing percentage).
  double get progress => limit <= 0 ? (spent > 0 ? 1 : 0) : (spent / limit).clamp(0.0, 1.0).toDouble();

  /// Real percentage (may exceed 100) for labels.
  double get percent => limit <= 0 ? 0 : spent / limit * 100;
}

/// Everything the dashboard shows for one period, derived from the
/// transactions in a single pass. Nothing here is stored: it is recomputed
/// from the source records, so editing, deleting or re-categorising a
/// transaction can never leave a stale balance behind.
///
/// Formulas (all in integer cents, see [Money]):
///  * receivedIncome  = sum of income records dated in the period
///                      (expected income is NOT included)
///  * loanIncome      = received income in the "loan" income category
///  * earnedIncome    = receivedIncome - loanIncome
///  * totalExpenses   = sum of expense records in the period
///  * fixedExpenses   = expenses whose category is fixed
///  * variableExpenses= totalExpenses - fixedExpenses
///  * actualSavings   = signed sum of savings transfers in the period
///                      (a transfer is NOT an expense: counted once only)
///  * available       = receivedIncome - totalExpenses - actualSavings
///                      (a monthly amount, not an account balance)
///  * budget remaining= limit - spending of the (variable) category
///  * plannedSavings / expectedIncome come from the automatic plans and are
///    informational only: they never change [available].
class MonthLedger {
  const MonthLedger({
    required this.receivedIncome,
    required this.loanIncome,
    required this.totalExpenses,
    required this.fixedExpenses,
    required this.actualSavings,
    required this.expectedIncome,
    required this.plannedSavings,
    required this.incomeGroups,
    required this.budgetLines,
  });

  final double receivedIncome;
  final double loanIncome;
  final double totalExpenses;
  final double fixedExpenses;
  final double actualSavings;
  final double expectedIncome;
  final double plannedSavings;
  final List<IncomeGroupTotal> incomeGroups;
  final List<BudgetLine> budgetLines;

  double get earnedIncome => Money.subtract(receivedIncome, loanIncome);
  double get variableExpenses => Money.subtract(totalExpenses, fixedExpenses);
  double get available => Money.fromCents(Money.toCents(receivedIncome) -
      Money.toCents(totalExpenses) -
      Money.toCents(actualSavings));

  /// Actual available minus the planned arithmetic
  /// (expected income - planned savings - expenses): manual entries and
  /// automatic items that are not due yet.
  double get planAdjustment => Money.fromCents(Money.toCents(available) -
      (Money.toCents(expectedIncome) -
          Money.toCents(plannedSavings) -
          Money.toCents(totalExpenses)));

  double get variableBudgetTotal =>
      Money.sum(budgetLines.map((b) => b.limit));
  double get variableBudgetSpent => Money.sum(budgetLines.map((b) => b.spent));
}

class LedgerCalculator {
  LedgerCalculator._();

  /// Name of the built-in loan categories (income side = money received,
  /// expense side = monthly installment, a fixed obligation).
  static const loanCategoryName = 'loan';

  static IncomeGroup incomeGroupOf(Category? category) {
    if (category == null) return IncomeGroup.extra;
    if (!category.isCustom) {
      switch (category.name) {
        case 'salary':
          return IncomeGroup.salary;
        case 'freelance':
          return IncomeGroup.freelance;
        case loanCategoryName:
          return IncomeGroup.loan;
      }
    }
    return IncomeGroup.extra;
  }

  static MonthLedger build({
    required List<Income> incomes,
    required List<Expense> expenses,
    required List<SavingsTransaction> savings,
    required List<Category> categories,
    required List<Budget> budgets,
    double expectedIncome = 0,
    double plannedSavings = 0,
  }) {
    final byId = <int, Category>{
      for (final c in categories)
        if (c.id != null) c.id!: c
    };

    // Income by group (cents).
    final groupCents = <IncomeGroup, int>{};
    var receivedCents = 0;
    for (final i in incomes) {
      final cents = Money.toCents(i.amount);
      receivedCents += cents;
      final g = incomeGroupOf(byId[i.categoryId]);
      groupCents[g] = (groupCents[g] ?? 0) + cents;
    }

    // Expenses: fixed vs variable by category; spending per category.
    var totalCents = 0;
    var fixedCents = 0;
    final spentByCategory = <int, int>{};
    for (final e in expenses) {
      final cents = Money.toCents(e.amount);
      totalCents += cents;
      final cat = byId[e.categoryId];
      if (cat != null && cat.isFixed) {
        fixedCents += cents;
      } else {
        spentByCategory[e.categoryId] =
            (spentByCategory[e.categoryId] ?? 0) + cents;
      }
    }

    var savingsCents = 0;
    for (final s in savings) {
      savingsCents += Money.toCents(s.amount);
    }

    // Budgets apply to variable categories only; fixed ones are ignored.
    final lines = <BudgetLine>[];
    for (final b in budgets) {
      final cat = byId[b.categoryId];
      if (cat == null || cat.isFixed || cat.isIncome) continue;
      lines.add(BudgetLine(
        category: cat,
        budget: b,
        spent: Money.fromCents(spentByCategory[b.categoryId] ?? 0),
      ));
    }

    return MonthLedger(
      receivedIncome: Money.fromCents(receivedCents),
      loanIncome: Money.fromCents(groupCents[IncomeGroup.loan] ?? 0),
      totalExpenses: Money.fromCents(totalCents),
      fixedExpenses: Money.fromCents(fixedCents),
      actualSavings: Money.fromCents(savingsCents),
      expectedIncome: expectedIncome,
      plannedSavings: plannedSavings,
      incomeGroups: [
        for (final g in IncomeGroup.values)
          if ((groupCents[g] ?? 0) != 0)
            IncomeGroupTotal(
                group: g, amount: Money.fromCents(groupCents[g] ?? 0)),
      ],
      budgetLines: lines,
    );
  }

  /// Variable spending (fixed categories excluded) between two instants,
  /// e.g. for daily / weekly variable totals.
  static double variableSpendingBetween(
    List<Expense> expenses,
    List<Category> categories,
    DateTime start,
    DateTime end,
  ) {
    final fixedIds = {
      for (final c in categories)
        if (c.isFixed && c.id != null) c.id!
    };
    var cents = 0;
    for (final e in expenses) {
      if (e.date.isBefore(start) || e.date.isAfter(end)) continue;
      if (fixedIds.contains(e.categoryId)) continue;
      cents += Money.toCents(e.amount);
    }
    return Money.fromCents(cents);
  }

  /// Defined rule for insufficient funds: the expense is ALLOWED (real life
  /// happens) but the user must confirm it explicitly when it exceeds the
  /// month's available amount.
  static bool needsOverdrawConfirmation(double available, double amount) =>
      Money.exceeds(amount, available);
}
