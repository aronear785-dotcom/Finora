import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/expense.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';
import '../expenses/expense_form_screen.dart';

/// The "few seconds" expense entry: amount (auto-focused numeric keyboard)
/// -> category -> save. Date/time defaults to now.
class QuickAddSheet extends ConsumerStatefulWidget {
  const QuickAddSheet({super.key});

  @override
  ConsumerState<QuickAddSheet> createState() => _QuickAddSheetState();
}

class _QuickAddSheetState extends ConsumerState<QuickAddSheet> {
  final _amountCtrl = TextEditingController();
  int? _categoryId;
  bool _saving = false;

  @override
  void dispose() {
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _save(int categoryId) async {
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    try {
      await ref.read(financeRepositoryProvider).addExpense(Expense(
            amount: amount,
            categoryId: categoryId,
            date: DateTime.now(),
          ));
      if (mounted) {
        Navigator.of(context).pop();
        showSnack(context, context.l10n.commonSuccess);
      }
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final catsAsync = ref.watch(categoriesProvider);

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 8,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(l.expQuick,
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
              const Spacer(),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const ExpenseFormScreen()));
                },
                child: Text(l.expAdd),
              ),
            ],
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _amountCtrl,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
            ],
            textAlign: TextAlign.end,
            style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800),
            decoration: InputDecoration(
              hintText: '0.00',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 14),
          catsAsync.when(
            data: (cats) {
              if (_categoryId == null && cats.isNotEmpty) {
                _categoryId = cats.first.id;
              }
              return SizedBox(
                height: 150,
                child: GridView.count(
                  crossAxisCount: 4,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: [
                    for (final c in cats)
                      _QuickCategoryTile(
                        category: c,
                        selected: _categoryId == c.id,
                        onTap: () => setState(() => _categoryId = c.id),
                      ),
                  ],
                ),
              );
            },
            loading: () => const SizedBox(
                height: 150, child: Center(child: CircularProgressIndicator())),
            error: (_, __) =>
                const SizedBox(height: 150, child: Center(child: Text(''))),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed:
                  _saving || _categoryId == null ? null : () => _save(_categoryId!),
              style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15)),
              child: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(l.commonSave),
            ),
          ),
        ],
      ),
    );
  }
}

class _QuickCategoryTile extends StatelessWidget {
  const _QuickCategoryTile({
    required this.category,
    required this.selected,
    required this.onTap,
  });

  final dynamic category;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = AppColors.fromInt(category.color as int);
    final label = context.l10n.t('cat.${category.name}');
    final name = label == 'cat.${category.name}' ? category.name as String : label;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: selected
              ? color.withOpacity(0.16)
              : scheme.surfaceVariant.withOpacity(0.5),
          borderRadius: BorderRadius.circular(14),
          border: selected ? Border.all(color: color, width: 1.4) : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(AppIcons.resolve(category.icon as String),
                size: 22, color: selected ? color : scheme.onSurfaceVariant),
            const SizedBox(height: 5),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Text(name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight:
                          selected ? FontWeight.w700 : FontWeight.w500,
                      color: scheme.onSurface)),
            ),
          ],
        ),
      ),
    );
  }
}
