import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../l10n/l10n_ext.dart';
import '../providers/providers.dart';

/// Clean monthly summary:
///   Expected automatic income
/// - Automatic savings
/// - Expenses
/// = Actual remaining balance
///
/// "Actual remaining" uses what is really recorded (automatic AND manual
/// income / savings), so a manual entry or an automatic item that is not due
/// yet shows up as one small adjustment line instead of silently changing
/// the arithmetic.
class PlanSummaryCard extends ConsumerWidget {
  const PlanSummaryCard({super.key, required this.month, this.onManage});

  final DateTime month;
  final VoidCallback? onManage;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final ledgerAsync = ref.watch(
        monthLedgerProvider(DateTime(month.year, month.month, 1)));
    const teal = Color(0xFF00BFA5);

    Widget line(String label, String value, Color color) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            children: [
              Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 13.5, color: scheme.onSurfaceVariant)),
              ),
              Text(value,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: color)),
            ],
          ),
        );

    return Card(
      elevation: 0,
      color: scheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.autorenew_rounded, size: 18, color: scheme.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(l.autoTitle,
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w800)),
                ),
                if (onManage != null)
                  TextButton(onPressed: onManage, child: Text(l.autoManage)),
              ],
            ),
            ledgerAsync.when(
              loading: () => const SizedBox(
                  height: 120, child: Center(child: CircularProgressIndicator())),
              error: (_, __) => const SizedBox(height: 60),
              data: (s) {
                final adjust = s.planAdjustment;
                final remainingColor =
                    s.available < 0 ? scheme.error : scheme.primary;
                return Column(
                  children: [
                    line(l.autoExpectedIncome, '+${fmt.format(s.expectedIncome)}',
                        scheme.primary),
                    line(l.autoAutoSavings, '-${fmt.format(s.plannedSavings)}',
                        teal),
                    line(l.autoExpenses, '-${fmt.format(s.totalExpenses)}',
                        scheme.error),
                    if (adjust.abs() >= 0.005)
                      line(
                          l.autoAdjust,
                          '${adjust > 0 ? '+' : '-'}${fmt.format(adjust.abs())}',
                          scheme.onSurfaceVariant),
                    const Divider(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: Text(l.autoRemaining,
                              style: const TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.w800)),
                        ),
                        Text(fmt.format(s.available),
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                color: remainingColor)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(l.autoBasedOn,
                          style: TextStyle(
                              fontSize: 11, color: scheme.onSurfaceVariant)),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
