import 'package:intl/intl.dart';

/// Formats monetary values for the whole app.
///
/// No live currency conversion is performed: only the display symbol
/// changes based on the selected currency code.
class MoneyFormatter {
  const MoneyFormatter(this.currencyCode);

  final String currencyCode;

  static const Map<String, String> _symbols = {
    'MAD': 'MAD',
    'EUR': '€',
    'USD': r'$',
    'CAD': r'C$',
    'GBP': '£',
  };

  static const Set<String> _prefixSymbols = {'€', r'$', r'C$', '£'};

  String get _symbol => _symbols[currencyCode] ?? currencyCode;

  /// "1,234.56 MAD" or "€1,234.56" depending on the currency.
  String format(num value) {
    final number = NumberFormat('#,##0.00', 'en_US').format(value);
    final symbol = _symbol;
    if (_prefixSymbols.contains(symbol)) {
      return '$symbol$number';
    }
    return '$number $symbol';
  }

  /// "1,234" without decimals (for compact chart labels).
  String formatCompact(num value) {
    final number = NumberFormat('#,##0', 'en_US').format(value);
    final symbol = _symbol;
    if (_prefixSymbols.contains(symbol)) {
      return '$symbol$number';
    }
    return '$number $symbol';
  }

  /// "1.2k" for axis labels.
  String abbreviate(num value) {
    final abs = value.abs();
    String core;
    if (abs >= 1000000) {
      core = '${(value / 1000000).toStringAsFixed(1)}M';
    } else if (abs >= 1000) {
      core = '${(value / 1000).toStringAsFixed(1)}k';
    } else {
      core = value.round().toString();
    }
    return core;
  }
}
