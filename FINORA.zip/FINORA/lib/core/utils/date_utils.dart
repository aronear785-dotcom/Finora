/// Small, pure date helpers shared across the app.
class DateUtilsX {
  DateUtilsX._();

  static const String _format = 'yyyy-MM';

  static DateTime monthStart(DateTime d) => DateTime(d.year, d.month, 1);

  static DateTime monthEnd(DateTime d) =>
      DateTime(d.year, d.month + 1, 0, 23, 59, 59);

  static DateTime nextMonthStart(DateTime d) =>
      DateTime(d.year, d.month + 1, 1);

  static DateTime previousMonthStart(DateTime d) =>
      DateTime(d.year, d.month - 1, 1);

  static bool sameMonth(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month;

  static String monthKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}';

  static String dayKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  static DateTime addMonths(DateTime d, int months) =>
      DateTime(d.year, d.month + months, 1);

  static DateTime endOfDay(DateTime d) => DateTime(d.year, d.month, d.day, 23, 59, 59);

  static DateTime startOfDay(DateTime d) => DateTime(d.year, d.month, d.day);

  static DateTime startOfWeek(DateTime d) {
    final day = DateTime(d.year, d.month, d.day);
    return day.subtract(Duration(days: day.weekday - 1));
  }

  static DateTime endOfWeek(DateTime d) =>
      startOfWeek(d).add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));

  /// Monday-first weekday list for calendar grids: 1 = Monday ... 7 = Sunday.
  static List<DateTime> weekGridFor(DateTime month) {
    final first = DateTime(month.year, month.month, 1);
    final offset = first.weekday - 1; // weekday 1=Mon
    final gridStart = first.subtract(Duration(days: offset));
    return List.generate(42, (i) => gridStart.add(Duration(days: i)));
  }
}
