import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../models/recurring_expense.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Recurring expenses: list, add/edit form, activate/deactivate and manual
/// "generate now" (the repository prevents duplicates).
class RecurringScreen extends ConsumerWidget {
  const RecurringScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final catsAsync = ref.watch(categoriesProvider);
    final items = ref.watch(recurringProvider).valueOrNull ?? const [];

    return Scaffold(
      appBar: AppBar(
        title: Text(l.recTitle),
        actions: [
          IconButton(
            tooltip: l.recGenerated,
            icon: const Icon(Icons.play_arrow_outlined),
            onPressed: () async {
              final n = await ref
                  .read(planningRepositoryProvider)
                  .generateDueTransactions();
              if (context.mounted) {
                showSnack(context, '${l.recGenerated} ($n)');
              }
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => const RecurringFormScreen()));
        },
        icon: const Icon(Icons.add),
        label: Text(l.recAdd),
      ),
      body: catsAsync.when(
        data: (cats) {
          if (items.isEmpty) {
            return EmptyState(
              icon: Icons.autorenew,
              title: l.recEmpty,
              action: FilledButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const RecurringFormScreen())),
                icon: const Icon(Icons.add),
                label: Text(l.recAdd),
              ),
            );
          }
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            children: [
              for (final r in items)
                _RecurringTile(
                  item: r,
                  color: _catColor(cats, r.categoryId),
                  icon: _catIcon(cats, r.categoryId),
                  name: _catName(context, cats, r.categoryId),
                  fmt: fmt,
                ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }

  Color _catColor(List<Category> cats, int id) {
    for (final c in cats) {
      if (c.id == id) return AppColors.fromInt(c.color);
    }
    return const Color(0xFF6C4DF6);
  }

  IconData _catIcon(List<Category> cats, int id) {
    for (final c in cats) {
      if (c.id == id) return AppIcons.resolve(c.icon);
    }
    return Icons.autorenew;
  }

  String _catName(BuildContext context, List<Category> cats, int id) {
    for (final c in cats) {
      if (c.id == id) return context.categoryLabel(c.name);
    }
    return '?';
  }
}

class _RecurringTile extends ConsumerWidget {
  const _RecurringTile({
    required this.item,
    required this.color,
    required this.icon,
    required this.name,
    required this.fmt,
  });

  final RecurringExpense item;
  final Color color;
  final IconData icon;
  final String name;
  final MoneyFormatter fmt;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    return Card(
      elevation: 0,
      color: scheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
        leading: Opacity(
          opacity: item.active ? 1 : 0.45,
          child: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 20, color: color),
          ),
        ),
        title: Text(item.name,
            style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                decoration: item.active ? null : TextDecoration.lineThrough)),
        subtitle: Text(
          '$name · ${context.frequencyLabel(item.frequency)}\n'
          '${l.recNextOcc}: ${item.nextDate.day} ${context.monthName(item.nextDate.month)} ${item.nextDate.year}',
          style: const TextStyle(fontSize: 12),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(fmt.formatCompact(item.amount),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: scheme.error)),
            PopupMenuButton<String>(
              onSelected: (v) async {
                switch (v) {
                  case 'edit':
                    await Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => RecurringFormScreen(item: item)));
                  case 'toggle':
                    await ref
                        .read(planningRepositoryProvider)
                        .updateRecurringExpense(
                            item.copyWith(active: !item.active));
                  case 'delete':
                    final ok = await confirmDialog(context,
                        title: l.commonDelete,
                        message: l.commonDeleteConfirm,
                        confirmLabel: l.commonDelete,
                        destructive: true);
                    if (ok) {
                      await ref
                          .read(planningRepositoryProvider)
                          .deleteRecurringExpense(item.id!);
                    }
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'edit', child: Text(l.commonEdit)),
                PopupMenuItem(
                    value: 'toggle',
                    child: Text(item.active
                        ? l.recInactive
                        : l.recActive)),
                PopupMenuItem(value: 'delete', child: Text(l.commonDelete)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Add / edit a recurring expense template.
class RecurringFormScreen extends ConsumerStatefulWidget {
  const RecurringFormScreen({super.key, this.item});

  final RecurringExpense? item;

  @override
  ConsumerState<RecurringFormScreen> createState() =>
      _RecurringFormScreenState();
}

class _RecurringFormScreenState extends ConsumerState<RecurringFormScreen> {
  final _nameCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  int? _categoryId;
  String _frequency = Frequencies.monthly;
  DateTime _nextDate = DateTime.now().add(const Duration(days: 1));
  bool _active = true;
  bool _saving = false;

  bool get _isEdit => widget.item != null;

  @override
  void initState() {
    super.initState();
    final r = widget.item;
    if (r != null) {
      _nameCtrl.text = r.name;
      _amountCtrl.text = r.amount.toStringAsFixed(2);
      _categoryId = r.categoryId;
      _frequency = r.frequency;
      _nextDate = r.nextDate;
      _active = r.active;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _save(int categoryId) async {
    final name = _nameCtrl.text.trim();
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (name.isEmpty) {
      showSnack(context, context.l10n.errEmptyField);
      return;
    }
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final item = RecurringExpense(
      id: widget.item?.id,
      name: name,
      amount: amount,
      categoryId: categoryId,
      frequency: _frequency,
      nextDate: _nextDate,
      active: _active,
    );
    final repo = ref.read(planningRepositoryProvider);
    try {
      if (_isEdit) {
        await repo.updateRecurringExpense(item);
      } else {
        await repo.addRecurringExpense(item);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final catsAsync = ref.watch(categoriesProvider);
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.recEdit : l.recAdd)),
      body: catsAsync.when(
        data: (cats) {
          if (_categoryId == null && cats.isNotEmpty) {
            _categoryId = cats.first.id;
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(
                controller: _nameCtrl,
                decoration: InputDecoration(
                  labelText: l.recName,
                  prefixIcon: const Icon(Icons.repeat_outlined),
                ),
              ),
              const SizedBox(height: 14),
              AmountField(controller: _amountCtrl, hint: '0.00'),
              const SizedBox(height: 16),
              Text(l.commonCategory,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in cats)
                    CategoryChip(
                      category: c,
                      selected: _categoryId == c.id,
                      onTap: () => setState(() => _categoryId = c.id),
                    ),
                ],
              ),
              const SizedBox(height: 18),
              DropdownButtonFormField<String>(
                value: _frequency,
                decoration: InputDecoration(labelText: l.recFreq),
                items: [
                  for (final f in Frequencies.all)
                    DropdownMenuItem(
                        value: f, child: Text(context.frequencyLabel(f))),
                ],
                onChanged: (v) => v != null
                    ? setState(() => _frequency = v)
                    : null,
              ),
              const SizedBox(height: 14),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event_outlined),
                title: Text(l.recNextDate,
                    style: const TextStyle(fontSize: 14)),
                trailing: Text(
                  '${_nextDate.day} ${context.monthName(_nextDate.month)} ${_nextDate.year}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _nextDate,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) setState(() => _nextDate = picked);
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(l.recActive,
                    style: const TextStyle(fontSize: 14)),
                value: _active,
                onChanged: (v) => setState(() => _active = v),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed:
                    _saving || _categoryId == null ? null : () => _save(_categoryId!),
                style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15)),
                child: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(l.commonSave),
              ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }
}
