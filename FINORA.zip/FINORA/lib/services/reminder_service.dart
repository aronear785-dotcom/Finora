import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Local daily reminders. Notifications never leave the device. On platforms
/// where the plugin is unavailable this safely no-ops.
class ReminderService {
  ReminderService._();

  static final ReminderService instance = ReminderService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _available = true;
  Timer? _rescheduleTimer;

  Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      try {
        final tzName = await FlutterTimezone.getLocalTimezone();
        tz.setLocalLocation(tz.getLocation(tzName));
      } catch (_) {
        // keep default location
      }
      await _plugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
      );
      _available = true;
    } catch (e) {
      debugPrint('ReminderService unavailable: $e');
      _available = false;
    }
  }

  Future<void> scheduleDaily({required int hour, required int minute}) async {
    if (!_available) return;
    await cancelAll();
    final now = tz.TZDateTime.now(tz.local);
    var next =
        tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (!next.isAfter(now)) {
      next = next.add(const Duration(days: 1));
    }
    await _plugin.zonedSchedule(
      0,
      'FINORA',
      'Track your money today. Your money. Your plan.',
      next,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'finora_daily',
          'FINORA daily reminder',
          channelDescription: 'Daily reminder to track your expenses',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
    _rescheduleTimer?.cancel();
    _rescheduleTimer = Timer(
      const Duration(days: 1),
      () => scheduleDaily(hour: hour, minute: minute),
    );
  }

  Future<void> cancelAll() async {
    _rescheduleTimer?.cancel();
    _rescheduleTimer = null;
    if (!_available) return;
    await _plugin.cancelAll();
  }
}
