import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../core/utils/money_formatter.dart';

/// Charts that always render real data provided by the caller. Zero-value
/// slices/bars are filtered out so empty periods show an empty state instead
/// of a broken chart.

class PieSlice {
  const PieSlice({required this.color, required this.value, required this.label});
  final Color color;
  final double value;
  final String label;
}

class ExpenseDonutChart extends StatelessWidget {
  const ExpenseDonutChart({super.key, required this.slices, this.formatter});

  final List<PieSlice> slices;
  final MoneyFormatter? formatter;

  @override
  Widget build(BuildContext context) {
    final clean = slices.where((s) => s.value > 0).toList();
    final total = clean.fold<double>(0, (s, e) => s + e.value);
    if (clean.isEmpty) {
      return const SizedBox(height: 160, child: Center(child: Text('')));
    }
    final scheme = Theme.of(context).colorScheme;
    return Row(
      children: [
        SizedBox(
          width: 150,
          height: 150,
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 34,
              sections: clean
                  .map((s) => PieChartSectionData(
                        value: s.value,
                        color: s.color,
                        radius: 42,
                        title:
                            '${(s.value / total * 100).toStringAsFixed(0)}%',
                        titleStyle: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: Colors.white),
                      ))
                  .toList(),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final s in clean)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                            color: s.color, shape: BoxShape.circle),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          s.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 12, color: scheme.onSurface),
                        ),
                      ),
                      Text(
                        formatter?.formatCompact(s.value) ??
                            s.value.toStringAsFixed(0),
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: scheme.onSurface,
                            locale: null),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class BarDatum {
  const BarDatum({required this.color, required this.value});
  final Color color;
  final double value;
}

class BarGroup {
  const BarGroup({required this.x, required this.label, required this.datum});
  final int x;
  final String label;
  final BarDatum datum;
}

/// Simple bar chart (one bar per group) - used for daily expenses or income
/// vs expenses per period. Labels are placed sparsely when there are many
/// groups so the X axis stays readable.
class FinoraBarChart extends StatelessWidget {
  const FinoraBarChart({
    super.key,
    required this.groups,
    this.formatter,
    this.barWidth = 10,
    this.maxValue,
  });

  final List<BarGroup> groups;
  final MoneyFormatter? formatter;
  final double barWidth;
  final double? maxValue;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final clean = groups.where((g) => g.datum.value > 0).toList();
    if (clean.isEmpty) {
      return const SizedBox(height: 160, child: Center(child: Text('')));
    }
    final max = maxValue ??
        clean.map((g) => g.datum.value).reduce((a, b) => a > b ? a : b);
    final labelEvery = clean.length > 12 ? (clean.length / 8).ceil() : 1;

    return SizedBox(
      height: 180,
      child: BarChart(
        BarChartData(
          maxY: (max * 1.15).clamp(1.0, double.infinity).toDouble(),
          barTouchData: BarTouchData(enabled: false),
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (_) => FlLine(
                color: scheme.outlineVariant.withValues(alpha: 0.35),
                strokeWidth: 1),
          ),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            topTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 46,
                getTitlesWidget: (value, meta) => Text(
                  formatter?.abbreviate(value) ?? value.round().toString(),
                  style: TextStyle(
                      fontSize: 9, color: scheme.onSurfaceVariant),
                ),
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 24,
                getTitlesWidget: (value, meta) {
                  final idx = value.toInt();
                  if (idx < 0 || idx >= clean.length) {
                    return const SizedBox.shrink();
                  }
                  if (idx % labelEvery != 0) {
                    return const SizedBox.shrink();
                  }
                  return Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      clean[idx].label,
                      style: TextStyle(
                          fontSize: 9, color: scheme.onSurfaceVariant),
                    ),
                  );
                },
              ),
            ),
          ),
          barGroups: clean
              .map((g) => BarChartGroupData(
                    x: g.x,
                    barRods: [
                      BarChartRodData(
                        toY: g.datum.value,
                        color: g.datum.color,
                        width: barWidth,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ],
                  ))
              .toList(),
        ),
      ),
    );
  }
}
