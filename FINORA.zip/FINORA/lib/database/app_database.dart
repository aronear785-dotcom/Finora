import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// SQLite access layer. Versioned schema, foreign keys ON, indexes on the
/// hot query columns (date, category). No SQL lives in the UI: everything
/// goes through repositories that use this helper.
class AppDatabase {
  AppDatabase._() : _overridePath = null;

  static final AppDatabase instance = AppDatabase._();

  /// Test-only constructor: uses an explicit file path instead of the app
  /// documents directory (which needs platform plugins unavailable in tests).
  AppDatabase.forPath(String overridePath) : _overridePath = overridePath;

  static const _version = 4;
  Database? _db;
  final String? _overridePath;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    String path;
    if (_overridePath != null) {
      path = _overridePath!;
    } else {
      final dir = await getApplicationDocumentsDirectory();
      path = p.join(dir.path, 'finora.db');
    }
    return openDatabase(
      path,
      version: _version,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, _) => createSchema(db),
      onUpgrade: (db, oldVersion, _) async {
        if (oldVersion < 2) await _createAutomationTables(db);
        if (oldVersion < 3) await _migrateToV3(db);
        if (oldVersion < 4) await _migrateToV4(db);
      },
    );
  }

  /// Creates the full relational schema. Kept public so tests can build the
  /// same schema against an in-memory database.
  Future<void> createSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'category',
        color INTEGER NOT NULL DEFAULT 4284123126,
        is_income INTEGER NOT NULL DEFAULT 0,
        is_custom INTEGER NOT NULL DEFAULT 0,
        expense_type TEXT NOT NULL DEFAULT 'variable',
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE income (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL CHECK (amount > 0),
        category_id INTEGER NOT NULL REFERENCES categories(id),
        date INTEGER NOT NULL,
        note TEXT,
        recurring INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL CHECK (amount > 0),
        category_id INTEGER NOT NULL REFERENCES categories(id),
        date INTEGER NOT NULL,
        note TEXT,
        payment_method TEXT,
        recurring_source_id INTEGER,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE budgets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL REFERENCES categories(id),
        amount REAL NOT NULL CHECK (amount >= 0),
        month TEXT NOT NULL,
        warn_at REAL NOT NULL DEFAULT 80,
        UNIQUE (category_id, month)
      )''');
    await db.execute('''
      CREATE TABLE savings_goals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        target REAL NOT NULL CHECK (target > 0),
        color INTEGER NOT NULL DEFAULT 4284123126,
        icon TEXT NOT NULL DEFAULT 'savings',
        note TEXT,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE savings_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        goal_id INTEGER NOT NULL REFERENCES savings_goals(id) ON DELETE CASCADE,
        amount REAL NOT NULL,
        date INTEGER NOT NULL,
        note TEXT,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE recurring_expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        amount REAL NOT NULL CHECK (amount > 0),
        category_id INTEGER NOT NULL REFERENCES categories(id),
        frequency TEXT NOT NULL DEFAULT 'monthly',
        next_date INTEGER NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        amount REAL NOT NULL CHECK (amount > 0),
        period TEXT NOT NULL DEFAULT 'monthly',
        category_id INTEGER REFERENCES categories(id),
        active INTEGER NOT NULL DEFAULT 1,
        next_billing INTEGER,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE debts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        person TEXT NOT NULL,
        amount REAL NOT NULL CHECK (amount > 0),
        direction TEXT NOT NULL DEFAULT 'owe',
        date INTEGER NOT NULL,
        note TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE settings (
        id INTEGER PRIMARY KEY,
        language TEXT NOT NULL DEFAULT 'system',
        currency TEXT NOT NULL DEFAULT 'MAD',
        theme TEXT NOT NULL DEFAULT 'system',
        reminders_enabled INTEGER NOT NULL DEFAULT 0,
        reminder_hour INTEGER NOT NULL DEFAULT 20,
        reminder_minute INTEGER NOT NULL DEFAULT 0,
        onboarding_done INTEGER NOT NULL DEFAULT 0,
        sample_loaded INTEGER NOT NULL DEFAULT 0,
        savings_percent REAL NOT NULL DEFAULT 20
      )''');

    // Indexes on hot query columns.
    await db.execute('CREATE INDEX idx_income_date ON income(date)');
    await db.execute('CREATE INDEX idx_income_cat ON income(category_id)');
    await db.execute('CREATE INDEX idx_expense_date ON expenses(date)');
    await db.execute('CREATE INDEX idx_expense_cat ON expenses(category_id)');
    await db.execute('CREATE INDEX idx_budget_month ON budgets(month)');
    await db.execute(
        'CREATE INDEX idx_savings_tx_goal ON savings_transactions(goal_id, date)');
    await db.execute(
        'CREATE INDEX idx_recurring_next ON recurring_expenses(next_date)');
    await db.execute('CREATE INDEX idx_debt_direction ON debts(direction)');
    await _createAutomationTables(db);
    await _createLoanTables(db);
  }

  Future<void> _addColumnIfMissing(
      DatabaseExecutor db, String table, String column, String ddl) async {
    final info = await db.rawQuery('PRAGMA table_info($table)');
    if (info.any((r) => r['name'] == column)) return;
    await db.execute('ALTER TABLE $table ADD COLUMN $column $ddl');
  }

  /// Schema v4 (non-destructive): optional end month + manual-receipt mode
  /// for recurring income, and bank-loan tracking.
  Future<void> _migrateToV4(DatabaseExecutor db) async {
    await _addColumnIfMissing(db, 'recurring_incomes', 'end_month', 'TEXT');
    await _addColumnIfMissing(
        db, 'recurring_incomes', 'auto_receive', 'INTEGER NOT NULL DEFAULT 1');
    await _createLoanTables(db);
  }

  Future<void> _createLoanTables(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS loans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        principal REAL NOT NULL CHECK (principal > 0),
        total_interest REAL NOT NULL DEFAULT 0 CHECK (total_interest >= 0),
        installments INTEGER NOT NULL CHECK (installments > 0),
        start_month TEXT NOT NULL,
        day_of_month INTEGER NOT NULL DEFAULT 1 CHECK (day_of_month BETWEEN 1 AND 31),
        active INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS loan_payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL REFERENCES loans(id) ON DELETE CASCADE,
        month TEXT NOT NULL,
        amount REAL NOT NULL,
        expense_id INTEGER,
        created_at INTEGER NOT NULL DEFAULT 0,
        UNIQUE (loan_id, month)
      )''');
  }

  /// Built-in expense categories that are fixed monthly obligations.
  static const fixedCategoryNames = [
    'rent',
    'electricity',
    'water',
    'internet',
    'phone',
    'subscriptions',
    'loan',
  ];

  /// Schema v3 (non-destructive): fixed/variable classification of expense
  /// categories, plus the "bank loan / credit" expense category and the
  /// "loan received" income category (a loan is never earned income).
  Future<void> _migrateToV3(DatabaseExecutor db) async {
    await _addColumnIfMissing(
        db, 'categories', 'expense_type', "TEXT NOT NULL DEFAULT 'variable'");
    final marks = List.filled(fixedCategoryNames.length, '?').join(',');
    await db.rawUpdate(
        "UPDATE categories SET expense_type = 'fixed' "
        'WHERE is_income = 0 AND is_custom = 0 AND name IN ($marks)',
        fixedCategoryNames);
    final hasAny = await db.rawQuery('SELECT COUNT(*) AS c FROM categories');
    if (((hasAny.first['c'] as num?) ?? 0) == 0) return; // seeded later
    for (final isIncome in [0, 1]) {
      final exists = await db.query('categories',
          columns: ['id'],
          where: 'name = ? AND is_income = ?',
          whereArgs: ['loan', isIncome],
          limit: 1);
      if (exists.isEmpty) {
        await db.insert('categories', {
          'name': 'loan',
          'icon': 'bank',
          'color': isIncome == 1 ? 0xFF8E24AA : 0xFFB71C1C,
          'is_income': isIncome,
          'is_custom': 0,
          'expense_type': isIncome == 1 ? 'variable' : 'fixed',
          'created_at': now(),
        });
      }
    }
  }

  /// Schema v2: automatic monthly income & savings.
  /// `plan_runs` is the ledger that makes generation idempotent and records
  /// per-month skips: a (kind, plan, month) row means "already handled".
  Future<void> _createAutomationTables(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS recurring_incomes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        amount REAL NOT NULL CHECK (amount > 0),
        category_id INTEGER NOT NULL REFERENCES categories(id),
        day_of_month INTEGER NOT NULL DEFAULT 1 CHECK (day_of_month BETWEEN 1 AND 31),
        start_month TEXT NOT NULL,
        end_month TEXT,
        auto_receive INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS savings_plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        goal_id INTEGER NOT NULL REFERENCES savings_goals(id) ON DELETE CASCADE,
        amount REAL NOT NULL CHECK (amount > 0),
        day_of_month INTEGER NOT NULL DEFAULT 1 CHECK (day_of_month BETWEEN 1 AND 31),
        start_month TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS plan_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL CHECK (kind IN ('income', 'savings')),
        plan_id INTEGER NOT NULL,
        month TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('done', 'skipped')),
        tx_id INTEGER,
        created_at INTEGER NOT NULL DEFAULT 0,
        UNIQUE (kind, plan_id, month)
      )''');
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_plan_runs_month ON plan_runs(month)');
  }

  /// Deletes every user-data row (settings are kept so language/currency
  /// survive a data wipe; sample flag resets).
  Future<void> wipeUserData() async {
    final db = await database;
    final tables = [
      'loan_payments',
      'loans',
      'plan_runs',
      'savings_plans',
      'recurring_incomes',
      'savings_transactions',
      'savings_goals',
      'income',
      'expenses',
      'budgets',
      'recurring_expenses',
      'subscriptions',
      'debts',
    ];
    await db.transaction((txn) async {
      for (final t in tables) {
        await txn.delete(t);
      }
      await txn.update(
        'settings',
        {'sample_loaded': 0},
        where: 'id = 1',
      );
    });
  }

  static int now() => DateTime.now().millisecondsSinceEpoch;

  /// Closes the database (used by tests; the app keeps the singleton open).
  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
