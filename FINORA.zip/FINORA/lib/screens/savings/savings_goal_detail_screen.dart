import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/savings_transaction.dart';
import '../../providers/providers.dart';
import '../../providers/savings_providers.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/common_widgets.dart';
import 'savings_form_screen.dart';
import 'savings_tx_screen.dart';

/// One goal: summary, progress ring/bar, transaction history with add/
/// withdraw/edit/delete.
class SavingsGoalDetailScreen extends ConsumerStatefulWidget {
  const SavingsGoalDetailScreen({super.key, required this.goalId});

  final int goalId;

  @override
  ConsumerState<SavingsGoalDetailScreen> createState() =>
      _SavingsGoalDetailScreenState();
}

class _SavingsGoalDetailScreenState
    extends ConsumerState<SavingsGoalDetailScreen> {
  Future<void> _pickTransaction({SavingsTransaction? existing}) async {
    await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => SavingsTxScreen(
              goalId: widget.goalId,
              existing: existing,
            )));
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final goals = ref.watch(goalsProvider).valueOrNull ?? const [];
    SavingsGoal? goal;
    for (final g in goals) {
      if (g.id == widget.goalId) goal = g;
    }
    if (goal == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final saved = ref.watch(savedForGoalProvider(widget.goalId)).valueOrNull ?? 0;
    final txs = ref
            .watch(goalTransactionsProvider(widget.goalId))
            .valueOrNull ??
        const <SavingsTransaction>[];
    final progress = FinanceCalculator.goalProgress(saved, goal.target);
    final color = AppColors.fromInt(goal.color);
    final remaining = goal.target - saved;

    return Scaffold(
      appBar: AppBar(
        title: Text(goal.name),
        actions: [
          IconButton(
            tooltip: l.commonEdit,
            icon: const Icon(Icons.edit_outlined),
            onPressed: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => SavingsFormScreen(goal: goal)));
            },
          ),
          IconButton(
            tooltip: l.commonDelete,
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok = await confirmDialog(context,
                  title: l.commonDelete,
                  message: l.commonDeleteConfirm,
                  confirmLabel: l.commonDelete,
                  destructive: true);
              if (ok) {
                await ref
                    .read(planningRepositoryProvider)
                    .deleteSavingsGoal(widget.goalId);
                if (mounted) Navigator.of(context).pop();
              }
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _pickTransaction(),
        icon: const Icon(Icons.add),
        label: Text(l.savAddTx),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          Card(
            elevation: 0,
            color: scheme.surface,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 120,
                        height: 120,
                        child: CircularProgressIndicator(
                          value: (progress / 100).clamp(0.0, 1.0).toDouble(),
                          strokeWidth: 12,
                          backgroundColor:
                              scheme.surfaceVariant.withOpacity(0.5),
                          valueColor: AlwaysStoppedAnimation(color),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('${progress.toStringAsFixed(0)}%',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  color: color)),
                          Text(l.savProgress,
                              style: TextStyle(
                                  fontSize: 11,
                                  color: scheme.onSurfaceVariant)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _Stat(l.savSaved, fmt.format(saved), color),
                      _Stat(l.savTarget, fmt.format(goal.target), scheme.onSurface),
                      _Stat(l.savRemaining, fmt.format(remaining),
                          remaining <= 0 ? color : scheme.error),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SectionTitle(
            title: l.savHistory,
            action: TextButton.icon(
              onPressed: () => _pickTransaction(),
              icon: const Icon(Icons.add, size: 18),
              label: Text(l.savAddTx),
            ),
          ),
          if (txs.isEmpty)
            EmptyState(
              icon: Icons.history_outlined,
              title: l.savEmpty,
            )
          else
            Card(
              elevation: 0,
              color: scheme.surface,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
              child: Column(
                children: [
                  for (final t in txs)
                    ListTile(
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 16),
                      leading: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: (t.amount >= 0 ? color : scheme.error)
                              .withOpacity(0.14),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          t.amount >= 0
                              ? Icons.add_rounded
                              : Icons.remove_rounded,
                          color: t.amount >= 0 ? color : scheme.error,
                        ),
                      ),
                      title: Text(
                        t.note ??
                            '${t.date.day} ${context.monthName(t.date.month)} ${t.date.year}',
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        '${t.date.day} ${context.monthName(t.date.month)}',
                        style: const TextStyle(fontSize: 12),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${t.amount >= 0 ? '+' : '-'}${fmt.formatCompact(t.amount.abs())}',
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: t.amount >= 0 ? color : scheme.error),
                          ),
                          PopupMenuButton<String>(
                            onSelected: (v) async {
                              if (v == 'edit') {
                                await _pickTransaction(existing: t);
                              } else if (v == 'delete') {
                                final ok = await confirmDialog(context,
                                    title: l.commonDelete,
                                    message: l.commonDeleteConfirm,
                                    confirmLabel: l.commonDelete,
                                    destructive: true);
                                if (ok) {
                                  await ref
                                      .read(planningRepositoryProvider)
                                      .deleteSavingsTransaction(t.id!);
                                }
                              }
                            },
                            itemBuilder: (_) => [
                              PopupMenuItem(
                                  value: 'edit',
                                  child: Text(l.commonEdit)),
                              PopupMenuItem(
                                  value: 'delete',
                                  child: Text(l.commonDelete)),
                            ],
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value, this.color);

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value,
            style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: color)),
        const SizedBox(height: 2),
        Text(label,
            style: TextStyle(
                fontSize: 11,
                color: Theme.of(context).colorScheme.onSurfaceVariant)),
      ],
    );
  }
}
