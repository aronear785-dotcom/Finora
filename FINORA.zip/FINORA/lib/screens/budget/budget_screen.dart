import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../models/budget.dart';
import '../../core/utils/date_utils.dart' as dutils;
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/category.dart';
import '../../providers/providers.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/common_widgets.dart';

/// Monthly budget list with per-category progress, status warnings and
/// copy-to-next-month.
class BudgetScreen extends ConsumerStatefulWidget {
  const BudgetScreen({super.key});

  @override
  ConsumerState<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends ConsumerState<BudgetScreen> {
  DateTime _month = DateTime.now();

  Future<void> _copyToNextMonth() async {
    await ref.read(planningRepositoryProvider).copyBudgetsToNextMonth(
        dutils.DateUtilsX.monthKey(_month));
    if (mounted) showSnack(context, context.l10n.budCopied);
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final monthKey = dutils.DateUtilsX.monthKey(_month);
    final budgetsAsync = ref.watch(budgetsProvider(monthKey));
    final expensesAsync = ref.watch(monthExpensesProvider(_month));
    final catsAsync = ref.watch(categoriesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l.budTitle),
        actions: [
          IconButton(
            tooltip: l.budCopy,
            icon: const Icon(Icons.copy_all_outlined),
            onPressed: _copyToNextMonth,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => BudgetFormScreen(month: _month)));
        },
        icon: const Icon(Icons.add),
        label: Text(l.budSet),
      ),
      body: catsAsync.when(
        data: (cats) {
          final catMap = {for (final c in cats) c.id: c};
          return budgetsAsync.when(
            data: (budgets) {
              final expenses =
                  expensesAsync.valueOrNull ?? const <dynamic>[];
              final spentByCat = <int, double>{};
              for (final e in expenses) {
                spentByCat[e.categoryId as int] =
                    (spentByCat[e.categoryId as int] ?? 0) +
                        (e.amount as num).toDouble();
              }
              if (budgets.isEmpty) {
                return EmptyState(
                  icon: Icons.pie_chart_outline,
                  title: l.budNoData,
                  action: FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (_) =>
                                BudgetFormScreen(month: _month))),
                    icon: const Icon(Icons.add),
                    label: Text(l.budSet),
                  ),
                );
              }
              final totalBudget =
                  budgets.fold<double>(0, (s, b) => s + b.amount);
              final totalSpent = spentByCat.values.fold<double>(0, (s, v) => s + v);

              bool _hasWarning() {
                for (final b in budgets) {
                  final st = FinanceCalculator.budgetStatus(
                      spentByCat[b.categoryId] ?? 0, b.amount, b.warnAt);
                  if (st != FinanceCalculator.BudgetStatus.normal) return true;
                }
                return false;
              }

              return ListView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                children: [
                  MonthHeader(
                    month: _month,
                    onChange: (m) => setState(() => _month = m),
                  ),
                  const SizedBox(height: 8),
                  if (_hasWarning())
                    Card(
                      elevation: 0,
                      color: scheme.errorContainer.withOpacity(0.5),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            Icon(Icons.warning_amber_rounded,
                                color: scheme.onErrorContainer),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                l.budApproachMsg,
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: scheme.onErrorContainer),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 10),
                  Card(
                    elevation: 0,
                    color: scheme.primaryContainer.withOpacity(0.35),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(l.budTotalBudget,
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: scheme.onSurfaceVariant)),
                              Text(fmt.format(totalBudget),
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      color: scheme.primary)),
                            ],
                          ),
                          const SizedBox(height: 12),
                          ProgressBar(
                            value: totalBudget == 0
                                ? 0.0
                                : (totalSpent / totalBudget)
                                    .clamp(0.0, 1.0)
                                    .toDouble(),
                            color: totalSpent > totalBudget
                                ? scheme.error
                                : scheme.primary,
                            height: 10,
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${l.budSpent}: ${fmt.format(totalSpent)}',
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: scheme.onSurfaceVariant)),
                              Text(
                                  '${l.budRemaining}: ${fmt.format(totalBudget - totalSpent)}',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: totalBudget - totalSpent < 0
                                          ? scheme.error
                                          : scheme.onSurfaceVariant)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  for (final b in budgets)
                    _BudgetCard(
                      budget: b,
                      category: catMap[b.categoryId],
                      spent: spentByCat[b.categoryId] ?? 0,
                      fmt: fmt,
                      onTap: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) =>
                                BudgetFormScreen(month: _month, budget: b)));
                      },
                    ),
                ],
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) => Center(child: Text(context.l10n.commonError)),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }
}

class _BudgetCard extends StatelessWidget {
  const _BudgetCard({
    required this.budget,
    required this.category,
    required this.spent,
    required this.fmt,
    required this.onTap,
  });

  final dynamic budget;
  final Category? category;
  final double spent;
  final MoneyFormatter fmt;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final amount = (budget.amount as num).toDouble();
    final warnAt = (budget.warnAt as num?)?.toDouble() ?? 80;
    final status =
        FinanceCalculator.budgetStatus(spent, amount, warnAt);
    final color = switch (status) {
      FinanceCalculator.BudgetStatus.normal => const Color(0xFF00BFA5),
      FinanceCalculator.BudgetStatus.approaching => const Color(0xFFFF8F00),
      FinanceCalculator.BudgetStatus.exceeded => scheme.error,
    };
    final base = category?.color ?? 0xFF6C4DF6;

    return Card(
      elevation: 0,
      color: scheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: AppColors.fromInt(base).withOpacity(0.14),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      AppIcons.resolve(category?.icon ?? 'category'),
                      size: 20,
                      color: AppColors.fromInt(base),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          category != null
                              ? context.categoryLabel(category!.name)
                              : l.catOther,
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w700),
                        ),
                        Text(
                          '${l.budSpent}: ${fmt.format(spent)} / ${l.budRemaining}: ${fmt.format(amount - spent)}',
                          style: TextStyle(
                              fontSize: 12, color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${FinanceCalculator.budgetProgress(spent, amount).toStringAsFixed(0)}%',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: color),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ProgressBar(
                value: FinanceCalculator.budgetProgress(spent, amount) / 100,
                color: color,
              ),
              const SizedBox(height: 6),
              Text(context.budgetStatusLabel(status),
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: color)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Add / edit a monthly budget for a category.
class BudgetFormScreen extends ConsumerStatefulWidget {
  const BudgetFormScreen({super.key, required this.month, this.budget});

  final DateTime month;
  final dynamic budget;

  @override
  ConsumerState<BudgetFormScreen> createState() => _BudgetFormScreenState();
}

class _BudgetFormScreenState extends ConsumerState<BudgetFormScreen> {
  final _amountCtrl = TextEditingController();
  int? _categoryId;
  double _warnAt = 80;
  String _monthKey = '';
  bool _saving = false;

  bool get _isEdit => widget.budget != null;

  @override
  void initState() {
    super.initState();
    final m = widget.month;
    _monthKey =
        '${m.year.toString().padLeft(4, '0')}-${m.month.toString().padLeft(2, '0')}';
    final b = widget.budget;
    if (b != null) {
      _amountCtrl.text = (b.amount as num).toStringAsFixed(2);
      _categoryId = b.categoryId as int;
      _warnAt = (b.warnAt as num?)?.toDouble() ?? 80;
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _save(int categoryId) async {
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final existing = widget.budget;
    await ref.read(planningRepositoryProvider).setBudget(Budget(
          id: existing != null ? existing.id as int? : null,
          categoryId: categoryId,
          amount: amount,
          month: _monthKey,
          warnAt: _warnAt,
        ));
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final catsAsync = ref.watch(categoriesProvider);
    final currencies = ['MAD', 'EUR', 'USD', 'CAD', 'GBP'];

    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.budEdit : l.budSet)),
      body: catsAsync.when(
        data: (cats) {
          final available = cats.where((c) {
            if (_isEdit && c.id == _categoryId) return true;
            return ref
                    .watch(budgetsProvider(_monthKey))
                    .valueOrNull
                    ?.every((b) => b.categoryId != c.id) ??
                true;
          }).toList();
          if (_categoryId == null && available.isNotEmpty) {
            _categoryId = available.first.id;
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('${context.monthlyLabel(widget.month)} · ${l.budTitle}',
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              AmountField(controller: _amountCtrl, hint: '0.00'),
              const SizedBox(height: 18),
              Text(l.commonCategory,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in available)
                    CategoryChip(
                      category: c,
                      selected: _categoryId == c.id,
                      onTap: () => setState(() => _categoryId = c.id),
                    ),
                ],
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: Text(l.budWarnAt,
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w700)),
                  ),
                  Text('${_warnAt.round()}%',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: Theme.of(context).colorScheme.primary)),
                ],
              ),
              Slider(
                value: _warnAt,
                min: 50,
                max: 100,
                divisions: 10,
                label: '${_warnAt.round()}%',
                onChanged: (v) => setState(() => _warnAt = v),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed:
                    _saving || _categoryId == null ? null : () => _save(_categoryId!),
                style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15)),
                child: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(l.commonSave),
              ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }
}


