/// An automatic monthly savings installment for one goal. A positive
/// savings transaction is generated on [dayOfMonth] every month starting at
/// [startMonth] ('YYYY-MM'), unless that month was skipped by the user.
/// Manual savings transactions are independent and never affect the plan.
class SavingsPlan {
  const SavingsPlan({
    this.id,
    required this.goalId,
    required this.amount,
    this.dayOfMonth = 1,
    required this.startMonth,
    this.active = true,
  });

  final int? id;
  final int goalId;
  final double amount;
  final int dayOfMonth;
  final String startMonth;
  final bool active;

  SavingsPlan copyWith({
    int? goalId,
    double? amount,
    int? dayOfMonth,
    String? startMonth,
    bool? active,
  }) =>
      SavingsPlan(
        id: id,
        goalId: goalId ?? this.goalId,
        amount: amount ?? this.amount,
        dayOfMonth: dayOfMonth ?? this.dayOfMonth,
        startMonth: startMonth ?? this.startMonth,
        active: active ?? this.active,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'goal_id': goalId,
        'amount': amount,
        'day_of_month': dayOfMonth,
        'start_month': startMonth,
        'active': active ? 1 : 0,
      };

  factory SavingsPlan.fromMap(Map<String, Object?> map) => SavingsPlan(
        id: map['id'] as int?,
        goalId: map['goal_id'] as int,
        amount: (map['amount'] as num).toDouble(),
        dayOfMonth: (map['day_of_month'] as int?) ?? 1,
        startMonth: map['start_month'] as String,
        active: (map['active'] as int? ?? 1) == 1,
      );
}
