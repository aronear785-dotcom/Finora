import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:finora/database/app_database.dart';
import 'package:finora/domain/ledger_calculator.dart';
import 'package:finora/models/budget.dart';
import 'package:finora/models/category.dart';
import 'package:finora/models/expense.dart';
import 'package:finora/models/loan.dart';
import 'package:finora/models/recurring_income.dart';
import 'package:finora/repositories/automation_repository.dart';
import 'package:finora/repositories/finance_repository.dart';
import 'package:finora/repositories/loan_repository.dart';
import 'package:finora/repositories/planning_repository.dart';

/// Recurring income end date, manual receipt confirmation, bank loans,
/// budget carry-over and quick-add shortcuts.
void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late AppDatabase db;
  late FinanceRepository finance;
  late PlanningRepository planning;
  late AutomationRepository auto;
  late LoanRepository loans;
  late int salaryCat, food, transport, rent;

  setUp(() async {
    db = AppDatabase.forPath(inMemoryDatabasePath);
    finance = FinanceRepository(db: db);
    planning = PlanningRepository(db: db);
    auto = AutomationRepository(db: db);
    loans = LoanRepository(db: db);
    salaryCat = await finance.addCategory(const Category(
        name: 'salary', icon: 'work', color: 0xFF66BB6A, isIncome: true));
    food = await finance
        .addCategory(const Category(name: 'food', icon: 'food', color: 0xFFFFB300));
    transport = await finance.addCategory(
        const Category(name: 'transport', icon: 'car', color: 0xFF42A5F5));
    rent = await finance.addCategory(const Category(
        name: 'rent', icon: 'home', color: 0xFF6C4DF6, expenseType: ExpenseType.fixed));
  });

  tearDown(() async {
    await db.close();
  });

  test('an end month stops an automatic income', () async {
    await auto.addRecurringIncome(RecurringIncome(
        name: 'Contract',
        amount: 1000,
        categoryId: salaryCat,
        startMonth: '2026-01',
        endMonth: '2026-02'));
    await auto.applyDue(now: DateTime(2026, 5, 10));
    expect((await finance.allIncome()).length, 2); // Jan + Feb only

    final march = await auto.summaryForMonth(DateTime(2026, 3, 1));
    expect(march.expectedIncome, 0); // no longer expected after the end
    final feb = await auto.summaryForMonth(DateTime(2026, 2, 1));
    expect(feb.expectedIncome, 1000);
  });

  test('manual receipt: expected until confirmed, then recorded exactly once',
      () async {
    final id = await auto.addRecurringIncome(RecurringIncome(
        name: 'Salary',
        amount: 5000,
        categoryId: salaryCat,
        dayOfMonth: 1,
        startMonth: '2026-03',
        autoReceive: false));
    await auto.applyDue(now: DateTime(2026, 3, 5));
    expect(await finance.allIncome(), isEmpty); // nothing auto-recorded

    var s = await auto.summaryForMonth(DateTime(2026, 3, 1));
    expect(s.expectedIncome, 5000);
    expect(s.actualIncome, 0); // expected is NOT received

    expect(await auto.markReceived(id, '2026-03', now: DateTime(2026, 3, 5)),
        isTrue);
    expect(await auto.markReceived(id, '2026-03', now: DateTime(2026, 3, 6)),
        isFalse); // idempotent
    expect((await finance.allIncome()).length, 1);

    // The scheduled run does not duplicate it either.
    await auto.applyDue(now: DateTime(2026, 3, 7));
    expect((await finance.allIncome()).length, 1);
    s = await auto.summaryForMonth(DateTime(2026, 3, 1));
    expect(s.actualIncome, 5000);
  });

  test('loan installments are split exactly; the last one absorbs rounding',
      () {
    const loan = Loan(
        name: 'Car',
        principal: 10000,
        totalInterest: 1000,
        installments: 3,
        startMonth: '2026-01');
    expect(loan.installmentAmount(1), 3666.66);
    expect(loan.installmentAmount(2), 3666.66);
    expect(loan.installmentAmount(3), 3666.68);
    expect(
        loan.installmentAmount(1) + loan.installmentAmount(2) +
            loan.installmentAmount(3),
        closeTo(11000, 0.0001));
  });

  test('loan installments become fixed expenses once per month; balance falls',
      () async {
    final id = await loans.addLoan(const Loan(
        name: 'Car',
        principal: 10000,
        totalInterest: 1000,
        installments: 3,
        startMonth: '2026-01'));
    expect(await auto.applyDue(now: DateTime(2026, 2, 10)), 2); // Jan + Feb

    var status = (await loans.statuses()).single;
    expect(status.paidCount, 2);
    expect(status.paidAmount, 7333.32);
    expect(status.outstanding, closeTo(3666.68, 0.0001));
    expect(status.finished, isFalse);

    // Running again never duplicates an installment.
    expect(await auto.applyDue(now: DateTime(2026, 2, 11)), 0);
    expect(await auto.applyDue(now: DateTime(2026, 3, 1)), 1);
    status = (await loans.statuses()).single;
    expect(status.finished, isTrue);
    expect(status.outstanding, 0);
    expect(await auto.applyDue(now: DateTime(2026, 6, 1)), 0); // fully repaid

    // Installments are FIXED expenses: they never touch a variable budget.
    final cats = [
      ...await finance.categories(),
      ...await finance.categories(income: true),
    ];
    final march = LedgerCalculator.build(
      incomes: const [],
      expenses: await finance.expensesBetween(
          DateTime(2026, 3, 1), DateTime(2026, 3, 31, 23, 59, 59)),
      savings: const [],
      categories: cats,
      budgets: const [],
    );
    expect(march.fixedExpenses, 3666.68);
    expect(march.variableExpenses, 0);

    await loans.deleteLoan(id);
    expect(await loans.loans(), isEmpty);
    // Recorded installments stay in the expense history.
    expect((await finance.allExpenses()).length, 3);
  });

  test('a received loan is income in its own category, not earned income',
      () async {
    await loans.addLoan(
        const Loan(
            name: 'Car',
            principal: 10000,
            installments: 10,
            startMonth: '2026-04'),
        receivedOn: DateTime(2026, 3, 1));
    final cats = [
      ...await finance.categories(),
      ...await finance.categories(income: true),
    ];
    final l = LedgerCalculator.build(
      incomes: await finance.incomeBetween(
          DateTime(2026, 3, 1), DateTime(2026, 3, 31, 23, 59, 59)),
      expenses: const [],
      savings: const [],
      categories: cats,
      budgets: const [],
    );
    expect(l.receivedIncome, 10000);
    expect(l.loanIncome, 10000);
    expect(l.earnedIncome, 0);
  });

  test('last month\'s variable budgets carry over once, never overwriting',
      () async {
    await planning.setBudget(
        Budget(categoryId: food, amount: 1500, month: '2026-02'));
    expect(await planning.carryOverBudgets(now: DateTime(2026, 3, 10)), 1);
    final march = await planning.budgetsForMonth('2026-03');
    expect(march.single.amount, 1500);
    expect(march.single.categoryId, food);
    expect(await planning.carryOverBudgets(now: DateTime(2026, 3, 11)), 0);
    expect((await planning.budgetsForMonth('2026-03')).length, 1);
  });

  test('quick-add shortcuts: most used variable categories, fixed excluded',
      () async {
    final now = DateTime(2026, 3, 31);
    for (var i = 0; i < 3; i++) {
      await finance.addExpense(Expense(
          amount: 20, categoryId: food, date: DateTime(2026, 3, 10 + i)));
    }
    await finance.addExpense(
        Expense(amount: 10, categoryId: transport, date: DateTime(2026, 3, 20)));
    for (var i = 0; i < 5; i++) {
      await finance.addExpense(Expense(
          amount: 3000, categoryId: rent, date: DateTime(2026, 3, 1 + i)));
    }
    final ids = await finance.frequentExpenseCategoryIds(now: now);
    expect(ids, [food, transport]);
  });
}
