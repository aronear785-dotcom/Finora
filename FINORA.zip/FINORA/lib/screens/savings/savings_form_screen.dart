import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/savings_goal.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Create / edit a savings goal (name, target, icon, color, notes).
class SavingsFormScreen extends ConsumerStatefulWidget {
  const SavingsFormScreen({super.key, this.goal});

  final SavingsGoal? goal;

  @override
  ConsumerState<SavingsFormScreen> createState() => _SavingsFormScreenState();
}

class _SavingsFormScreenState extends ConsumerState<SavingsFormScreen> {
  final _nameCtrl = TextEditingController();
  final _targetCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  int _color = 0xFF6C4DF6;
  String _icon = 'savings';
  bool _saving = false;

  bool get _isEdit => widget.goal != null;

  @override
  void initState() {
    super.initState();
    final g = widget.goal;
    if (g != null) {
      _nameCtrl.text = g.name;
      _targetCtrl.text = g.target.toStringAsFixed(2);
      _noteCtrl.text = g.note ?? '';
      _color = g.color;
      _icon = g.icon;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _targetCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    final raw = _targetCtrl.text.trim().replaceAll(',', '.');
    final target = double.tryParse(raw);
    if (name.isEmpty) {
      showSnack(context, context.l10n.errEmptyField);
      return;
    }
    if (target == null || target <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final repo = ref.read(planningRepositoryProvider);
    final goal = SavingsGoal(
      id: widget.goal?.id,
      name: name,
      target: target,
      color: _color,
      icon: _icon,
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
    );
    try {
      if (_isEdit) {
        await repo.updateSavingsGoal(goal);
      } else {
        await repo.addSavingsGoal(goal);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.savEditGoal : l.savNewGoal)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _nameCtrl,
            decoration: InputDecoration(
              labelText: l.commonName,
              prefixIcon: const Icon(Icons.flag_outlined),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _targetCtrl,
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: l.savTargetAmount,
              prefixIcon: const Icon(Icons.attach_money_outlined),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _noteCtrl,
            maxLines: 2,
            decoration: InputDecoration(
              labelText: '${l.savNotes} (${l.commonOptional})',
              prefixIcon: const Icon(Icons.notes_outlined),
            ),
          ),
          const SizedBox(height: 20),
          Text(l.catColor,
              style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          ColorChoiceBar(selected: _color, onSelect: (c) => setState(() => _color = c)),
          const SizedBox(height: 20),
          Text(l.catIcon,
              style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.fromInt(_color).withOpacity(0.14),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(AppIcons.resolve(_icon),
                    color: AppColors.fromInt(_color)),
              ),
              const SizedBox(width: 12),
              OutlinedButton.icon(
                onPressed: () async {
                  final picked = await pickIcon(context, current: _icon);
                  if (picked != null) setState(() => _icon = picked);
                },
                icon: const Icon(Icons.grid_view_outlined),
                label: Text(l.commonSelect),
              ),
            ],
          ),
          const SizedBox(height: 28),
          FilledButton(
            onPressed: _saving ? null : _save,
            style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15)),
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : Text(l.commonSave),
          ),
        ],
      ),
    );
  }
}
