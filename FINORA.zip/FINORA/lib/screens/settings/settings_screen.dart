import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/date_utils.dart' as dutils;
import '../../l10n/l10n_ext.dart';
import '../../models/app_settings.dart';
import '../../providers/providers.dart';
import '../../services/demo_data_service.dart';
import '../../services/export_service.dart';
import '../../services/reminder_service.dart';
import '../../widgets/common_widgets.dart';
import '../report/report_screen.dart';
import 'categories_screen.dart';

/// Complete settings: language, currency, theme, notifications, export,
/// backup/restore, delete all (with strong confirmation), sample data,
/// privacy & about.
class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  static const _langs = [
    ('system', '🌐'),
    ('en', '🇬🇧'),
    ('fr', '🇫🇷'),
    ('ar', '🇲🇦'),
    ('es', '🇪🇸'),
    ('zh', '🇨🇳'),
    ('ru', '🇷🇺'),
  ];
  static const _currencies = ['MAD', 'EUR', 'USD', 'CAD', 'GBP'];

  Future<void> _save(AppSettings s) async {
    await ref.read(settingsServiceProvider).save(s);
    if (s.remindersEnabled) {
      await ReminderService.instance
          .scheduleDaily(hour: s.reminderHour, minute: s.reminderMinute);
    } else {
      await ReminderService.instance.cancelAll();
    }
  }

  Future<void> _export(String kind) async {
    final svc = ExportService();
    try {
      switch (kind) {
        case 'csv':
          final cats = await ref.read(financeRepositoryProvider).categories();
          final csv = await svc.buildTransactionsCsv(
              categories: {for (final c in cats) c.id: c});
          await svc.shareTextFile(
              csv,
              'finora_export_${dutils.DateUtilsX.monthKey(DateTime.now())}.csv',
              'FINORA CSV');
        case 'pdf':
          Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ReportScreen()));
          return;
        case 'json':
          final backup = await svc.buildJsonBackup();
          await svc.shareTextFile(
              backup,
              'finora_backup_${dutils.DateUtilsX.monthKey(DateTime.now())}.json',
              'FINORA JSON backup');
      }
      if (mounted && kind != 'pdf') showSnack(context, context.l10n.setExported);
    } catch (_) {
      if (mounted) {
        showSnack(context, context.l10n.errImportCorrupted);
      }
    }
  }

  Future<void> _restore() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final bytes = result.files.single.bytes;
      if (bytes == null) {
        if (mounted) showSnack(context, context.l10n.errImportCorrupted);
        return;
      }
      final text = utf8.decode(bytes, allowMalformed: true);
      await ExportService().restoreBackup(text);
      if (mounted) showSnack(context, context.l10n.setImported);
    } catch (_) {
      if (mounted) showSnack(context, context.l10n.setImportFailed);
    }
  }

  Future<void> _deleteAll() async {
    final ok = await confirmDialog(
      context,
      title: context.l10n.setDeleteTitle,
      message: context.l10n.setDeleteMsg,
      confirmLabel: context.l10n.commonDelete,
      destructive: true,
    );
    if (ok) {
      await ref.read(settingsServiceProvider).deleteAllData();
    }
  }

  Future<void> _loadSample() async {
    final svc = DemoDataService();
    await svc.loadSampleData();
    final s = ref.read(settingsProvider).valueOrNull ?? AppSettings.defaults;
    await _save(s.copyWith(sampleLoaded: true));
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final s = ref.watch(settingsProvider).valueOrNull ?? AppSettings.defaults;

    return Scaffold(
      appBar: AppBar(title: Text(l.setTitle)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          _sectionTitle(l.setLanguage),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Column(
              children: [
                for (final (code, flag) in _langs)
                  RadioListTile<String>(
                    dense: true,
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 12),
                    title: Text(
                      code == 'system'
                          ? l.setSystemLang
                          : '${_langName(code)} ($flag)',
                      style: const TextStyle(fontSize: 14),
                    ),
                    value: code,
                    groupValue: s.language,
                    onChanged: (v) => v != null
                        ? _save(s.copyWith(language: v))
                        : null,
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setCurrency),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in _currencies)
                    ChoiceChip(
                      label: Text(c),
                      selected: s.currency == c,
                      onSelected: (_) => _save(s.copyWith(currency: c)),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setTheme),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SegmentedButton<String>(
                segments: [
                  ButtonSegment(
                      value: 'system', label: Text(l.setThemeSystem)),
                  ButtonSegment(value: 'light', label: Text(l.setThemeLight)),
                  ButtonSegment(value: 'dark', label: Text(l.setThemeDark)),
                ],
                selected: {s.theme},
                onSelectionChanged: (sel) =>
                    _save(s.copyWith(theme: sel.first)),
                showSelectedIcon: false,
              ),
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setNotifications),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Column(
              children: [
                SwitchListTile(
                  title: Text(l.setReminders,
                      style: const TextStyle(fontSize: 14)),
                  value: s.remindersEnabled,
                  onChanged: (v) =>
                      _save(s.copyWith(remindersEnabled: v)),
                ),
                ListTile(
                  enabled: s.remindersEnabled,
                  leading: const Icon(Icons.schedule_outlined),
                  title: Text(l.setReminderTime,
                      style: const TextStyle(fontSize: 14)),
                  trailing: Text(
                    '${s.reminderHour.toString().padLeft(2, '0')}:'
                    '${s.reminderMinute.toString().padLeft(2, '0')}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(
                          hour: s.reminderHour, minute: s.reminderMinute),
                    );
                    if (t != null) {
                      await _save(s.copyWith(
                          reminderHour: t.hour, reminderMinute: t.minute));
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setExport),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.table_chart_outlined),
                  title: Text(l.expCsv,
                      style: const TextStyle(fontSize: 14)),
                  onTap: () => _export('csv'),
                ),
                ListTile(
                  leading: const Icon(Icons.picture_as_pdf_outlined),
                  title: Text(l.expPdf,
                      style: const TextStyle(fontSize: 14)),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const ReportRoute())),
                ),
                ListTile(
                  leading: const Icon(Icons.save_alt_outlined),
                  title: Text(l.expJson,
                      style: const TextStyle(fontSize: 14)),
                  subtitle: Text(l.setWarnBackup,
                      style: const TextStyle(fontSize: 11)),
                  onTap: () => _export('json'),
                ),
                ListTile(
                  leading: const Icon(Icons.restore_outlined),
                  title: Text(l.setRestore,
                      style: const TextStyle(fontSize: 14)),
                  onTap: _restore,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setSample),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.auto_awesome_outlined),
                  title: Text(l.setLoadSample,
                      style: const TextStyle(fontSize: 14)),
                  subtitle: Text(l.setSampleWarn,
                      style: const TextStyle(fontSize: 11)),
                  onTap: s.sampleLoaded ? null : _loadSample,
                ),
                ListTile(
                  enabled: s.sampleLoaded,
                  leading: const Icon(Icons.delete_sweep_outlined),
                  title: Text(l.setRemoveSample,
                      style: const TextStyle(fontSize: 14)),
                  onTap: () async {
                    final ok = await confirmDialog(context,
                        title: l.setRemoveSample,
                        message: l.setSampleWarn,
                        destructive: true);
                    if (ok) {
                      await ref
                          .read(settingsServiceProvider)
                          .deleteAllData();
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.catManage),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: ListTile(
              leading: const Icon(Icons.category_outlined),
              title: Text(l.catManage,
                  style: const TextStyle(fontSize: 14)),
              subtitle: Text(l.catManage,
                  style: const TextStyle(fontSize: 11)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const CategoriesScreen())),
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setDeleteAll),
          Card(
            elevation: 0,
            color: scheme.errorContainer.withValues(alpha: 0.35),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: ListTile(
              leading: Icon(Icons.delete_forever_outlined,
                  color: scheme.error),
              title: Text(l.setDeleteAll,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: scheme.error)),
              onTap: _deleteAll,
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setPrivacy),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(l.setPrivacyBody,
                  style: const TextStyle(fontSize: 13, height: 1.5)),
            ),
          ),
          const SizedBox(height: 16),
          _sectionTitle(l.setAbout),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Image.asset('assets/images/logo.png',
                        width: 52, height: 52),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('FINORA',
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: scheme.primary)),
                        Text(l.tagline,
                            style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 2),
                        Text('v1.0.0 · ${l.setPrivacy}',
                            style: TextStyle(
                                fontSize: 11,
                                color: scheme.onSurfaceVariant)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 6),
        child: Text(title,
            style: const TextStyle(
                fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 0.3)),
      );

  String _langName(String code) => switch (code) {
        'en' => 'English',
        'fr' => 'Français',
        'ar' => 'العربية',
        'es' => 'Español',
        'zh' => '中文',
        'ru' => 'Русский',
        _ => 'Auto',
      };
}


