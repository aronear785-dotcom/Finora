/// An income record. Date is stored as a UTC-midnight epoch millisecond.
class Income {
  const Income({
    this.id,
    required this.amount,
    required this.categoryId,
    required this.date,
    this.note,
    this.isRecurring = false,
  });

  final int? id;
  final double amount;
  final int categoryId;
  final DateTime date;
  final String? note;
  final bool isRecurring;

  Income copyWith({
    double? amount,
    int? categoryId,
    DateTime? date,
    String? note,
    bool? isRecurring,
  }) =>
      Income(
        id: id,
        amount: amount ?? this.amount,
        categoryId: categoryId ?? this.categoryId,
        date: date ?? this.date,
        note: note ?? this.note,
        isRecurring: isRecurring ?? this.isRecurring,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'amount': amount,
        'category_id': categoryId,
        'date': date.millisecondsSinceEpoch,
        'note': note,
        'recurring': isRecurring ? 1 : 0,
      };

  factory Income.fromMap(Map<String, Object?> map) => Income(
        id: map['id'] as int?,
        amount: (map['amount'] as num).toDouble(),
        categoryId: map['category_id'] as int,
        date: DateTime.fromMillisecondsSinceEpoch(map['date'] as int),
        note: map['note'] as String?,
        isRecurring: (map['recurring'] as int? ?? 0) == 1,
      );
}
