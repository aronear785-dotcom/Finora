import 'package:sqflite/sqflite.dart';

import '../core/utils/app_bus.dart';
import '../database/app_database.dart';
import '../models/app_settings.dart';

/// Settings + default seeding + data wipe. Accepts an injected [AppDatabase]
/// so tests can run against an in-memory database.
class SettingsService {
  SettingsService({AppDatabase? db}) : _db = db ?? AppDatabase.instance;

  final AppDatabase _db;

  Future<AppSettings> load() async {
    final db = await _db.database;
    final rows = await db.query('settings', where: 'id = 1', limit: 1);
    if (rows.isEmpty) {
      const s = AppSettings.defaults;
      await db.insert('settings', s.toMap());
      return s;
    }
    return AppSettings.fromMap(rows.first);
  }

  Future<void> save(AppSettings settings) async {
    final db = await _db.database;
    final rows = await db.query('settings', where: 'id = 1', limit: 1);
    if (rows.isEmpty) {
      await db.insert('settings', settings.toMap());
    } else {
      await db.update('settings', settings.toMap(), where: 'id = 1');
    }
    AppBus.instance.bump();
  }

  /// Seeds default categories and income categories on first launch.
  Future<void> seedDefaults() async {
    final db = await _db.database;
    final count = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM categories'));
    if (count != null && count > 0) return;
    final now = AppDatabase.now();
    final expenseDefaults = <(String, String, int)>[
      ('rent', 'home', 0xFF6C4DF6),
      ('food', 'food', 0xFFFFB300),
      ('car', 'car', 0xFFF4511E),
      ('transport', 'transport', 0xFF4C8DF6),
      ('education', 'education', 0xFF00897B),
      ('health', 'health', 0xFFE53935),
      ('electricity', 'electricity', 0xFFFFD54F),
      ('water', 'water', 0xFF26A69A),
      ('internet', 'internet', 0xFF5C6BC0),
      ('phone', 'phone', 0xFF66BB6A),
      ('shopping', 'shopping', 0xFFD81B60),
      ('clothing', 'clothing', 0xFF8E24AA),
      ('entertainment', 'entertainment', 0xFFFF8F00),
      ('subscriptions', 'subscriptions', 0xFF78909C),
      ('home', 'chair', 0xFF00BFA5),
      ('other', 'more', 0xFF9E9E9E),
    ];
    await db.transaction((txn) async {
      for (final (name, icon, color) in expenseDefaults) {
        await txn.insert('categories', {
          'name': name,
          'icon': icon,
          'color': color,
          'is_income': 0,
          'is_custom': 0,
          'created_at': now,
        });
      }
      final incomeDefaults = <(String, String, int)>[
        ('salary', 'work', 0xFF66BB6A),
        ('freelance', 'laptop', 0xFF4C8DF6),
        ('bonus', 'gift', 0xFFFFB300),
        ('business', 'business', 0xFF00BFA5),
        ('investment', 'investment', 0xFF5C6BC0),
        ('other', 'more', 0xFF9E9E9E),
      ];
      for (final (name, icon, color) in incomeDefaults) {
        await txn.insert('categories', {
          'name': name,
          'icon': icon,
          'color': color,
          'is_income': 1,
          'is_custom': 0,
          'created_at': now,
        });
      }
    });
    AppBus.instance.bump();
  }

  /// Deletes ALL user data (settings row kept).
  Future<void> deleteAllData() async {
    await _db.wipeUserData();
    AppBus.instance.bump();
  }
}
