import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants.dart';
import '../../core/utils/money_formatter.dart';
import '../../l10n/l10n_ext.dart';
import '../../models/savings_goal.dart';
import '../../providers/providers.dart';
import '../../providers/savings_providers.dart';
import '../../services/finance_calculator.dart';
import '../../widgets/common_widgets.dart';
import 'savings_form_screen.dart';
import 'savings_goal_detail_screen.dart';
import 'savings_plan_screen.dart';

/// Savings goals overview: per-goal progress, savings rate and automatic
/// savings target (planning only - never moves real money).
class SavingsScreen extends ConsumerStatefulWidget {
  const SavingsScreen({super.key});

  @override
  ConsumerState<SavingsScreen> createState() => _SavingsScreenState();
}

class _SavingsScreenState extends ConsumerState<SavingsScreen> {
  static const _rates = <double>[5, 10, 15, 20, 30];

  Future<void> _setRate(double rate) async {
    final service = ref.read(settingsServiceProvider);
    final current = ref.read(settingsProvider).valueOrNull;
    if (current == null) return;
    await service.save(current.copyWith(savingsPercent: rate));
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final fmt = ref.watch(moneyFormatterProvider);
    final goalsAsync = ref.watch(goalsProvider);
    final settings = ref.watch(settingsProvider).valueOrNull;

    final incomeTotal = ref
            .watch(monthIncomeProvider(DateTime.now()))
            .valueOrNull
            ?.fold<double>(0, (s, i) => s + i.amount) ??
        0;
    final rate = settings?.savingsPercent ?? 20;
    final autoTarget =
        FinanceCalculator.automaticSavingsTarget(incomeTotal, rate);

    return Scaffold(
      appBar: AppBar(
        title: Text(l.savTitle),
        actions: [
          IconButton(
            tooltip: l.savPlan,
            icon: const Icon(Icons.calculate_outlined),
            onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SavingsPlanScreen())),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => const SavingsFormScreen()));
        },
        icon: const Icon(Icons.add),
        label: Text(l.savNewGoal),
      ),
      body: goalsAsync.when(
        data: (goals) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
          children: [
            Card(
              elevation: 0,
              color: scheme.surface,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(l.savPercent,
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w700)),
                        const Spacer(),
                        DropdownButton<double>(
                          value: _rates.contains(rate) ? rate : 20,
                          underline: const SizedBox.shrink(),
                          items: [
                            for (final r in _rates)
                              DropdownMenuItem(
                                  value: r, child: Text('${r.round()}%')),
                          ],
                          onChanged: (v) => v != null ? _setRate(v) : null,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.lightbulb_outline,
                            size: 15, color: scheme.primary),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text('${l.savAutoTarget}: ${fmt.format(autoTarget)}',
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: scheme.primary)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (goals.isEmpty)
              EmptyState(
                icon: Icons.savings_outlined,
                title: l.savEmpty,
                action: FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(
                          builder: (_) => const SavingsFormScreen())),
                  icon: const Icon(Icons.add),
                  label: Text(l.savNewGoal),
                ),
              )
            else
              for (final g in goals)
                _GoalCard(
                  goal: g,
                  fmt: fmt,
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) =>
                          SavingsGoalDetailScreen(goalId: g.id!))),
                ),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => Center(child: Text(context.l10n.commonError)),
      ),
    );
  }
}

class _GoalCard extends ConsumerWidget {
  const _GoalCard({
    required this.goal,
    required this.fmt,
    required this.onTap,
  });

  final SavingsGoal goal;
  final MoneyFormatter fmt;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final color = AppColors.fromInt(goal.color);
    final saved = ref
            .watch(savedForGoalProvider(goal.id!))
            .valueOrNull ??
        0;
    final progress = FinanceCalculator.goalProgress(saved, goal.target);
    final remaining = goal.target - saved;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Card(
        elevation: 0,
        color: scheme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(AppIcons.resolve(goal.icon),
                          size: 22, color: color),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(goal.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w700)),
                          Text(
                            '${context.l10n.savRemaining}: ${fmt.format(remaining)}',
                            style: TextStyle(
                                fontSize: 12, color: scheme.onSurfaceVariant),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(fmt.format(saved),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: color)),
                        Text(
                          progress >= 100
                              ? context.l10n.savDone
                              : '${progress.toStringAsFixed(0)}% · ${fmt.format(goal.target)}',
                          style: TextStyle(
                              fontSize: 11, color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ProgressBar(value: progress / 100, color: color, height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
