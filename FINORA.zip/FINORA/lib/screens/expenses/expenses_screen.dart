import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/date_utils.dart' as dutils;
import '../../l10n/l10n_ext.dart';
import '../../models/expense.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';
import 'expense_day_screen.dart' show openDay;
import 'expense_form_screen.dart';

/// Expense history grouped by day + calendar view with per-day totals.
class ExpensesScreen extends ConsumerStatefulWidget {
  const ExpensesScreen({super.key});

  @override
  ConsumerState<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends ConsumerState<ExpensesScreen> {
  DateTime _month = DateTime.now();
  bool _calendar = false;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final fmt = ref.watch(moneyFormatterProvider);
    final catsAsync = ref.watch(categoriesProvider);
    final expensesAsync = ref.watch(monthExpensesProvider(_month));

    return Scaffold(
      appBar: AppBar(
        title: Text(l.navExpenses),
        actions: [
          IconButton(
            tooltip: l.expAdd,
            icon: const Icon(Icons.add_box_outlined),
            onPressed: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const ExpenseFormScreen()));
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: MonthHeader(
              month: _month,
              onChange: (m) => setState(() => _month = m),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SegmentedButton<bool>(
              segments: [
                ButtonSegment(
                    value: false,
                    icon: const Icon(Icons.list_alt_outlined),
                    label: Text(l.expList)),
                ButtonSegment(
                    value: true,
                    icon: const Icon(Icons.calendar_month_outlined),
                    label: Text(l.expCalendar)),
              ],
              selected: {_calendar},
              onSelectionChanged: (s) => setState(() => _calendar = s.first),
              showSelectedIcon: false,
              style: const ButtonStyle(
                  visualDensity: VisualDensity.compact),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: catsAsync.when(
              data: (cats) {
                final catMap = {for (final c in cats) c.id: c};
                return expensesAsync.when(
                  data: (expenses) {
                    if (expenses.isEmpty) {
                      return EmptyState(
                        icon: Icons.receipt_long_outlined,
                        title: l.expEmpty,
                        subtitle: l.homeNoData,
                        action: FilledButton.icon(
                          onPressed: () =>
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) =>
                                      const ExpenseFormScreen())),
                          icon: const Icon(Icons.add),
                          label: Text(l.expAdd),
                        ),
                      );
                    }
                    return _calendar
                        ? _ExpenseCalendar(
                            month: _month,
                            expenses: expenses,
                            catMap: catMap,
                            fmt: fmt,
                          )
                        : _DayGroupedList(
                            month: _month,
                            expenses: expenses,
                            catMap: catMap,
                            fmt: fmt,
                          );
                  },
                  loading: () =>
                      const Center(child: CircularProgressIndicator()),
                  error: (_, __) =>
                      Center(child: Text(context.l10n.commonError)),
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (_, __) =>
                  Center(child: Text(context.l10n.commonError)),
            ),
          ),
        ],
      ),
    );
  }
}

/// Expense list grouped by day with clear daily totals.
class _DayGroupedList extends StatelessWidget {
  const _DayGroupedList({
    required this.month,
    required this.expenses,
    required this.catMap,
    required this.fmt,
  });

  final DateTime month;
  final List<Expense> expenses;
  final Map<int, dynamic> catMap;
  final dynamic fmt;

  @override
  Widget build(BuildContext context) {
    final map = <DateTime, List<Expense>>{};
    for (final e in expenses) {
      final day = DateTime(e.date.year, e.date.month, e.date.day);
      map.putIfAbsent(day, () => []).add(e);
    }
    final days = map.keys.toList()..sort((a, b) => b.compareTo(a));

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
      children: [
        for (final day in days)
          _DayGroup(
            day: day,
            expenses: map[day]!,
            catMap: catMap,
            fmt: fmt,
          ),
      ],
    );
  }
}

class _DayGroup extends StatelessWidget {
  const _DayGroup({
    required this.day,
    required this.expenses,
    required this.catMap,
    required this.fmt,
  });

  final DateTime day;
  final List<Expense> expenses;
  final Map<int, dynamic> catMap;
  final dynamic fmt;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final scheme = Theme.of(context).colorScheme;
    final total = expenses.fold<double>(0, (s, e) => s + e.amount);
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => openDay(context, day,
                categories: catMap, fmt: fmt),
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              child: Row(
                children: [
                  Expanded(
                    child: Text(context.shortDayLabel(day),
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: scheme.onSurface)),
                  ),
                  Text('${l.expDayTotal}: ${money(fmt, total)}',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: scheme.onSurfaceVariant)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          Card(
            elevation: 0,
            color: scheme.surface,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Column(
              children: [
                for (final e in expenses)
                  ListTile(
                    dense: false,
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 14),
                    leading: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: catColor(catMap, e.categoryId)
                            .withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        catIcon(catMap, e.categoryId),
                        size: 19,
                        color: catColor(catMap, e.categoryId),
                      ),
                    ),
                    title: Text(
                      catName(context, catMap, e.categoryId),
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    subtitle: e.note == null || e.note!.isEmpty
                        ? null
                        : Text(e.note!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12)),
                    trailing: Text('-${money(fmt, e.amount)}',
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: scheme.error)),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => ExpenseFormScreen(expense: e))),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// 6-week calendar grid; each cell shows the day with its total expense and
/// transaction count. Selecting a day opens that day's transactions.
class _ExpenseCalendar extends StatelessWidget {
  const _ExpenseCalendar({
    required this.month,
    required this.expenses,
    required this.catMap,
    required this.fmt,
  });

  final DateTime month;
  final List<Expense> expenses;
  final Map<int, dynamic> catMap;
  final dynamic fmt;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final byDay = <int, (double, int)>{};
    for (final e in expenses) {
      final key = DateTime(e.date.year, e.date.month, e.date.day)
          .millisecondsSinceEpoch;
      final cur = byDay[key] ?? (0, 0);
      byDay[key] = (cur.$1 + e.amount, cur.$2 + 1);
    }
    final cells = dutils.DateUtilsX.weekGridFor(month);
    final maxDay = byDay.values.fold<double>(0, (m, v) => v.$1 > m ? v.$1 : m);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
      children: [
        Card(
          elevation: 0,
          color: scheme.surface,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                Row(
                  children: [
                    for (var w = 1; w <= 7; w++)
                      Expanded(
                        child: Center(
                          child: Text(context.weekdayShort(w),
                              style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: scheme.onSurfaceVariant)),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                GridView.count(
                  crossAxisCount: 7,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  children: [
                    for (final day in cells)
                      _CalendarCell(
                        day: day,
                        inMonth: day.month == month.month,
                        total: byDay[day.millisecondsSinceEpoch]?.$1 ?? 0,
                        count: byDay[day.millisecondsSinceEpoch]?.$2 ?? 0,
                        maxDay: maxDay,
                        onTap: () => openDay(context, day,
                            categories: catMap, fmt: fmt),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _CalendarCell extends StatelessWidget {
  const _CalendarCell({
    required this.day,
    required this.inMonth,
    required this.total,
    required this.count,
    required this.maxDay,
    required this.onTap,
  });

  final DateTime day;
  final bool inMonth;
  final double total;
  final int count;
  final double maxDay;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final has = total > 0;
    final intensity = maxDay <= 0
        ? 0.0
        : (total / maxDay * 0.35 + 0.08).clamp(0.08, 0.45);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        decoration: BoxDecoration(
          color: has
              ? scheme.primary.withValues(alpha: intensity)
              : (inMonth
                  ? scheme.surfaceContainerHighest.withValues(alpha: 0.4)
                  : Colors.transparent),
          borderRadius: BorderRadius.circular(10),
        ),
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('${day.day}',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: inMonth ? scheme.onSurface : scheme.outline)),
            if (has) ...[
              const SizedBox(height: 2),
              Text(money(fmt, total),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 8, fontWeight: FontWeight.w600, color: scheme.primary)),
              Text('$count',
                  style: TextStyle(fontSize: 7, color: scheme.onSurfaceVariant)),
            ],
          ],
        ),
      ),
    );
  }
}

// Small helpers (no SQL, no logic - pure display mapping).
String money(dynamic fmt, double v) =>
    fmt.formatCompact(v) as String;

Color catColor(Map<int, dynamic> map, int id) =>
    map[id] != null ? Color(map[id].color as int) : const Color(0xFF6C4DF6);

IconData catIcon(Map<int, dynamic> map, int id) => map[id] != null
    ? (switch (map[id].icon as String) {
        'home' => Icons.home_outlined,
        'food' => Icons.restaurant_outlined,
        'car' => Icons.directions_car_outlined,
        'transport' => Icons.directions_bus_outlined,
        'education' => Icons.school_outlined,
        'health' => Icons.favorite_outline,
        'electricity' => Icons.bolt_outlined,
        'water' => Icons.water_drop_outlined,
        'internet' => Icons.wifi_outlined,
        'phone' => Icons.phone_outlined,
        'shopping' => Icons.shopping_bag_outlined,
        'clothing' => Icons.checkroom_outlined,
        'entertainment' => Icons.movie_outlined,
        'subscriptions' => Icons.subscriptions_outlined,
        'chair' => Icons.chair_outlined,
        'more' => Icons.more_horiz,
        _ => Icons.category_outlined,
      })
    : Icons.category_outlined;

String catName(BuildContext context, Map<int, dynamic> map, int id) {
  final c = map[id];
  if (c == null) return context.l10n.catOther;
  final label = context.l10n.t('cat.${c.name}');
  return label == 'cat.${c.name}' ? c.name as String : label;
}
