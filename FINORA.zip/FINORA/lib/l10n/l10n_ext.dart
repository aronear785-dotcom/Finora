import 'package:flutter/material.dart';

import '../services/finance_calculator.dart';
import 'app_localizations.dart';

/// Convenience accessors for localized strings + labels derived from stored
/// database keys. "All visible text is localized" is enforced here: stored
/// category names are keys like 'food' that map to cat.* entries.
extension AppLocalizationsContext on BuildContext {
  AppLocalizations get l10n =>
      Localizations.of<AppLocalizations>(this, AppLocalizations)!;

  String monthName(int month) => switch (month) {
        1 => l10n.m1,
        2 => l10n.m2,
        3 => l10n.m3,
        4 => l10n.m4,
        5 => l10n.m5,
        6 => l10n.m6,
        7 => l10n.m7,
        8 => l10n.m8,
        9 => l10n.m9,
        10 => l10n.m10,
        11 => l10n.m11,
        12 => l10n.m12,
        _ => '',
      };

  String weekdayShort(int weekday) => switch (weekday) {
        1 => l10n.w1,
        2 => l10n.w2,
        3 => l10n.w3,
        4 => l10n.w4,
        5 => l10n.w5,
        6 => l10n.w6,
        7 => l10n.w7,
        _ => '',
      };

  /// Category display label: 'food' -> localized cat.food; custom category
  /// names are shown as-is.
  String categoryLabel(String storedName) =>
      _localize('cat.$storedName', storedName);

  /// Income category label: 'salary' -> localized inc.salary.
  String incomeLabel(String storedName) =>
      _localize('inc.$storedName', storedName);

  /// Payment method label: 'cash' -> localized pay.cash.
  String paymentLabel(String storedName) =>
      _localize('pay.$storedName', storedName);

  String frequencyLabel(String f) => switch (f) {
        'daily' => l10n.recDaily,
        'weekly' => l10n.recWeekly,
        'monthly' => l10n.recMonthly,
        'yearly' => l10n.recYearly,
        _ => f,
      };

  String budgetStatusLabel(BudgetStatus status) => switch (status) {
        BudgetStatus.normal => l10n.budNormal,
        BudgetStatus.approaching => l10n.budApproaching,
        BudgetStatus.exceeded => l10n.budExceeded,
      };

  String monthlyLabel(DateTime month) =>
      '${monthName(month.month)} ${month.year}';

  String shortDayLabel(DateTime d) =>
      '${weekdayShort(d.weekday)} ${d.day}';

  String _localize(String key, String fallback) {
    final t = l10n.t(key);
    return t == key ? fallback : t;
  }
}
