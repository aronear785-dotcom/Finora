/// An automatic monthly income template (e.g. salary). A real income row is
/// generated for it on [dayOfMonth] of every month starting at [startMonth]
/// ('YYYY-MM'), unless that month was skipped by the user.
class RecurringIncome {
  const RecurringIncome({
    this.id,
    required this.name,
    required this.amount,
    required this.categoryId,
    this.dayOfMonth = 1,
    required this.startMonth,
    this.active = true,
  });

  final int? id;
  final String name;
  final double amount;
  final int categoryId;
  final int dayOfMonth;
  final String startMonth;
  final bool active;

  RecurringIncome copyWith({
    String? name,
    double? amount,
    int? categoryId,
    int? dayOfMonth,
    String? startMonth,
    bool? active,
  }) =>
      RecurringIncome(
        id: id,
        name: name ?? this.name,
        amount: amount ?? this.amount,
        categoryId: categoryId ?? this.categoryId,
        dayOfMonth: dayOfMonth ?? this.dayOfMonth,
        startMonth: startMonth ?? this.startMonth,
        active: active ?? this.active,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'amount': amount,
        'category_id': categoryId,
        'day_of_month': dayOfMonth,
        'start_month': startMonth,
        'active': active ? 1 : 0,
      };

  factory RecurringIncome.fromMap(Map<String, Object?> map) => RecurringIncome(
        id: map['id'] as int?,
        name: map['name'] as String,
        amount: (map['amount'] as num).toDouble(),
        categoryId: map['category_id'] as int,
        dayOfMonth: (map['day_of_month'] as int?) ?? 1,
        startMonth: map['start_month'] as String,
        active: (map['active'] as int? ?? 1) == 1,
      );
}
