/// A subscription. [period] is 'monthly' or 'yearly'.
class Subscription {
  const Subscription({
    this.id,
    required this.name,
    required this.amount,
    this.period = 'monthly',
    this.categoryId,
    this.active = true,
    this.nextBilling,
  });

  final int? id;
  final String name;
  final double amount;
  final String period;
  final int? categoryId;
  final bool active;
  final DateTime? nextBilling;

  Subscription copyWith({
    String? name,
    double? amount,
    String? period,
    int? categoryId,
    bool? active,
    DateTime? nextBilling,
  }) =>
      Subscription(
        id: id,
        name: name ?? this.name,
        amount: amount ?? this.amount,
        period: period ?? this.period,
        categoryId: categoryId ?? this.categoryId,
        active: active ?? this.active,
        nextBilling: nextBilling ?? this.nextBilling,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'amount': amount,
        'period': period,
        'category_id': categoryId,
        'active': active ? 1 : 0,
        'next_billing': nextBilling?.millisecondsSinceEpoch,
      };

  factory Subscription.fromMap(Map<String, Object?> map) => Subscription(
        id: map['id'] as int?,
        name: map['name'] as String,
        amount: (map['amount'] as num).toDouble(),
        period: (map['period'] as String?) ?? 'monthly',
        categoryId: map['category_id'] as int?,
        active: (map['active'] as int? ?? 1) == 1,
        nextBilling: map['next_billing'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(map['next_billing'] as int),
      );
}
