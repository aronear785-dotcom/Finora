import 'package:sqflite/sqflite.dart';

import '../core/utils/app_bus.dart';
import '../domain/money.dart';
import '../core/utils/date_utils.dart';
import '../database/app_database.dart';
import '../models/loan.dart';
import '../models/plan_run.dart';
import '../models/recurring_income.dart';
import '../models/savings_plan.dart';
import 'loan_repository.dart';

/// Figures for the monthly summary card.
///
/// * [expectedIncome] - automatic income planned for the month (skipped
///   months excluded).
/// * [autoSavings]    - automatic savings installments planned for the month
///   (skipped months excluded).
/// * [expenses]       - expenses recorded in the month.
/// * [remaining]      - ACTUAL balance: recorded income - recorded savings
///   (automatic AND manual) - recorded expenses.
class MonthPlanSummary {
  const MonthPlanSummary({
    required this.expectedIncome,
    required this.autoSavings,
    required this.expenses,
    required this.actualIncome,
    required this.actualSavings,
  });

  final double expectedIncome;
  final double autoSavings;
  final double expenses;
  final double actualIncome;
  final double actualSavings;

  double get remaining => actualIncome - actualSavings - expenses;

  /// Difference between the actual balance and the planned arithmetic
  /// (expected income - automatic savings - expenses): manual income/savings
  /// entries and automatic items that are not due yet.
  double get adjustment => remaining - (expectedIncome - autoSavings - expenses);

  bool get hasPlans => expectedIncome > 0 || autoSavings > 0;
}

/// Automatic monthly income and savings.
///
/// How it works:
///  * A plan (recurring income or savings installment) fires on its
///    day-of-month. [applyDue] turns every due month into a REAL income /
///    savings transaction and records it in the `plan_runs` ledger, so
///    running it again (app start, resume, ...) never creates duplicates and
///    a transaction the user deleted by hand is never silently recreated.
///  * [skipMonth] cancels ONE month only (removing that month's generated
///    transaction if it already ran). Other months are untouched.
///  * Manual savings are plain savings transactions; they never touch plans.
class AutomationRepository {
  AutomationRepository({AppDatabase? db}) : _db = db ?? AppDatabase.instance;

  final AppDatabase _db;

  Future<Database> get _database => _db.database;

  // ------------------------------------------------------------------ helpers
  static String monthKey(DateTime d) => DateUtilsX.monthKey(d);

  /// Date a plan fires in [month]; days past the month's end use its last day.
  static DateTime occurrence(DateTime month, int day) {
    final last = DateTime(month.year, month.month + 1, 0).day;
    final d = day < 1 ? 1 : (day > last ? last : day);
    return DateTime(month.year, month.month, d);
  }

  /// First month a NEW plan should apply to: this month if its day has not
  /// passed yet, otherwise next month (so creating a plan never back-fills a
  /// date that already went by).
  static String nextStartMonth(int day, {DateTime? now}) {
    final n = now ?? DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final thisMonth = DateTime(n.year, n.month, 1);
    final useNext = occurrence(thisMonth, day).isBefore(today);
    return monthKey(useNext ? DateTime(n.year, n.month + 1, 1) : thisMonth);
  }

  static DateTime _parseMonth(String key) {
    final parts = key.split('-');
    return DateTime(int.parse(parts[0]), int.parse(parts[1]), 1);
  }

  // ---------------------------------------------------------- recurring income
  Future<List<RecurringIncome>> recurringIncomes() async {
    final db = await _database;
    final rows = await db.query('recurring_incomes', orderBy: 'id ASC');
    return rows.map(RecurringIncome.fromMap).toList();
  }

  Future<int> addRecurringIncome(RecurringIncome r) async {
    final db = await _database;
    final id = await db.insert(
        'recurring_incomes', {...r.toMap(), 'created_at': AppDatabase.now()});
    AppBus.instance.bump();
    return id;
  }

  Future<void> updateRecurringIncome(RecurringIncome r) async {
    final db = await _database;
    await db.update('recurring_incomes', r.toMap(),
        where: 'id = ?', whereArgs: [r.id]);
    AppBus.instance.bump();
  }

  /// Deletes the plan and its ledger. Transactions it already generated stay
  /// in the history.
  Future<void> deleteRecurringIncome(int id) async {
    final db = await _database;
    await db.transaction((txn) async {
      await txn.delete('plan_runs',
          where: 'kind = ? AND plan_id = ?',
          whereArgs: [PlanKind.income.name, id]);
      await txn.delete('recurring_incomes', where: 'id = ?', whereArgs: [id]);
    });
    AppBus.instance.bump();
  }

  // ------------------------------------------------------------ savings plans
  Future<List<SavingsPlan>> savingsPlans() async {
    final db = await _database;
    final rows = await db.query('savings_plans', orderBy: 'id ASC');
    return rows.map(SavingsPlan.fromMap).toList();
  }

  Future<SavingsPlan?> planForGoal(int goalId) async {
    final db = await _database;
    final rows = await db.query('savings_plans',
        where: 'goal_id = ?', whereArgs: [goalId], limit: 1);
    return rows.isEmpty ? null : SavingsPlan.fromMap(rows.first);
  }

  /// Creates the plan, or updates the goal's existing one (one plan per goal).
  Future<int> saveSavingsPlan(SavingsPlan p) async {
    final db = await _database;
    final existing = p.id ?? (await planForGoal(p.goalId))?.id;
    int id;
    if (existing != null) {
      await db.update('savings_plans', {...p.toMap(), 'id': existing},
          where: 'id = ?', whereArgs: [existing]);
      id = existing;
    } else {
      id = await db.insert(
          'savings_plans', {...p.toMap(), 'created_at': AppDatabase.now()});
    }
    AppBus.instance.bump();
    return id;
  }

  Future<void> deleteSavingsPlan(int id) async {
    final db = await _database;
    await db.transaction((txn) async {
      await txn.delete('plan_runs',
          where: 'kind = ? AND plan_id = ?',
          whereArgs: [PlanKind.savings.name, id]);
      await txn.delete('savings_plans', where: 'id = ?', whereArgs: [id]);
    });
    AppBus.instance.bump();
  }

  // -------------------------------------------------------------------- runs
  Future<List<PlanRun>> runsForMonth(String month) async {
    final db = await _database;
    final rows =
        await db.query('plan_runs', where: 'month = ?', whereArgs: [month]);
    return rows.map(PlanRun.fromMap).toList();
  }

  /// Cancels ONE month of a plan (e.g. an emergency). If that month's
  /// transaction was already generated it is removed; every other month and
  /// the plan itself are untouched.
  Future<void> skipMonth(PlanKind kind, int planId, String month) async {
    final db = await _database;
    await db.transaction((txn) async {
      final rows = await txn.query('plan_runs',
          where: 'kind = ? AND plan_id = ? AND month = ?',
          whereArgs: [kind.name, planId, month],
          limit: 1);
      if (rows.isNotEmpty) {
        final txId = rows.first['tx_id'] as int?;
        if (txId != null) {
          await txn.delete(
              kind == PlanKind.income ? 'income' : 'savings_transactions',
              where: 'id = ?',
              whereArgs: [txId]);
        }
        await txn.update('plan_runs', {'status': 'skipped', 'tx_id': null},
            where: 'id = ?', whereArgs: [rows.first['id']]);
      } else {
        await txn.insert('plan_runs', {
          'kind': kind.name,
          'plan_id': planId,
          'month': month,
          'status': 'skipped',
          'created_at': AppDatabase.now(),
        });
      }
    });
    AppBus.instance.bump();
  }

  /// Undoes [skipMonth]: the month applies again (and is generated right
  /// away when its date has already passed).
  Future<void> restoreMonth(PlanKind kind, int planId, String month,
      {DateTime? now}) async {
    final db = await _database;
    await db.delete('plan_runs',
        where: "kind = ? AND plan_id = ? AND month = ? AND status = 'skipped'",
        whereArgs: [kind.name, planId, month]);
    await applyDue(now: now);
    AppBus.instance.bump();
  }

  /// Manual-receipt workflow: records ONE income for [planId] in [month]
  /// (the user confirmed the money arrived). Idempotent: returns false and
  /// creates nothing when that month was already received or skipped.
  Future<bool> markReceived(int planId, String month, {DateTime? now}) async {
    final db = await _database;
    final today = now ?? DateTime.now();
    var created = false;
    await db.transaction((txn) async {
      if (await _hasRun(txn, PlanKind.income, planId, month)) return;
      final rows = await txn.query('recurring_incomes',
          where: 'id = ?', whereArgs: [planId], limit: 1);
      if (rows.isEmpty) return;
      final plan = RecurringIncome.fromMap(rows.first);
      final occ = occurrence(_parseMonth(month), plan.dayOfMonth);
      final todayStart = DateTime(today.year, today.month, today.day);
      final date = occ.isAfter(todayStart) ? todayStart : occ;
      final txId = await txn.insert('income', {
        'amount': plan.amount,
        'category_id': plan.categoryId,
        'date': date.millisecondsSinceEpoch,
        'note': plan.name,
        'recurring': 1,
        'created_at': AppDatabase.now(),
      });
      await txn.insert('plan_runs', {
        'kind': PlanKind.income.name,
        'plan_id': planId,
        'month': month,
        'status': 'done',
        'tx_id': txId,
        'created_at': AppDatabase.now(),
      });
      created = true;
    });
    if (created) AppBus.instance.bump();
    return created;
  }

  // ------------------------------------------------------------------ engine
  List<DateTime> _monthsToProcess(
      String startMonth, DateTime today, DateTime firstAllowed,
      {String? endMonth}) {
    var m = _parseMonth(startMonth);
    if (m.isBefore(firstAllowed)) m = firstAllowed;
    var last = DateTime(today.year, today.month, 1);
    if (endMonth != null) {
      final end = _parseMonth(endMonth);
      if (end.isBefore(last)) last = end;
    }
    final out = <DateTime>[];
    while (!m.isAfter(last)) {
      out.add(m);
      m = DateTime(m.year, m.month + 1, 1);
    }
    return out;
  }

  Future<bool> _hasRun(
      DatabaseExecutor db, PlanKind kind, int planId, String month) async {
    final rows = await db.query('plan_runs',
        columns: ['id'],
        where: 'kind = ? AND plan_id = ? AND month = ?',
        whereArgs: [kind.name, planId, month],
        limit: 1);
    return rows.isNotEmpty;
  }

  /// Generates every due, not-yet-handled month of every active plan.
  /// Safe to call as often as you like (idempotent). Catches up at most
  /// [maxMonthsBack] months if the app was not opened for a long time.
  /// Returns how many transactions were created.
  Future<int> applyDue({DateTime? now, int maxMonthsBack = 12}) async {
    final db = await _database;
    final today = now ?? DateTime.now();
    final todayStart = DateTime(today.year, today.month, today.day);
    final firstAllowed = DateTime(today.year, today.month - maxMonthsBack, 1);
    var created = 0;

    await db.transaction((txn) async {
      final incomeRows =
          await txn.query('recurring_incomes', where: 'active = 1');
      for (final row in incomeRows) {
        final plan = RecurringIncome.fromMap(row);
        // Manual-receipt plans stay "expected" until the user confirms.
        if (!plan.autoReceive) continue;
        for (final m in _monthsToProcess(plan.startMonth, today, firstAllowed,
            endMonth: plan.endMonth)) {
          final key = monthKey(m);
          if (await _hasRun(txn, PlanKind.income, plan.id!, key)) continue;
          final occ = occurrence(m, plan.dayOfMonth);
          if (occ.isAfter(todayStart)) continue; // not due yet
          final txId = await txn.insert('income', {
            'amount': plan.amount,
            'category_id': plan.categoryId,
            'date': occ.millisecondsSinceEpoch,
            'note': plan.name,
            'recurring': 1,
            'created_at': AppDatabase.now(),
          });
          await txn.insert('plan_runs', {
            'kind': PlanKind.income.name,
            'plan_id': plan.id,
            'month': key,
            'status': 'done',
            'tx_id': txId,
            'created_at': AppDatabase.now(),
          });
          created++;
        }
      }

      final savingsRows = await txn.query('savings_plans', where: 'active = 1');
      for (final row in savingsRows) {
        final plan = SavingsPlan.fromMap(row);
        for (final m in _monthsToProcess(plan.startMonth, today, firstAllowed)) {
          final key = monthKey(m);
          if (await _hasRun(txn, PlanKind.savings, plan.id!, key)) continue;
          final occ = occurrence(m, plan.dayOfMonth);
          if (occ.isAfter(todayStart)) continue;
          final txId = await txn.insert('savings_transactions', {
            'goal_id': plan.goalId,
            'amount': plan.amount,
            'date': occ.millisecondsSinceEpoch,
            'note': null,
            'created_at': AppDatabase.now(),
          });
          await txn.insert('plan_runs', {
            'kind': PlanKind.savings.name,
            'plan_id': plan.id,
            'month': key,
            'status': 'done',
            'tx_id': txId,
            'created_at': AppDatabase.now(),
          });
          created++;
        }
      }

      // Bank-loan installments -> fixed expenses, once per loan and month.
      final loanRows = await txn.query('loans', where: 'active = 1');
      if (loanRows.isNotEmpty) {
        final loanCat = await LoanRepository.ensureLoanCategory(txn, income: false);
        final lastMonth = DateTime(today.year, today.month, 1);
        for (final row in loanRows) {
          final loan = Loan.fromMap(row);
          final start = _parseMonth(loan.startMonth);
          for (var k = 0; k < loan.installments; k++) {
            final m = DateTime(start.year, start.month + k, 1);
            if (m.isAfter(lastMonth)) break;
            if (m.isBefore(firstAllowed)) continue;
            final key = monthKey(m);
            final paid = await txn.query('loan_payments',
                columns: ['id'],
                where: 'loan_id = ? AND month = ?',
                whereArgs: [loan.id, key],
                limit: 1);
            if (paid.isNotEmpty) continue;
            final occ = occurrence(m, loan.dayOfMonth);
            if (occ.isAfter(todayStart)) break;
            final amount = loan.installmentAmount(k + 1);
            final expenseId = await txn.insert('expenses', {
              'amount': amount,
              'category_id': loanCat,
              'date': occ.millisecondsSinceEpoch,
              'note': loan.name,
              'created_at': AppDatabase.now(),
            });
            await txn.insert('loan_payments', {
              'loan_id': loan.id,
              'month': key,
              'amount': amount,
              'expense_id': expenseId,
              'created_at': AppDatabase.now(),
            });
            created++;
          }
        }
      }
    });
    if (created > 0) AppBus.instance.bump();
    return created;
  }

  // ----------------------------------------------------------------- summary
  Future<double> _sum(Database db, String table, int start, int end) async {
    final rows = await db.rawQuery(
        'SELECT COALESCE(SUM(CAST(ROUND(amount * 100) AS INTEGER)),0) AS s FROM $table '
        'WHERE date >= ? AND date <= ?',
        [start, end]);
    return Money.fromCents((rows.first['s'] as num).toInt());
  }

  /// Expected automatic income, automatic savings, expenses and the actual
  /// remaining balance for [month].
  Future<MonthPlanSummary> summaryForMonth(DateTime month) async {
    final db = await _database;
    final key = monthKey(month);
    final start = DateUtilsX.monthStart(month).millisecondsSinceEpoch;
    final end = DateUtilsX.monthEnd(month).millisecondsSinceEpoch;

    final skipped = await db.query('plan_runs',
        columns: ['kind', 'plan_id'],
        where: "month = ? AND status = 'skipped'",
        whereArgs: [key]);
    final skippedIncome = <int>{
      for (final r in skipped)
        if (r['kind'] == 'income') r['plan_id'] as int
    };
    final skippedSavings = <int>{
      for (final r in skipped)
        if (r['kind'] == 'savings') r['plan_id'] as int
    };

    var expectedIncome = 0.0;
    for (final p in await recurringIncomes()) {
      if (p.active &&
          p.startMonth.compareTo(key) <= 0 &&
          (p.endMonth == null || key.compareTo(p.endMonth!) <= 0) &&
          !skippedIncome.contains(p.id)) {
        expectedIncome += p.amount;
      }
    }
    var autoSavings = 0.0;
    for (final p in await savingsPlans()) {
      if (p.active &&
          p.startMonth.compareTo(key) <= 0 &&
          !skippedSavings.contains(p.id)) {
        autoSavings += p.amount;
      }
    }

    return MonthPlanSummary(
      expectedIncome: expectedIncome,
      autoSavings: autoSavings,
      expenses: await _sum(db, 'expenses', start, end),
      actualIncome: await _sum(db, 'income', start, end),
      actualSavings: await _sum(db, 'savings_transactions', start, end),
    );
  }
}
