import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:finora/database/app_database.dart';
import 'package:finora/models/budget.dart';
import 'package:finora/models/category.dart';
import 'package:finora/models/debt.dart';
import 'package:finora/models/expense.dart';
import 'package:finora/models/income.dart';
import 'package:finora/models/recurring_expense.dart';
import 'package:finora/models/savings_goal.dart';
import 'package:finora/models/savings_transaction.dart';
import 'package:finora/models/subscription.dart';
import 'package:finora/repositories/finance_repository.dart';
import 'package:finora/repositories/planning_repository.dart';

/// End-to-end SQLite tests: schema creation, CRUD, integrity constraints,
/// recurring-expense duplicate prevention, all on an in-memory database via
/// the FFI factory (no Android/iOS platform needed).
void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late AppDatabase db;
  late FinanceRepository finance;
  late PlanningRepository planning;

  setUp(() async {
    db = AppDatabase.forPath(inMemoryDatabasePath);
    finance = FinanceRepository(db: db);
    planning = PlanningRepository(db: db);
  });

  tearDown(() async {
    await db.close();
  });

  test('category CRUD with safe delete (used categories are protected)',
      () async {
    final id = await finance.addCategory(Category(
        name: 'Travel', icon: 'flight', color: 0xFF6C4DF6, isCustom: true));
    final cats = await finance.categories();
    expect(cats.map((c) => c.name), contains('Travel'));

    // A category referenced by a transaction cannot be deleted.
    await finance.addExpense(Expense(
        amount: 99, categoryId: id, date: DateTime(2026, 9, 10)));
    await expectLater(finance.deleteCategory(id),
        throwsA(isA<CategoryInUseException>()));

    // An unused category deletes cleanly.
    final id2 = await finance.addCategory(Category(
        name: 'Travel2', icon: 'flight', color: 0xFF6C4DF6, isCustom: true));
    await finance.deleteCategory(id2);
    expect((await finance.categories()).any((c) => c.id == id2), isFalse);
  });

  test('income and expense CRUD with date filtering', () async {
    final cid = await finance.addCategory(Category(
        name: 'Salary', icon: 'work', color: 0xFF6C4DF6, isIncome: true));
    await finance.addIncome(Income(
        amount: 15000,
        categoryId: cid,
        date: DateTime(2026, 9, 1),
        note: 'September salary'));
    await finance.addIncome(
        Income(amount: 2000, categoryId: cid, date: DateTime(2026, 9, 12)));
    await finance.addExpense(Expense(
        amount: 120, categoryId: cid, date: DateTime(2026, 9, 5)));
    await finance.addExpense(Expense(
        amount: 30, categoryId: cid, date: DateTime(2026, 8, 20)));

    final sepIncome = await finance.incomeBetween(
        DateTime(2026, 9, 1), DateTime(2026, 9, 30, 23, 59, 59));
    expect(sepIncome.length, 2);

    final sepExpenses = await finance.expensesBetween(
        DateTime(2026, 9, 1), DateTime(2026, 9, 30, 23, 59, 59));
    expect(sepExpenses.length, 1);

    expect((await finance.allExpenses()).length, 2);

    // Edit + delete round-trip.
    final exp = (await finance.allExpenses()).first;
    await finance.updateExpense(exp.copyWith(amount: 150));
    expect((await finance.allExpenses()).first.amount, 150);
    await finance.deleteExpense(exp.id!);
    expect((await finance.allExpenses()).length, 1);
  });

  test('budget upsert and copy to next month', () async {
    final cid = await finance.addCategory(Category(
        name: 'Food', icon: 'restaurant', color: 0xFFEF5350));
    await planning.setBudget(
        Budget(categoryId: cid, amount: 2500, month: '2026-09'));
    // Second save is an update, not a duplicate.
    await planning.setBudget(
        Budget(categoryId: cid, amount: 3000, month: '2026-09'));
    final sep = await planning.budgetsForMonth('2026-09');
    expect(sep.length, 1);
    expect(sep.first.amount, 3000);

    await planning.copyBudgetsToNextMonth('2026-09');
    final oct = await planning.budgetsForMonth('2026-10');
    expect(oct.length, 1);
    expect(oct.first.amount, 3000);
  });

  test('savings goal transactions drive progress from SQLite', () async {
    final gid = await planning.addSavingsGoal(SavingsGoal(
        name: 'Buy a car', target: 100000, color: 0xFF6C4DF6, icon: 'car'));
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: gid, amount: 20000, date: DateTime(2026, 9, 1)));
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: gid, amount: 5000, date: DateTime(2026, 9, 10)));
    // Withdrawal reduces the saved amount.
    await planning.addSavingsTransaction(SavingsTransaction(
        goalId: gid, amount: -2000, date: DateTime(2026, 9, 12)));

    expect(await planning.savedForGoal(gid), 23000);
    expect(await planning.totalSaved(), 23000);
    final monthSavings = await planning.savedBetween(
        DateTime(2026, 9, 1), DateTime(2026, 9, 30, 23, 59, 59));
    expect(monthSavings, 23000);
    expect((await planning.transactionsForGoal(gid)).length, 3);

    // Deleting the goal cascades to its transactions.
    await planning.deleteSavingsGoal(gid);
    expect(await planning.savingsGoals(), isEmpty);
    expect(await planning.transactionsForGoal(gid), isEmpty);
  });

  test('recurring expense generation never creates duplicates', () async {
    final cid = await finance.addCategory(Category(
        name: 'Internet', icon: 'wifi', color: 0xFF42A5F5));
    final rid = await planning.addRecurringExpense(RecurringExpense(
      name: 'Fiber internet',
      amount: 300,
      categoryId: cid,
      frequency: 'monthly',
      nextDate: DateTime(2026, 9, 1),
    ));

    await planning.generateDueTransactions(since: DateTime(2026, 8, 1));
    final first = (await finance.allExpenses())
        .where((e) => e.recurringSourceId == rid)
        .length;
    expect(first, greaterThan(0));

    // Re-running the generator must not create a second row.
    await planning.generateDueTransactions(since: DateTime(2026, 8, 1));
    final second = (await finance.allExpenses())
        .where((e) => e.recurringSourceId == rid)
        .length;
    expect(second, first);
  });

  test('subscription totals: monthly and yearly, only active ones', () async {
    await planning.addSubscription(Subscription(
        name: 'Netflix', amount: 300, period: 'monthly'));
    await planning.addSubscription(
        Subscription(name: 'Cloud', amount: 1200, period: 'yearly'));

    var totals = await planning.subscriptionTotals();
    expect(totals.monthly, closeTo(400, 0.001));
    expect(totals.yearly, closeTo(4800, 0.001));

    // Deactivating excludes a subscription from the totals.
    final subs = await planning.subscriptions();
    await planning.updateSubscription(Subscription(
        id: subs.first.id,
        name: subs.first.name,
        amount: subs.first.amount,
        period: subs.first.period,
        active: false));
    totals = await planning.subscriptionTotals();
    expect(totals.monthly, closeTo(100, 0.001));
  });

  test('debt CRUD and mark-as-paid', () async {
    final id = await planning.addDebt(Debt(
      person: 'Karim',
      amount: 500,
      direction: Debt.owe,
      date: DateTime(2026, 9, 8),
      note: 'Dinner',
    ));
    await planning.markDebtPaid(id);
    final list = await planning.debts(direction: Debt.owe);
    expect(list.single.status, 'paid');

    await planning.deleteDebt(id);
    expect(await planning.debts(), isEmpty);
  });

  test('wipeUserData removes all user rows but keeps settings', () async {
    final cid = await finance.addCategory(
        Category(name: 'Food', icon: 'restaurant', color: 0xFFEF5350));
    await finance.addExpense(
        Expense(amount: 5, categoryId: cid, date: DateTime(2026, 9, 1)));
    expect((await finance.allExpenses()).length, 1);

    await db.wipeUserData();
    expect(await finance.allExpenses(), isEmpty);
    expect(await finance.categories(), isNotEmpty); // defaults survive
  });
}
