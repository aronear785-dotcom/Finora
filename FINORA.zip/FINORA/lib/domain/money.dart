/// Decimal-safe money arithmetic.
///
/// Amounts are persisted as REAL (2 decimals) and exposed as `double` by the
/// models, but every AGGREGATION goes through integer minor units (cents), so
/// sums such as 0.1 + 0.2 are exact and totals never drift.
class Money {
  Money._();

  /// 12.34 -> 1234 (rounded half away from zero).
  static int toCents(num value) => (value * 100).round();

  static double fromCents(int cents) => cents / 100.0;

  /// Exact sum of [values] (computed in cents).
  static double sum(Iterable<num> values) {
    var cents = 0;
    for (final v in values) {
      cents += toCents(v);
    }
    return fromCents(cents);
  }

  /// a - b, exact to the cent.
  static double subtract(num a, num b) => fromCents(toCents(a) - toCents(b));

  /// True when [amount] is strictly greater than [available] (to the cent).
  static bool exceeds(num amount, num available) =>
      toCents(amount) > toCents(available);
}
