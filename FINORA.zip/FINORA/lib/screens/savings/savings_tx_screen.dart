import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../l10n/l10n_ext.dart';
import '../../models/savings_transaction.dart';
import '../../providers/providers.dart';
import '../../widgets/common_widgets.dart';

/// Add / withdraw money to/from a goal (add or edit a transaction).
class SavingsTxScreen extends ConsumerStatefulWidget {
  const SavingsTxScreen({super.key, required this.goalId, this.existing});

  final int goalId;
  final SavingsTransaction? existing;

  @override
  ConsumerState<SavingsTxScreen> createState() => _SavingsTxScreenState();
}

class _SavingsTxScreenState extends ConsumerState<SavingsTxScreen> {
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  DateTime _date = DateTime.now();
  bool _withdraw = false;
  bool _saving = false;

  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final t = widget.existing;
    if (t != null) {
      _amountCtrl.text = t.amount.abs().toStringAsFixed(2);
      _noteCtrl.text = t.note ?? '';
      _date = t.date;
      _withdraw = t.amount < 0;
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final raw = _amountCtrl.text.trim().replaceAll(',', '.');
    final amount = double.tryParse(raw);
    if (amount == null || amount <= 0) {
      showSnack(context, context.l10n.errInvalidAmount);
      return;
    }
    setState(() => _saving = true);
    final repo = ref.read(planningRepositoryProvider);
    final tx = SavingsTransaction(
      id: widget.existing?.id,
      goalId: widget.goalId,
      amount: _withdraw ? -amount : amount,
      date: _date,
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
    );
    try {
      if (_isEdit) {
        await repo.updateSavingsTransaction(tx);
      } else {
        await repo.addSavingsTransaction(tx);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        showSnack(context, context.l10n.errDbError);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? l.savEditTx : l.savAddTx)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<bool>(
            segments: [
              ButtonSegment(
                  value: false,
                  icon: const Icon(Icons.add_rounded),
                  label: Text(l.savAdd)),
              ButtonSegment(
                  value: true,
                  icon: const Icon(Icons.remove_rounded),
                  label: Text(l.savRemove)),
            ],
            selected: {_withdraw},
            onSelectionChanged: (s) => setState(() => _withdraw = s.first),
            showSelectedIcon: false,
          ),
          const SizedBox(height: 18),
          AmountField(controller: _amountCtrl, hint: '0.00'),
          const SizedBox(height: 14),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.calendar_month_outlined),
            title: Text(l.commonDate,
                style: const TextStyle(fontSize: 14)),
            trailing: Text(
              '${_date.day} ${context.monthName(_date.month)} ${_date.year}',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _date,
                firstDate: DateTime(2000),
                lastDate: DateTime(2100),
              );
              if (picked != null) setState(() => _date = picked);
            },
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _noteCtrl,
            decoration: InputDecoration(
              labelText: '${l.commonNote} (${l.commonOptional})',
              prefixIcon: const Icon(Icons.notes_outlined),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: _saving ? null : _save,
            style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15)),
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : Text(l.commonSave),
          ),
        ],
      ),
    );
  }
}
