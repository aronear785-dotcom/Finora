import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:finora/l10n/app_localizations.dart';
import 'package:finora/l10n/l10n_ext.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const langs = ['en', 'fr', 'ar', 'es', 'zh', 'ru'];

  test('all six ARB files share the identical key set', () async {
    final en = jsonDecode(await rootBundle.loadString('assets/l10n/app_en.arb'))
        as Map<String, dynamic>;
    final enKeys = en.keys.where((k) => !k.startsWith('@')).toSet();
    expect(enKeys.length, 312);

    for (final lang in langs) {
      final raw = jsonDecode(
              await rootBundle.loadString('assets/l10n/app_$lang.arb'))
          as Map<String, dynamic>;
      expect(raw.keys.where((k) => !k.startsWith('@')).toSet(), enKeys,
          reason: 'key parity for $lang');
    }
  });

  test('AppLocalizations loads French and falls back gracefully', () async {
    final fr = await AppLocalizations.load(const Locale('fr'));
    expect(fr.appName, 'FINORA'); // brand kept identical across languages
    expect(fr.t('tagline'), isNot('tagline')); // a real translation, not the key
    expect(fr.t('no.such.key'), 'no.such.key'); // unknown keys fall back
  });

  test('all six locales load without throwing', () async {
    for (final lang in langs) {
      final a = await AppLocalizations.load(Locale(lang));
      expect(a.t('tagline'), isNotEmpty, reason: lang);
      expect(a.navHome, isNotEmpty, reason: lang);
    }
  });

  testWidgets('context extension resolves the active locale', (tester) async {
    await tester.pumpWidget(MaterialApp(
      locale: const Locale('fr'),
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [AppLocalizations.delegate],
      home: Builder(
        builder: (context) => Text(context.l10n.tagline),
      ),
    ));
    final frTagline = (jsonDecode(
                await rootBundle.loadString('assets/l10n/app_fr.arb'))
            as Map<String, dynamic>)['tagline']
        .toString();
    expect(find.text(frTagline), findsOneWidget);
  });
}
