# FINORA release build rules (R8 / --shrink).

# flutter_local_notifications serialises scheduled notifications with Gson
# (reflection + generic TypeToken) - keep it intact under R8.
-keep class com.dexterous.** { *; }
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-keepattributes Signature
-keepattributes *Annotation*

# Optional Play Core classes referenced by the Flutter embedding.
-dontwarn com.google.android.play.core.**
