import 'package:flutter/material.dart';

/// Fixed obligations (rent, internet, loan installments...) never consume a
/// variable budget; variable spending (food, transport...) does.
enum ExpenseType { fixed, variable }

/// A spending category. Icon and color are stored by name/value so the
/// database stays UI-agnostic.
class Category {
  const Category({
    this.id,
    required this.name,
    required this.icon,
    required this.color,
    this.isIncome = false,
    this.isCustom = false,
    this.expenseType = ExpenseType.variable,
  });

  final int? id;
  final String name;
  final String icon;
  final int color;
  final bool isIncome;
  final bool isCustom;

  /// Only meaningful for expense categories (income categories ignore it).
  final ExpenseType expenseType;

  bool get isFixed => !isIncome && expenseType == ExpenseType.fixed;

  Category copyWith({
    String? name,
    String? icon,
    int? color,
    ExpenseType? expenseType,
  }) =>
      Category(
        id: id,
        name: name ?? this.name,
        icon: icon ?? this.icon,
        color: color ?? this.color,
        isIncome: isIncome,
        isCustom: isCustom,
        expenseType: expenseType ?? this.expenseType,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'icon': icon,
        'color': color,
        'is_income': isIncome ? 1 : 0,
        'is_custom': isCustom ? 1 : 0,
        'expense_type': expenseType.name,
      };

  factory Category.fromMap(Map<String, Object?> map) => Category(
        id: map['id'] as int?,
        name: map['name'] as String,
        icon: (map['icon'] as String?) ?? 'category',
        color: (map['color'] as int?) ?? 0xFF6C4DF6,
        isIncome: (map['is_income'] as int? ?? 0) == 1,
        isCustom: (map['is_custom'] as int? ?? 0) == 1,
        expenseType: map['expense_type'] == 'fixed'
            ? ExpenseType.fixed
            : ExpenseType.variable,
      );
}
